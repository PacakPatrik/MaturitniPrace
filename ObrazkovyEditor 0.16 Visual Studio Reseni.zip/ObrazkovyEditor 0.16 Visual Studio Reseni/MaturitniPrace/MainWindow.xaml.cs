﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Controls;
using System;
using System.IO;
using XamlAnimatedGif;


namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        #region ClassObjects
        AddText addTextClass = new AddText();
        Crop crop = new Crop();
        DPI dpi = new DPI();
        FillColor fillColor = new FillColor();
        GraphicFilters graphicFilters = new GraphicFilters();
        Layers layers = new Layers();
        Paint paint = new Paint();
        Resize resize = new Resize();
        Rotate rotate = new Rotate();
        Selection selection = new Selection();
        Settings settings = new Settings();
        Shapes shapes = new Shapes();
        Zoom zoom = new Zoom();
        Others others = new Others();
        #endregion
        #region Windows

        TxtBoxRec TxtBoxRec = new TxtBoxRec();
        SelectionWindowsWithPoints selectionWindows = new SelectionWindowsWithPoints();
        MouseCreatedRec MouseCreatedRec = new MouseCreatedRec();
        SelectionWindow selectionWindowMenu = new SelectionWindow();
        ResizeWindow resizeWin = new ResizeWindow();
        ShapesWindows shapesWindows = new ShapesWindows();
        #endregion
        #region OtherVariables
        Storyboard sb;
        public BitmapSource original_Image;
        public BitmapSource ZoomImage;
        public BitmapSource first_bitmap_frame;

        public List<Point> list_Of_Points = new List<Point>();
        public List<Ellipse> list_Of_Ellipses = new List<Ellipse>();
        public List<Line> list_Of_Lines = new List<Line>();
        public List<Rectangle> list_Of_Rectangles = new List<Rectangle>();
        public List<Shape> list_Of_Shapes = new List<Shape>();
        public List<BitmapSource> list_Of_Gif_Images = new List<BitmapSource>();
        public List<FileStream> list_Of_Streams = new List<FileStream>();
        public List<Rectangle> list_Of_Painted_Rectangles = new List<Rectangle>();
        public List<Ellipse> list_Of_Painted_Ellipses = new List<Ellipse>();
        public List<BitmapSource> previous_Images = new List<BitmapSource>();

        public string active_Control = "";
        public int count = 0;

        public Size original_picture_size;
        public Size canvas_Size;
        public Size original_Size_To_Set;
        public Size resize_Canvas_Size;
        public Size canvas_Size_On_Open;
        public Size canvas_Size_After_Zoom;
        public Size Mouse_Rec_Size;
        public Size TxtBox_Rec_Size;
        public Size size_of_croppedarea;
        public Size canvas_Zoom_ratio_Size;

        public double ratio_After_Opening=1;
        public double ratio_After_Resize = 1;
        public double ratio_After_Resize_Width=1;
        public double ratio_After_Resize_Height=1;
        public double ratio_zoom=1;
        double zoom_ratio = 1;
        public double zoom_ratio_Width=1;
        public double zoom_ratio_Height=1;

        public Polygon FilledPolygon;
        public Polygon FilterPolygon1;
        public Polygon FilterPolygon2;
        public Rectangle FilledRectangle;
        public Rectangle LowerFilterRectangle;
        public Rectangle UpperFilterRectangle;
        
        public Brush ColorFilledBrush;
    


        public OpenFileDialog openFileDialog = new OpenFileDialog();
        public SaveFileDialog saveFileDialog = new SaveFileDialog();
        public PrintDialog printdialog = new PrintDialog();
        
        
        public ImageBrush imageBrush = new ImageBrush();
        public BitmapImage GifBitmap=new BitmapImage();

        #endregion
        #region BooleanVariables
        public bool Removed_Polygon_Point = false;
        public bool Ended_Polygon = false;
        public bool opened = false;
        public bool Is_Picture_Uploaded = false;
        public bool Is_Stopped_Before_Ending = false;
        public bool Is_polygon_created;
        public bool Is_cut_polygon;
        public bool Is_MouseRec_Open = false;
        public bool Is_SelectionPolygon_Open = false;
        public bool Is_TxTBoxRec_Open = false;
        public bool Is_path_changed;
        public bool Is_Shortcut_Pressed;
        public bool Is_Reset_Done;
        public bool Is_Cut_Done=false;
        public bool Is_Side_Window_Opened = false;
        public bool Is_PictureRotated=false;
        public bool AreProportionsChangedWTxtBox;
        public bool AreProportionsChangedManualy;
        public bool Is_Dpi_Changed;
        public bool Is_Shape_Added;
        public bool Is_Shape_Permanently_Added=false;
        public bool Is_Text_Added;
        public bool Is_Polygon_Filled_With_Color;
        public bool Is_Painting_Allowed;
        public bool Is_Left_Filter_Pressed;
        public bool Is_Right_Filter_Pressed;
        public bool Are_Rectangles_Added=false;
        public bool Is_Open_Pressed = false;
        public bool Is_ApplyToAllFrames_Checked = false;
        public bool Is_Gif_Opened=false;
        public bool Is_Smthg_Added_To_Image = false;
        
        #endregion
        //Funkce a přikazi,které se provedou při spuštění programu
        public MainWindow()
        {

            InitializeComponent();
            Application.Current.MainWindow = this;
            others.SetWindowSize(this);
            System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();
            MemoryStream stream = new MemoryStream();
            dispatcherTimer.Tick += DispatcherTimer_Tick;

            //dispatcherTimer.Interval = new TimeSpan(0,0,5);
            // dispatcherTimer.Start();
            //uppercanvas.Width = this.Width;
            //uppercanvas.Height = this.Height;
            //uppercanvas.Children.Add(MainPicture);
            //MessageBox.Show(Convert.ToString(this.Height));
            int pocet = 0;
         
            //METODA PRO ZJISTENI INDEXU INSTANCE OKNA NEBO TRIDY
            //for (int i = 0; i < Application.Current.Windows.Count; i++)
            //{
            //    try
            //    {
            //        MessageBox.Show(((LayersWindows)Application.Current.Windows[i]).Width.ToString());
            //        pocet = i;
            //        MessageBox.Show(i.ToString());
            //    }
            //    catch
            //    {

            //    }
            //}

        }

        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
          
        }

        //Funkce a přikazi, které se provedou při zavření programu
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);

            Application.Current.Shutdown();
        }
        //Funkce, které se provedou při kliknutí na obrázek(Canvas)
        private void MainPicture_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
            selection.DrawPointsToPolygon(MainPicture, active_Control, Is_Picture_Uploaded, ref Ended_Polygon, list_Of_Points,
                list_Of_Ellipses, list_Of_Lines, ref Removed_Polygon_Point, ref Is_Stopped_Before_Ending, ratio_After_Opening);
            selection.StartRecWithMouse(MainPicture, list_Of_Points, active_Control, list_Of_Rectangles, Is_Picture_Uploaded, ratio_After_Opening, ratio_After_Resize);
            resize.ResizeManualMouseDown(active_Control, MainPicture, uppercanvas);
            paint.PaintMouseDown(Is_Picture_Uploaded);
            
        }
        //Funkce, která ukaže vysunovací menu a změní barvu ikony domu
        private void MenuIcon_MouseDown(object sender, MouseButtonEventArgs e)
        {

            others.ShowMenu(sb, Resources, VysouvaciMenu, ref opened, RectangleMenu);
        }
        //změna barvy ikony domu
        private void MenuIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            others.MenuIconMouseUpColorChange(RectangleMenu);
        }
        //Funkce, které se provedou po kliknutí na tlačítko Open
        private void Otevrit_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            layers.ClearLayers(Is_Open_Pressed);
            others.HideMainMenu(sb, Resources, VysouvaciMenu, ref opened);
            others.OpenFile(st,openFileDialog, MainPicture,/* CanvasBorder */ ref Is_Picture_Uploaded, ref original_picture_size, 
                ref original_Image, ref Is_polygon_created, ref Is_path_changed, ref original_Size_To_Set, ref resize_Canvas_Size,GIFimage,GifBitmap,list_Of_Gif_Images,uppercanvas, ref Is_Gif_Opened, list_Of_Streams);
            others.SetSizeOfCanvas(segmentColection, pathfigure, MainPicture,/* CanvasBorder */ ref ratio_After_Opening, ref canvas_Size, ref canvas_Size_On_Open,
                this, ref canvas_Size_After_Zoom,st,openFileDialog,ref GifBitmap,GIFimage,ref Is_Open_Pressed,ref canvas_Zoom_ratio_Size);
            
            others.PutImageToMiddle(uppercanvas, MainPicture, ref Is_Reset_Done, ref Is_Cut_Done, GIFimage,ref Is_Open_Pressed);
            layers.OpenLayersWindowOnGifOpening(Is_Side_Window_Opened, openFileDialog,list_Of_Gif_Images, Is_Open_Pressed);
            
        }
        //Rozbalení výběru na další 3 možnosti a ztmavení
        private void SelectionIcon_MouseDown(object sender, MouseButtonEventArgs e)
        {
            selection.RenameActiveControl(ref active_Control, "SelectionPolygon", Is_MouseRec_Open, Is_TxTBoxRec_Open);
            selection.MouseDownShowSelectionMenu(RectangleSelection, MainPicture, ratio_After_Opening, canvas_Size, Is_Picture_Uploaded, original_Size_To_Set, ref Is_Side_Window_Opened,Is_Gif_Opened);
        }
        //Zesvětlení controlu u rozbalovacího kontrolu po puštění tlačítka myši
        private void SelectionIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            selection.MouseUpShowIconMenu(RectangleSelection);
        }
        //Funkce, které se provedou při kliknutí na výběr pomocí bodů(volný vyběr)
        private void PolygonSelection_MouseDown(object sender, MouseButtonEventArgs e)
        {

            


            //selection.ReDrawSelectedControlCanvas(SelectedControl, "pack://application:,,,/Resources/icons8-polygon-24.png", active_Control, "SelectionPolygon");
        }
        //Funkce, které se provedou po kliknutí na výběr pomocí čtverce vytvořeného tahem myši
        private void SelectionViaMouse_MouseDown(object sender, MouseButtonEventArgs e)
        {

            selection.RenameActiveControl(ref active_Control, "SelectionMouse", Is_SelectionPolygon_Open, Is_TxTBoxRec_Open);

            selection.ShowMouseRecWindow(count, ref Is_MouseRec_Open);
           // selection.ReDrawSelectedControlCanvas(SelectedControl, "pack://application:,,,/Resources/icons8-mouse-26.png", active_Control, "SelectionMouse");
        }
        //Funkce, které se provedou po kliknutí na výběr pomocí číselného údaje
        private void SelectionViaPoint_MouseDown(object sender, MouseButtonEventArgs e)
        {

            selection.RenameActiveControl(ref active_Control, "SelectionTxtBox", Is_SelectionPolygon_Open, Is_MouseRec_Open);

            selection.ShowTxtBoxRec(count, ref Is_TxTBoxRec_Open);
            //selection.ReDrawSelectedControlCanvas(SelectedControl, "pack://application:,,,/Resources/icons8-rectangular-24.png", active_Control, "SelectionTxtBox");

        }
        //Funkce, které se provedou při táhnutí myši po obrázku
        private void MainPicture_MouseMove(object sender, MouseEventArgs e)
        {
            selection.SetLabelWMouseCoordinates(MainPicture, active_Control,ratio_After_Opening, ratio_After_Resize_Width,ratio_After_Resize_Height);
            selection.DrawLineToPolygon(MainPicture, active_Control, Is_Picture_Uploaded, list_Of_Lines);
            selection.MakeEllipseBigger(MainPicture, active_Control, Is_Picture_Uploaded, list_Of_Ellipses, list_Of_Lines, Removed_Polygon_Point);
            selection.FormRecWhileMovingMouse(MainPicture, active_Control, list_Of_Rectangles, list_Of_Points, ratio_After_Opening, ratio_After_Resize, ref resize_Canvas_Size);
            shapes.HighlightTheShape(MainPicture, Is_Shape_Added, list_Of_Shapes);
            addTextClass.MoveText(Is_Text_Added, MainPicture);
            paint.PaintMouseMove(MainPicture,list_Of_Painted_Rectangles,list_Of_Painted_Ellipses);
            //MessageBox.Show("this is a picture");
        }
        //Funkce, které se provedou po uvolnění tlačítka myši na obrázku
        private void MainPicture_MouseUp_1(object sender, MouseButtonEventArgs e)
        {
            selection.EndFormingRec();
            addTextClass.ReleaseText();
            fillColor.FillWithDesiredColor(MainPicture, Ended_Polygon, list_Of_Points, ref Is_Polygon_Filled_With_Color,ref FilledPolygon,list_Of_Rectangles);
            paint.PaintMouseUp();
            graphicFilters.GetPointsForFilters(MainPicture, Ended_Polygon, list_Of_Points,ref FilterPolygon1,ref FilterPolygon2, list_Of_Rectangles, ref Are_Rectangles_Added, ref LowerFilterRectangle, ref UpperFilterRectangle);
        }
        //Funkce, které se provedou po kliknutí na tlačítko ořezu
        private void CropImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            others.ResetScaleFactor(st);
            crop.CropUsingPolygonPoints(segmentColection, pathfigure, list_Of_Points, Is_Picture_Uploaded, active_Control, ref size_of_croppedarea, ref Is_polygon_created);
            crop.CropUsingRec(list_Of_Rectangles, MainPicture, ratio_After_Opening, ref original_Image, Is_Picture_Uploaded, active_Control, zoom_ratio, ref Is_polygon_created, segmentColection, ref canvas_Size, ref resize_Canvas_Size, ref original_Size_To_Set, Mouse_Rec_Size, TxtBox_Rec_Size);
            crop.DarkerRec(RectangleCrop);
            crop.ClearCanvas(MainPicture, ref Removed_Polygon_Point, ref Ended_Polygon, ref Is_Stopped_Before_Ending, list_Of_Ellipses, list_Of_Lines, list_Of_Points, ref active_Control, ref count, Is_Picture_Uploaded);
            others.CutDone(ref Is_Cut_Done);
            others.PutImageToMiddle(uppercanvas,MainPicture, ref Is_Reset_Done, ref Is_Cut_Done, GIFimage,ref Is_Open_Pressed);
        }
        // Zesvětlení tlačítka ořezu při uvolnění tlačitka na myši
        private void CropImage_MouseUp(object sender, MouseButtonEventArgs e)
        {
            crop.LigherRec(RectangleCrop);
        }
        //Funkce,která se provede při stisknutí tlačítka Save
        private void Ulozit_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            others.CreateSaveCopyFile(active_Control, Is_polygon_created, Is_Picture_Uploaded);

        }
        //Funkce,která se provede při stisknutí tlačítka Save As
        private void UlozitJako_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            others.SaveImage(saveFileDialog, active_Control);
        }
        //Funkce,která se provede při otočení kolečkem na obrázku
        private void MainPicture_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            zoom.ZoomOnCanvas(ref canvas_Size_After_Zoom,st,uppercanvas,e, MainPicture, ref original_Image, ratio_After_Opening, Is_polygon_created, ref zoom_ratio_Width,ref zoom_ratio_Height, ref zoom_ratio, Is_Shape_Added,Is_Text_Added, segmentColection,pathfigure, ref canvas_Zoom_ratio_Size);
            shapes.MouseWheelOnShape(list_Of_Shapes,MainPicture, e, Is_Shape_Added);
        }

        //Funkce, která navrátí zpět velikost obrázku do původní velikosti jako při otevření a smaže všechny změny
        private void ResetButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                ResetToLoadState();
            }
            catch { }
        }



        #region ResizeMethods


        private void ResizeIcon_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
            resize.ShowResizeMenu(RectangleResize, MainPicture, ratio_After_Opening, ref resize_Canvas_Size, Is_Picture_Uploaded, original_Size_To_Set, ref Is_Side_Window_Opened, Is_Gif_Opened);
            
        }

        private void ResizeIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            resize.SetColorToOriginal(RectangleResize);
        }

        #endregion

        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                others.CTRLplusZShortcutPressed(e, ref Is_Shortcut_Pressed);
                if (Is_Shortcut_Pressed == true)
                {

                    ResetToLoadState();
                    Is_Shortcut_Pressed = false;
                }
            }
            catch{ }
            
        }
        #region ResetButtonCode
        public void ResetToLoadState()
        {
            if (Is_Gif_Opened == false)
            {
                if (active_Control == "ResizePercent"){
                    uppercanvas.Children.RemoveAt(uppercanvas.Children.Count);
                }
                original_Size_To_Set = original_picture_size;
                Is_Reset_Done = true;
                st.ScaleX = 1;
                st.ScaleY = 1;
                canvas_Zoom_ratio_Size.Width = canvas_Size_On_Open.Width;
                canvas_Zoom_ratio_Size.Height = canvas_Size_On_Open.Height;

                Removed_Polygon_Point = false;
                Ended_Polygon = false;
                opened = false;
                //Picture_Uploaded = false;
                Is_Stopped_Before_Ending = false;
                Is_polygon_created = false;
                Is_cut_polygon = false;
                Is_Shape_Added = false;
                Is_Side_Window_Opened = false;

                Is_MouseRec_Open = false;
                Is_SelectionPolygon_Open = false;
                Is_TxTBoxRec_Open = false;
                zoom_ratio_Width = 1;
                zoom_ratio_Height = 1;

                list_Of_Points.Clear();
                list_Of_Ellipses.Clear();
                list_Of_Lines.Clear();
                list_Of_Rectangles.Clear();
                count = 0;
                zoom_ratio = 1;
                original_Image = others.UploadedImage;
                imageBrush.ImageSource = original_Image;

                MainPicture.Width = others.sizeAfterOpen.Width;
                MainPicture.Height = others.sizeAfterOpen.Height;
                MainPicture.Background = imageBrush;

                others.ResetLineSegment(MainPicture, segmentColection, pathfigure);

                selection.RemoveTxtBoxesOnReset();
                ratio_After_Resize = 1;
                ratio_After_Resize_Height = 1;
                ratio_After_Resize_Width = 1;
                MainPicture.Children.Clear();
                selectionWindowMenu.OriginalHeight.Text = Convert.ToString(original_Size_To_Set.Width);
                selectionWindowMenu.OriginalWidth.Text = Convert.ToString(original_Size_To_Set.Height);

                selectionWindowMenu.TxtY.Text = "0";
                selectionWindowMenu.TxtX.Text = "0";
                selectionWindowMenu.TxTWidth.Text = "0";
                selectionWindowMenu.TxTHeight.Text = "0";

                RemoveStackpanelChildren();
                resizeWin.OnresetButton(canvas_Size.Width * ratio_After_Opening, canvas_Size.Height * ratio_After_Opening);
                canvas_Size = canvas_Size_On_Open;
                others.PutImageToMiddle(uppercanvas, MainPicture, ref Is_Reset_Done, ref Is_Cut_Done, GIFimage, ref Is_Open_Pressed);
                canvas_Size_After_Zoom.Width = others.sizeAfterOpen.Width;
                canvas_Size_After_Zoom.Height = others.sizeAfterOpen.Height;
            }
            else
            {
                foreach (Window window in Application.Current.Windows)
                {
                    if (window.Title != "LayersWindows" && window.Title!= "Obrazkovy Editor")
                    {
                        window.Visibility = Visibility.Hidden;
                    }
                }
                MainPicture.Visibility = Visibility.Hidden;
                GIFimage.Visibility = Visibility.Visible;
                //list_Of_Streams[list_Of_Streams.Count - 1].Dispose();
                layers.DeleteredrawButtons();
                foreach(FileStream stream in list_Of_Streams)
                {
                    stream.Dispose();
                }
                list_Of_Streams.Clear();
                //MessageBox.Show(others.original_gif_path);
                //AnimationBehavior.SetSourceUri(GIFimage, null);
                AnimationBehavior.SetSourceStream(GIFimage, null);
                AnimationBehavior.SetSourceUri(GIFimage,new Uri(others.original_gif_path));
                //AnimationBehavior.SetSourceUri(GIFimage, new Uri(openFileDialog.FileName));
                // ((LayersWindows)Application.Current.Windows[14]).ListOfAllLayersStackpanel.Children.RemoveRange(0, ((LayersWindows)Application.Current.Windows[14]).ListOfAllLayersStackpanel.Children.Count);


                layers.list_of_all_layer_borders.Clear();
                layers.list_Of_Delete_Buttons.Clear();
                layers.list_Of_Redraw_Button.Clear();
                layers.list_Of_Stackpanels.Clear();
                ((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate.Clear();
               ((LayersWindows)Application.Current.Windows[14]).ListOfAllLayersStackpanel.Children.RemoveRange(0, ((LayersWindows)Application.Current.Windows[14]).ListOfAllLayersStackpanel.Children.Count);
                for (int i = 0; i < list_Of_Gif_Images.Count; i++)
                {

                    Border border = new Border();
                    border.BorderThickness = new Thickness(15);
                    border.BorderBrush = new SolidColorBrush(Colors.Black);
                    border.BorderBrush.Opacity = 0;

                    Button deletebutton = new Button();
                    deletebutton.Content = "X";
                    deletebutton.Width = 30;
                    deletebutton.Height = 30;
                    deletebutton.Margin = new Thickness(0, 0, 10, 0);
                    deletebutton.Background = new SolidColorBrush(Colors.DarkRed);
                    deletebutton.PreviewMouseDown += layers.Deletebutton_PreviewMouseDown; 
                    layers.list_Of_Delete_Buttons.Add(deletebutton);

                    //border.Name = i.ToString();
                    layers.list_of_all_layer_borders.Add(border);

                    layers.list_of_all_layer_borders[i].Width = layers.list_of_all_layer_borders[0].Width;
                    layers.list_of_all_layer_borders[i].Height = layers.list_of_all_layer_borders[0].Height;
                    layers.list_of_all_layer_borders[layers.list_of_all_layer_borders.Count - 1].MouseMove += layers.Layers_MouseMove;
                    layers.list_of_all_layer_borders[layers.list_of_all_layer_borders.Count - 1].MouseDown += layers.Layers_PreviewMouseDown;
                    StackPanel stackpanel1 = new StackPanel();
                    StackPanel stackpanel2 = new StackPanel();
                    stackpanel1.Orientation = Orientation.Horizontal;
                    stackpanel2.Orientation = Orientation.Vertical;
                    ratio_zoom = 1;
                    stackpanel1.Children.Add(deletebutton);

                    Border border2 = new Border();
                    border2.Background = new SolidColorBrush(Colors.White);

                    System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                    image.Source = list_Of_Gif_Images[i];
                    image.Stretch = Stretch.Fill;
                    //image.Width = list_of_all_layer_borders[0].Width;
                    //image.Height = list_of_all_layer_borders[0].Height;
                    ((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate.Add(image);

                    border2.Child = image;
                    stackpanel1.Children.Add(border2);
                    layers.list_of_all_layer_borders[i].Child = stackpanel1;
                    layers.ratiotoscaledown = border2.Height / 120;
                    stackpanel1.Children.Add(stackpanel2);

                    TextBlock nameoflayer = new TextBlock();
                    nameoflayer.Text = "Layer n." + i.ToString();
                    nameoflayer.FontWeight = FontWeights.Bold;


                    stackpanel2.Children.Add(nameoflayer);




                    // stackpanel2.Children.Add(deletebutton);
                    stackpanel2.HorizontalAlignment = HorizontalAlignment.Right;
                    stackpanel2.VerticalAlignment = VerticalAlignment.Center;



                    border2.Height = 120;
                    border2.Width *= layers.ratiotoscaledown;
                    // MessageBox.Show(border_Positions[i].ToString());
                    ((LayersWindows)Application.Current.Windows[14]).ListOfAllLayersStackpanel.Children.Add(layers.list_of_all_layer_borders[i]);
                    layers.list_Of_Stackpanels.Add(stackpanel2);
                    layers.list_Of_Reset_Borders.Add(layers.list_of_all_layer_borders[i]);
                    //((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate.Clear();
                    //for(int j = 0; j < list_Of_Gif_Images.Count; j++)
                    //{
                    //    Image image2 = new Image();
                    //    image2.Source = list_Of_Gif_Images[j];
                    //    ((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate.Add(image2);
                    //}
                }

            }
        }

        public void RemoveStackpanelChildren()
        {
            selectionWindowMenu.textboxstackpanel.Children.Clear();
        }
        #endregion

        private void Form_KeyUp(object sender, KeyEventArgs e)
        {
            others.CTRLReleased(e);
        }

        private void Image_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            rotate.DarkenTheButtonAfterPress(RectangleRotate);
            rotate.RotateCanvas(original_Image, MainPicture,uppercanvas,ref Is_PictureRotated,ref resize_Canvas_Size, Is_Picture_Uploaded);
            rotate.ImageToMiddle(uppercanvas,MainPicture);
            others.ResetLineSegment(MainPicture, segmentColection, pathfigure);
        }

        private void Image_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            rotate.LightenTheButtonAfterReleas(RectangleRotate);
        }

        private void uppercanvas_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            resize.ChangeCursorOnEdges(MainPicture, uppercanvas, active_Control, ratio_After_Opening, ratio_After_Resize_Width,ratio_After_Resize_Height);
           
        }

        private void uppercanvas_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            resize.ResizeManualMouseUp(uppercanvas, MainPicture, ref AreProportionsChangedManualy, active_Control);
 
        }

        private void uppercanvas_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            others.HideMainMenu(sb, Resources, VysouvaciMenu, ref opened);
        }

        private void Tisk_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            others.TiskObrazku(printdialog, MainPicture,Is_Picture_Uploaded, original_Image);
        }

        private void DPIChange_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            dpi.ShowDpiMenu(RectangleDPI,ref Is_Side_Window_Opened);
           // dpi.ChangeTheDpi(original_Image, MainPicture);
        }

        private void DPIChange_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            dpi.LightenTheButton(RectangleDPI);
        }

        private void Shapes_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            shapes.ShowShapeMenu(RectangleShapes,ref Is_Side_Window_Opened);
        }

        private void Shapes_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            shapes.LightenTheRectangle(RectangleShapes);
        }

        private void AddText_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            addTextClass.ShowAddTextMenu(RectangleText,MainPicture,ref Is_Side_Window_Opened,Is_Text_Added);
        }

        private void AddText_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            addTextClass.ReleaseMouseOnIcon(RectangleText);
        }

        private void FilColor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            fillColor.ShowFillColorMenu(RectangleFillColor, active_Control);
           
        }

        private void FilColor_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            fillColor.FillColorMouseUp(RectangleFillColor);
        }

        private void PaintBrush_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            paint.ShowPaintMenu(RectanglePaint,ref Is_Side_Window_Opened);
        }

        private void PaintBrush_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            paint.ReleaseMouseOnButton(RectanglePaint);
        }


        private void GraphicFilters_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            graphicFilters.ShowFilterWindow(RectangleFilters, ref Is_Side_Window_Opened,MainPicture,ref LowerFilterRectangle,ref UpperFilterRectangle, ref Are_Rectangles_Added);
        }

        private void GraphicFilters_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            graphicFilters.FilterIconMouseUp(RectangleFilters);
        }

        private void LayersButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            layers.ShowLayersWindow(Is_Side_Window_Opened, RectangleLayers,Is_Gif_Opened);
        }

        private void LayersButton_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            layers.LayersWindowMouseUp(RectangleLayers);
        }

        private void Form_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            layers.DeleteAllGifsBeforeClossing();           
        }
    }
}