﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro DPIWindow.xaml
    /// </summary>
    public partial class DPIWindow : Window
    {
      
        ImageBrush imageBrush;
        Brush brush;
        BitmapSource bitmapSource;
        double scale;
        public DPIWindow()
        {
            InitializeComponent();
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
        }

        private void CloseButton_PreviewMouseDown_1(object sender, MouseButtonEventArgs e)
        {
            
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;

        }

      

     

        private void DownArrow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded == true)
            {
                brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                imageBrush = (ImageBrush)brush;
                bitmapSource = (BitmapSource)imageBrush.ImageSource;
                ((MainWindow)Application.Current.MainWindow).previous_Images.Add((BitmapSource)imageBrush.ImageSource);
                scale = 0.7;
                TransformedBitmap transformedBitmap = new TransformedBitmap(bitmapSource, new ScaleTransform(scale, scale));
                imageBrush.ImageSource = transformedBitmap;
                //imageBrush.Stretch = Stretch.Fill;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Background = brush;
              
                ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed = true;
                ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed = true;
            }
        }

        private void UpArrow_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                imageBrush.ImageSource = ((MainWindow)Application.Current.MainWindow).previous_Images[((MainWindow)Application.Current.MainWindow).previous_Images.Count - 1];
                ((MainWindow)Application.Current.MainWindow).previous_Images.RemoveAt(((MainWindow)Application.Current.MainWindow).previous_Images.Count - 1);
                brush = imageBrush;
            }
            catch { }
        }
    }
}
