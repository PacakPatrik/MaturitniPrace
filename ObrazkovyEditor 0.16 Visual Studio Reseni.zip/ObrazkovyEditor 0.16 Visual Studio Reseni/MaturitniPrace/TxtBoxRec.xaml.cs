﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro TxtBoxRec.xaml
    /// </summary>
    public partial class TxtBoxRec : Window
    {
        Point start_point;
        Size rec_size;
        public TxtBoxRec()
        {
            InitializeComponent();
           
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        //Smaže čtverec a body vytvořené na obrázku
        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            PointXTxt.Text = "";
            PointYTxt.Text = "";
            WidthTxt.Text = "";
            HeightTxtx.Text = "";
            ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Clear();
            for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j > -1; j--)
            {
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
            }
         
            ((MainWindow)Application.Current.MainWindow).active_Control = "";
            ((MainWindow)Application.Current.MainWindow).count = 0;

           
            this.Visibility = Visibility.Hidden;
        }
        //Změní souřadnici v textboxu bodu X(oranžové tečky) na obrázku
        private void PointXTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (PointXTxt.Text == ""){}
            else if (Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < ((MainWindow)Application.Current.MainWindow).MainPicture.Width &&
               Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0 && PointXTxt.Text !="")
            {
                start_point.X = Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening;

                if (((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count < 1)
                {
                    Ellipse ellipse = new Ellipse();
                    ellipse.Height = 5;
                    ellipse.Width = 5;
                    ellipse.Fill = new SolidColorBrush(Colors.Orange);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(ellipse);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Add(ellipse);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count-1], start_point.X);
                }
                else
                {
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.X);
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                    {
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count-1], start_point.X);
                    }
                }
            }
        }
        //Změní souřadnici v textboxu bodu Y(oranžové tečky) na obrázku
        private void PointYTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (PointYTxt.Text == "") {}
            else if (Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < ((MainWindow)Application.Current.MainWindow).MainPicture.Height &&
               Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0 )
            {
                start_point.Y = Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening;


                if (((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count < 1)
                {
                    Ellipse ellipse = new Ellipse();
                    ellipse.Height = 5;
                    ellipse.Width = 5;
                    ellipse.Fill = new SolidColorBrush(Colors.Orange);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(ellipse);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Add(ellipse);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.Y);
                }
                else
                {
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.Y);
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                    {
                        Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                    }
                }
            }
        }
        //změna šírki v textboxu, změní šířku čtverce na obrázku
        private void WidthTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (WidthTxt.Text == "")
            {

            }
            else if (Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < Math.Abs(start_point.X - ((MainWindow)Application.Current.MainWindow).MainPicture.Width) &&
                Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0 )
                rec_size.Width = Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening;
            {
                if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count < 1) 
                {

                    Rectangle rec = new Rectangle();
                    rec.Width = rec_size.Width;
                    rec.Height = 1;
                    rec.Stroke = new SolidColorBrush(Colors.Yellow);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Add(rec);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rec);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.X);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                }
                else
                {
                    ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1].Width = rec_size.Width;
                }
            }
            
        }
        //změna výšky v textboxu, změní výšku čtverce na obrázku
        private void HeightTxtx_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (HeightTxtx.Text == "")
            {

            }
            else if (Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < Math.Abs(start_point.Y - ((MainWindow)Application.Current.MainWindow).MainPicture.Height) &&
                Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0 )
            {
                rec_size.Height = Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening;
                if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count < 1)
                {
                    Rectangle rec = new Rectangle();
                    rec.Height = rec_size.Height;
                    rec.Width = 1;
                    rec.Stroke = new SolidColorBrush(Colors.Yellow);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Add(rec);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rec);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.X);
                }
                else
                {
                    ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1].Height = rec_size.Height;
                }
            }
        }
        //Kod, který se provede, pokud se visibility(viditelnost) okna
        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.Visibility == Visibility.Visible)
            {
                OriginalWidth.Text =Convert.ToString(((MainWindow)Application.Current.MainWindow).original_picture_size.Width);
                OriginalHeight.Text = Convert.ToString(((MainWindow)Application.Current.MainWindow).original_picture_size.Height);
            }
        }
        //Kod, který se provede při dokončení výběru
        private void OkButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_TxTBoxRec_Open = false;
        }
    }
}
