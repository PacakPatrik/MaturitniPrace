﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Media.Imaging;
using System.Windows.Controls;
using System.IO;
using System.Drawing;
using XamlAnimatedGif;
using System.Drawing.Imaging;

namespace MaturitniPrace
{

    class Layers
    {
        LayersWindows layersWindows = new LayersWindows();
        public List<Border> list_of_all_layer_borders = new List<Border>();
        public List<StackPanel> list_Of_Stackpanels = new List<StackPanel>();
        List<System.Windows.Point> border_Positions = new List<System.Windows.Point>();
        public List<Button> list_Of_Delete_Buttons = new List<Button>();
        public List<Button> list_Of_Redraw_Button = new List<Button>();
        BitmapSource bitmapsource;
        public List<Border> list_Of_Reset_Borders=new List<Border>();
        System.Windows.Media.Brush brush;
        ImageBrush imageBrush = new ImageBrush();
        BitmapImage bitmapimage = new BitmapImage();
        PngBitmapEncoder bitmapEncoder = new PngBitmapEncoder();
        public double ratiotoscaledown;
        bool converted;
        //bool redrawpressed=true;
        public void ShowLayersWindow(bool is_side_window_opened, System.Windows.Shapes.Rectangle rec,bool Is_Gif_Opened)
        {
            if (!is_side_window_opened)
            {
                if (Is_Gif_Opened)
                {
                    layersWindows.Visibility = Visibility.Visible;
                    rec.Fill = new SolidColorBrush(System.Windows.Media.Color.FromRgb(40, 40, 40));


                    //if (!converted)
                    //{
                    //    using (var stream = new MemoryStream())
                    //    {
                    //        bitmapEncoder.Save(stream);
                    //        stream.Seek(0, SeekOrigin.Begin);

                    //        bitmapimage.BeginInit();
                    //        bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                    //        bitmapimage.StreamSource = stream;
                    //        bitmapimage.EndInit();

                    //    }

                    //    imageBrush.ImageSource = bitmapimage;
                    //    converted = true;
                    //}
                }
                else
                {
                    MessageBox.Show("This function is reserved only for GIF formats");
                }
                }
        }
        public void LayersWindowMouseUp(System.Windows.Shapes.Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(System.Windows.Media.Color.FromRgb(65, 65, 65));
        }
        public void OpenLayersWindowOnGifOpening(bool is_side_window_opened, OpenFileDialog openfile, List<BitmapSource> list_of_Gif_Images, bool Is_Open_Pressed)
        {
            if (!is_side_window_opened && openfile.FileName.EndsWith(".gif"))
            {
                layersWindows.Visibility = Visibility.Visible;
                PutLayersIntoWindow(list_of_Gif_Images, Is_Open_Pressed);
            }
        }
        public void PutLayersIntoWindow(List<BitmapSource> list_of_Gif_Images, bool isopenpressed)
        {
            if (isopenpressed)
            {
                for (int i = 0; i < list_of_Gif_Images.Count; i++)
                {
                    
                    Border border = new Border();
                    border.BorderThickness = new Thickness(15);
                    border.BorderBrush = new SolidColorBrush(Colors.Black);
                    border.BorderBrush.Opacity = 0;
                
                    Button deletebutton = new Button();
                    deletebutton.Content = "X";
                    deletebutton.Width = 30;
                    deletebutton.Height = 30;
                    deletebutton.Margin = new Thickness(0, 0, 10, 0);
                    deletebutton.Background = new SolidColorBrush(Colors.DarkRed);
                    deletebutton.PreviewMouseDown += Deletebutton_PreviewMouseDown; ;
                    list_Of_Delete_Buttons.Add(deletebutton);

                    //border.Name = i.ToString();
                    list_of_all_layer_borders.Add(border);
                  
                    list_of_all_layer_borders[i].Width= list_of_all_layer_borders[0].Width;
                    list_of_all_layer_borders[i].Height = list_of_all_layer_borders[0].Height;
                    list_of_all_layer_borders[list_of_all_layer_borders.Count - 1].MouseMove += Layers_MouseMove;
                    list_of_all_layer_borders[list_of_all_layer_borders.Count - 1].MouseDown += Layers_PreviewMouseDown;
                    StackPanel stackpanel1 = new StackPanel();
                    StackPanel stackpanel2 = new StackPanel();
                    stackpanel1.Orientation = Orientation.Horizontal;
                    stackpanel2.Orientation = Orientation.Vertical;

                    stackpanel1.Children.Add(deletebutton);

                    Border border2 = new Border();
                    border2.Background = new SolidColorBrush(Colors.White);

                    System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                    image.Source = list_of_Gif_Images[i];
                    image.Stretch = Stretch.Fill;
                    //image.Width = list_of_all_layer_borders[0].Width;
                    //image.Height = list_of_all_layer_borders[0].Height;
                    layersWindows.list_Of_Images_To_Animate.Add(image);

                    border2.Child = image;
                    stackpanel1.Children.Add(border2);
                    list_of_all_layer_borders[i].Child = stackpanel1;
                    ratiotoscaledown = border2.Height / 120;
                    stackpanel1.Children.Add(stackpanel2);

                    TextBlock nameoflayer = new TextBlock();
                    nameoflayer.Text = "Layer n." + i.ToString();
                    nameoflayer.FontWeight = FontWeights.Bold;


                    stackpanel2.Children.Add(nameoflayer);




                    // stackpanel2.Children.Add(deletebutton);
                    stackpanel2.HorizontalAlignment = HorizontalAlignment.Right;
                    stackpanel2.VerticalAlignment = VerticalAlignment.Center;



                    border2.Height = 120;
                    border2.Width *= ratiotoscaledown;
                    // MessageBox.Show(border_Positions[i].ToString());
                    layersWindows.ListOfAllLayersStackpanel.Children.Add(list_of_all_layer_borders[i]);
                    list_Of_Stackpanels.Add(stackpanel2);
                    list_Of_Reset_Borders.Add(list_of_all_layer_borders[i]);
                }
            }
        }


        public void Layers_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            //MessageBox.Show("hej");
            for (int i = 0; i < list_of_all_layer_borders.Count; i++)
            {

                if (list_of_all_layer_borders[i].IsMouseOver)
                {
                     //if (redrawpressed)
                     //{
                    // MessageBox.Show(i.ToString());
                   
                         for (int j = 0; j < list_of_all_layer_borders.Count; j++)
                        {
                            list_of_all_layer_borders[j].BorderBrush.Opacity = 0;
                         
                        }
                        list_of_all_layer_borders[i].BorderBrush.Opacity = 0.7;

                        ImageBrush brush = new ImageBrush();
                        brush.ImageSource = layersWindows.list_Of_Images_To_Animate[i].Source;
                        ((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded = true;
                        DeleteredrawButtons();
                        HideGIFAndShowCanvas(brush);

                        list_Of_Redraw_Button.Clear();

                        Button redrawbutton = new Button();
                        redrawbutton.Background = new SolidColorBrush(Colors.LightGreen);
                        redrawbutton.Content = "Redraw Frame";
                   
                        list_Of_Redraw_Button.Add(redrawbutton);
                        list_Of_Redraw_Button[0].PreviewMouseDown += Layers_PreviewMouseDown1;
                        list_Of_Stackpanels[i].Children.Add(list_Of_Redraw_Button[0]);
                        //redrawpressed = false;
                    
                     //}

                }
            }
            
        }

        public void Layers_PreviewMouseDown1(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
           // 
            for (int i = 0; i < layersWindows.ListOfAllLayersStackpanel.Children.Count; i++)
            {

                if (list_Of_Stackpanels[i].IsMouseOver)
                {
                    
                    //MessageBox.Show(i.ToString());
                    brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
               
                    imageBrush = (ImageBrush)brush;
                    //BitmapImage bitmap3 = new BitmapImage();
                    //bitmap3 = (BitmapImage)imageBrush.ImageSource;
                    //Bitmap bitmap2;
                    //bitmap2 = ToWinFormsBitmap(bitmap3);
                    //for (int x = 0; x < bitmap2.Width; x++)
                    //{
                    //    for (int y = 0; y < bitmap2.Height; y++)
                    //    {
                    //        System.Drawing.Color bitColor = bitmap2.GetPixel(x, y);
                    //        //Sets all the pixels to white but with the original alpha value
                    //        bitmap2.SetPixel(x, y, System.Drawing.Color.FromArgb(bitColor.A, 255, 255, 255));
                    //    }
                    //}
                    //imageBrush.ImageSource = ToWpfBitmap(bitmap2);
                    //    brush = imageBrush;
                    
                   
                    var bitmap = new RenderTargetBitmap((int)(((MainWindow)Application.Current.MainWindow).MainPicture.Width), (int)(((MainWindow)Application.Current.MainWindow).MainPicture.Height), 96, 96, PixelFormats.Pbgra32);

                  //  var brush2 = new VisualBrush(((MainWindow)Application.Current.MainWindow).MainPicture);

                    var visual = new DrawingVisual();
                    var drawingContext = visual.RenderOpen();


                    drawingContext.DrawRectangle(brush, null, new Rect(new System.Windows.Point(0, 0), new System.Windows.Point((int)(((MainWindow)Application.Current.MainWindow).MainPicture.Width), (int)(((MainWindow)Application.Current.MainWindow).MainPicture.Height))));

                    drawingContext.Close();

                    bitmap.Render(visual);

                    
                    bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));
                 
                  

                    bitmapsource = (BitmapSource)imageBrush.ImageSource;
                    if (((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed == true)
                    {
                        var bitmapa = new TransformedBitmap(bitmapsource, new ScaleTransform(((MainWindow)Application.Current.MainWindow).previous_Images[0].Width / bitmapsource.PixelWidth, ((MainWindow)Application.Current.MainWindow).previous_Images[0].Height/ bitmapsource.PixelHeight));
                        ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed = false;
                        bitmapsource = bitmapa;
                    }
                
                  
                    layersWindows.list_Of_Images_To_Animate[i].Source = bitmapsource;
                    ImageBrush imagebrush3 = new ImageBrush();
                    imagebrush3.ImageSource = bitmapsource;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imagebrush3;
                   // redrawpressed = true;
                    break;
                    
                }
           
            }
            DeleteredrawButtons();






            
        }

        public void Deletebutton_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            for (int i = 0; i < layersWindows.ListOfAllLayersStackpanel.Children.Count; i++)
            {

                if (list_Of_Delete_Buttons[i].IsMouseOver)
                {
                    layersWindows.ListOfAllLayersStackpanel.Children.RemoveAt(i);
                    list_of_all_layer_borders.RemoveAt(i);
                    list_Of_Delete_Buttons.RemoveAt(i);
                    list_Of_Stackpanels.RemoveAt(i);
                    list_Of_Redraw_Button.Clear();
                    layersWindows.list_Of_Images_To_Animate.RemoveAt(i);
                }
            }
        }

     

    

        public void Layers_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            for (int i = 0; i < list_of_all_layer_borders.Count; i++)
            {

                if (list_of_all_layer_borders[i].IsMouseOver)
                {
                    // MessageBox.Show(i.ToString());
                    for(int j = 0; j < list_of_all_layer_borders.Count; j++)
                    {
                        list_of_all_layer_borders[j].BorderBrush.Opacity = 0;
                    }
                    list_of_all_layer_borders[i].BorderBrush.Opacity = 0.5;

                }
            }
        }


        public void ClearLayers(bool Is_Open_Pressed)
        {
            if (Is_Open_Pressed)
            {
                layersWindows.ListOfAllLayersStackpanel.Children.Clear();
            }
        }
        public void HideGIFAndShowCanvas(ImageBrush imagetoload)
        {

            //((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Clear();
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Add(((MainWindow)Application.Current.MainWindow).MainPicture);
            ((MainWindow)Application.Current.MainWindow).MainPicture.IsEnabled = true;
            ((MainWindow)Application.Current.MainWindow).GIFimage.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Visibility = Visibility.Visible;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imagetoload;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).list_Of_Gif_Images[0].Width;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).list_Of_Gif_Images[0].Height;
            
            ((MainWindow)Application.Current.MainWindow).segmentColection.Clear();
            LineSegment lineSegment1 = new LineSegment();
            LineSegment lineSegment2 = new LineSegment();
            LineSegment lineSegment3 = new LineSegment();
            LineSegment lineSegment4 = new LineSegment();

            lineSegment2.Point = new System.Windows.Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, 0);
            lineSegment3.Point = new System.Windows.Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);
            lineSegment4.Point = new System.Windows.Point(0, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);
            ((MainWindow)Application.Current.MainWindow).pathfigure.StartPoint = lineSegment1.Point = new System.Windows.Point(0, 0);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(lineSegment2);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(lineSegment3);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(lineSegment4);
            //((MainWindow)Application.Current.MainWindow).MainPicture.Width = 200;
            //((MainWindow)Application.Current.MainWindow).MainPicture.Height = 200;
            ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
            ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height = 1;
            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width = 1;
            //Rectangle rec = new Rectangle();
            //rec.Width = 200;
            //rec.Height = 200;
            //rec.Fill = new SolidColorBrush(Colors.White);
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Add(rec);
            Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2- ((MainWindow)Application.Current.MainWindow).MainPicture.Width/2);
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Add(((MainWindow)Application.Current.MainWindow).MainPicture);
            Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2- ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2);

        }

        public void DeleteAllGifsBeforeClossing()
        {
            AnimationBehavior.SetSourceStream(((MainWindow)Application.Current.MainWindow).GIFimage, null);
            for(int k=0;k< ((MainWindow)Application.Current.MainWindow).list_Of_Streams.Count ; k++)
            {
                ((MainWindow)Application.Current.MainWindow).list_Of_Streams[k].Close();
            }
            for (int j = 0; j < ((MainWindow)Application.Current.MainWindow).list_Of_Streams.Count ; j++)
            {
                ((MainWindow)Application.Current.MainWindow).list_Of_Streams[j].Dispose();
            }
            for (int i = 0; i < 20; i++)
            {
                File.Delete((i).ToString() + ".gif");
            }
        }

        public void DeleteredrawButtons()
        {
            for (int i = 0; i < list_Of_Stackpanels.Count; i++)
            {
                if (list_Of_Stackpanels[i].Children.Count > 1)
                {
                    list_Of_Stackpanels[i].Children.RemoveAt(1);
                }
            }
        }

      public void ResetImages(Border border)
        {
            
         
        }
    }
}
