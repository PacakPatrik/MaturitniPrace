﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Markup;

namespace MaturitniPrace
{
    class Resize
    {
        ResizeWindow resizeWindow = new ResizeWindow();
        SelectionWindow selectionWindow = new SelectionWindow();

        #region Varibles
        bool MouseDown=false;

        string direction="";
        List<Rectangle> rectanglelist = new List<Rectangle>();
        #endregion

        #region Others

        public void ShowResizeMenu(Rectangle rec,Canvas maincanvas,double ratio,ref Size resizecanvasSize,bool pictureuploaded, Size original_size_to_Set, ref bool Is_Side_Window_Opened,bool IsGifOpened)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
            if (Is_Side_Window_Opened == false)
            {
                if (!IsGifOpened)
                {
                    resizeWindow.Visibility = Visibility.Visible;
                    if (((MainWindow)Application.Current.MainWindow).Is_path_changed == true)
                    {
                        resizeWindow.SetOriginals(Convert.ToString(original_size_to_Set.Width), Convert.ToString(original_size_to_Set.Height), pictureuploaded);
                        ((MainWindow)Application.Current.MainWindow).Is_path_changed = false;
                        if (resizecanvasSize.Width == 0)
                        {
                            resizecanvasSize.Width = maincanvas.Width * ratio;
                            resizecanvasSize.Height = maincanvas.Height * ratio;
                        }
                    }
                    else
                    {
                        resizeWindow.PassRatio(ratio);
                        resizeWindow.SetOriginals(Convert.ToString(original_size_to_Set.Width), Convert.ToString(original_size_to_Set.Height), pictureuploaded);
                        if (resizecanvasSize.Width == 0)
                        {
                            resizecanvasSize.Width = maincanvas.Width * ratio;
                            resizecanvasSize.Height = maincanvas.Height * ratio;

                        }
                    }

                    Is_Side_Window_Opened = true;
                }
                else
                {
                    MessageBox.Show("Due to maintaining the ratio of Gif, this option is not available");
                }
                    //MessageBox.Show(Convert.ToString(original_size_to_Set.Width));
            }
        }
        public void SetColorToOriginal(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
        #endregion


        #region ResizeWithMouse
        public void ChangeCursorOnEdges(Canvas canvas,Canvas uppercanvas, string ActiveControl,double ratioafteropen, double ratioafterresizewidth,double ratioafterresizeheight )
        {

            Point p = Mouse.GetPosition(uppercanvas);
            if (ActiveControl == "ResizeManual")
            {

                if ((p.Y > Canvas.GetTop(canvas) + canvas.Height - 10 && p.Y < Canvas.GetTop(canvas) + canvas.Height) || (p.Y < Canvas.GetTop(canvas) + 10 && p.Y > Canvas.GetTop(canvas)))
                {
                    Mouse.OverrideCursor = Cursors.SizeNS;
                }
                else if ((p.X > Canvas.GetLeft(canvas) + canvas.Width - 10 && p.X < Canvas.GetLeft(canvas) + canvas.Width) || (p.X < Canvas.GetLeft(canvas) + 10 && p.X > Canvas.GetLeft(canvas)))
                {
                    Mouse.OverrideCursor = Cursors.SizeWE;
                }
                else /*((p.X > 10 && p.X < canvas.Width - 10 && p.Y > 10 && p.Y < canvas.Height - 10) || p.X < 2 || p.X > canvas.Width - 2 || p.Y < 2 || p.Y > canvas.Height - 2)*/
                {
                    Mouse.OverrideCursor = Cursors.Arrow;
                }
            }
            if (ActiveControl=="ResizeManual" && MouseDown==true)
            {
                if (direction == "L" && p.X>5)
                {
                    Canvas.SetLeft(rectanglelist[0], p.X);
                    rectanglelist[0].Width= Math.Abs((Canvas.GetLeft(canvas) + canvas.Width) - p.X);
                    resizeWindow.SetManualWidthAndHeight(Math.Round(Convert.ToDouble(rectanglelist[0].Width)/0.5)*ratioafteropen, Math.Round((Convert.ToDouble(rectanglelist[0].Height) / 0.5) * ratioafteropen) );
                }
                if (direction == "R"  )
                {
                    rectanglelist[0].Width = Math.Abs(Canvas.GetLeft(canvas) - p.X);
                    resizeWindow.SetManualWidthAndHeight(Math.Round(Convert.ToDouble(rectanglelist[0].Width) / 0.5) * ratioafteropen , Math.Round((Convert.ToDouble(rectanglelist[0].Height) / 0.5) * ratioafteropen) );
                }
                if (direction == "U" && p.Y>5)
                {
                    Canvas.SetTop(rectanglelist[0], p.Y);
                    rectanglelist[0].Height = Math.Abs((Canvas.GetTop(canvas)+ canvas.Height)-p.Y);
                    resizeWindow.SetManualWidthAndHeight(Math.Round(Convert.ToDouble(rectanglelist[0].Width) / 0.5) * ratioafteropen , Math.Round((Convert.ToDouble(rectanglelist[0].Height) / 0.5) * ratioafteropen) );
                }
                if (direction == "D"  )
                {
                    rectanglelist[0].Height = Math.Abs(Canvas.GetTop(canvas) - p.Y);
                    resizeWindow.SetManualWidthAndHeight(Math.Round(Convert.ToDouble(rectanglelist[0].Width) / 0.5) * ratioafteropen , Math.Round((Convert.ToDouble(rectanglelist[0].Height) / 0.5) * ratioafteropen) );
                }
            }
        }
        public void ResizeManualMouseDown(string ActiveControl,Canvas canvas, Canvas Uppercanvas)
        {
           // MessageBox.Show("ej");
            Point p = Mouse.GetPosition(canvas);
            if (ActiveControl == "ResizeManual")
            {
                if ((p.X > 10 && p.X < canvas.Width - 10 && p.Y > 10 && p.Y < canvas.Height - 10))
                {

                }
                else if ((p.Y > canvas.Height - 10 && p.Y < canvas.Height))
                {
                    CreateRectangleWithMouse(Uppercanvas,canvas);
                    direction = "D";
                    
                }
                else if ((p.X > canvas.Width - 10 && p.X < canvas.Width))
                {
                    CreateRectangleWithMouse(Uppercanvas, canvas);
                    direction = "R";
                  
                }
                else if ((p.Y < 10 && p.Y > 0))
                {
                    CreateRectangleWithMouse(Uppercanvas, canvas);
                    direction = "U";
                  
                }
                else if ((p.X < 10 && p.X > 0))
                {
                    CreateRectangleWithMouse(Uppercanvas,canvas);
                    direction = "L";
                   
                }
            }
        }
        public void ResizeManualMouseUp(Canvas uppercanvas, Canvas canvas, ref bool AreProportionsChanged, string activecontrol)
        {
            if (activecontrol == "ResizeManual")
            {
                MouseDown = false;
                try
                {
                    if (direction == "L")
                    {
                        Canvas.SetLeft(canvas, Canvas.GetLeft(rectanglelist[0]));
                        canvas.Width = rectanglelist[0].Width;
                    }
                    if (direction == "R")
                    {
                        canvas.Width = rectanglelist[0].Width;
                    }
                    if (direction == "U")
                    {
                        Canvas.SetTop(canvas, Canvas.GetTop(rectanglelist[0]));
                        canvas.Height = rectanglelist[0].Height;
                    }
                    if (direction == "D")
                    {
                        canvas.Height = rectanglelist[0].Height;
                    }
                    AreProportionsChanged = true;
                    rectanglelist.Clear();
                }
                catch { }
                try
                {
                    PutLineSegmentsToCorners(canvas);
                    uppercanvas.Children.RemoveAt(2);
                }
                catch { }
            }
        }
         

        public void CreateRectangleWithMouse(Canvas uppercanvas, Canvas canvas)
        {
            
      
            Rectangle rec = new Rectangle();
            rec.Stroke = new SolidColorBrush(Colors.Red);
            rec.Width = canvas.Width;
            rec.Height = canvas.Height;
            rec.StrokeThickness = 2;
            rectanglelist.Add(rec);
            uppercanvas.Children.Add(rectanglelist[0]);
            Canvas.SetLeft(rectanglelist[0], Canvas.GetLeft(canvas));
            Canvas.SetTop(rectanglelist[0], Canvas.GetTop(canvas));
            //MessageBox.Show(rectanglelist.Count.ToString());
            MouseDown = true;
        }

        public void PutLineSegmentsToCorners(Canvas canvas)
        {
            ((MainWindow)Application.Current.MainWindow).pathfigure.StartPoint = new Point(0, 0);
            LineSegment linesegment1 = new LineSegment();
            LineSegment linesegment2 = new LineSegment();
            LineSegment linesegment3 = new LineSegment();
            linesegment1.Point = new Point(canvas.Width, 0);
            linesegment2.Point = new Point(canvas.Width, canvas.Height);
            linesegment3.Point = new Point(0, canvas.Height);

            ((MainWindow)Application.Current.MainWindow).segmentColection.Clear();
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment1);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment2);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment3);

        }



        #endregion
    }
}
