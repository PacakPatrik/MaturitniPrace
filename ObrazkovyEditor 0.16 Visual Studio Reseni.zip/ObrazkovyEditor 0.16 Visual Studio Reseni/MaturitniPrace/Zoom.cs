﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Controls;
using System;

namespace MaturitniPrace
{
    class Zoom
    {

        double ScaleRate = 1.05;
        
        ImageBrush Image_brush = new ImageBrush();
        Rectangle zoom_rec = new Rectangle();
        List<BitmapSource> bitmapSources = new List<BitmapSource>();

        public void ZoomOnCanvas(ref Size canvasSizeAfterZoom,ScaleTransform st, Canvas uppercanvas,MouseWheelEventArgs e, Canvas canvas,/*StackPanel stackpanel,*/ref BitmapSource originalImage, double ratio,bool Is_polygon_created,ref double zoom_ratio_Width, ref double zoom_ratio_Height
, ref double zoom_ratio, bool Is_Shape_Added, bool Is_Text_Added, PathSegmentCollection pathsegments,PathFigure figure,ref Size canvas_Zoom_ratio_Size)
        {
            
            if (Is_polygon_created == false && !Is_Shape_Added && !Is_Text_Added)
            {
                if (e.Delta > 0)
                {

                    //if ((canvas.Width < uppercanvas.ActualWidth) && canvas.Height < uppercanvas.ActualHeight)
                    //{
                    //    //MessageBox.Show(String.Format("{0}   {1}", stackpanel.Width, uppercanvas.ActualWidth));
                    //    canvasSizeAfterZoom.Width *= ScaleRate;
                    //    canvasSizeAfterZoom.Height *= ScaleRate;


                    //    // MessageBox.Show(Convert.ToString(stackpanel.Width));
                    //    st.ScaleX *= ScaleRate;
                    //    st.ScaleY *= ScaleRate;

                    //    st.CenterX = 0.1;
                    //    canvas.Width = canvasSizeAfterZoom.Width;
                    //    canvas.Height = canvasSizeAfterZoom.Height;
                    //    if (canvas.Width < ((MainWindow)Application.Current.MainWindow).canvas_Size_On_Open.Width)
                    //    {
                    //        canvas.RenderTransformOrigin = new Point(0, 0);
                    //    }
                    //    else
                    //    {
                    //        canvas.RenderTransformOrigin = new Point(0, 0.5);
                    //    }
                    //        Canvas.SetLeft(canvas, uppercanvas.ActualWidth / 2 - canvas.Width / 2);
                    //        Canvas.SetTop(canvas, uppercanvas.ActualHeight / 2 - canvas.Height / 2);
                    //        ResetLineSegment(canvas, pathsegments, figure);
                    //    }



                    if ((canvas.Width < uppercanvas.ActualWidth-100) && canvas.Height < uppercanvas.ActualHeight-100)
                    {
                        canvas.Height += canvas.Height * 0.1;
                        canvas.Width += canvas.Width * 0.1;

                        Canvas.SetLeft(canvas, uppercanvas.ActualWidth / 2 - canvas.Width / 2);
                        Canvas.SetTop(canvas, uppercanvas.ActualHeight / 2 - canvas.Height/ 2);

                        zoom_ratio_Width = canvas_Zoom_ratio_Size.Width / canvas.Width;
                        zoom_ratio_Height = canvas_Zoom_ratio_Size.Height / canvas.Height;
                        //MessageBox.Show(zoom_ratio_Width.ToString());
                    }

                    // MessageBox.Show(Convert.ToString(st.CenterY));
                    //MatrixTransform matTrans = canvas.RenderTransform as MatrixTransform;
                    //Point pos1 = e.GetPosition(Maingrid);

                    //var scale = e.Delta > 0 ? 1.1 : 1 / 1.1;

                    //Matrix mat = matTrans.Matrix;
                    //mat.ScaleAt(scale, scale, pos1.X, pos1.Y);
                    //matTrans.Matrix = mat;
                    //e.Handled = true;




                    //mousePos = Mouse.GetPosition(canvas);

                    //crop_rectangle.Width = 0;
                    //crop_rectangle.Height = 0;
                    //zoom_rec.Width = canvas.Width / 1.05;
                    //zoom_rec.Height = canvas.Height / 1.05;
                    //if ((mousePos.X > canvas.Width - (zoom_rec.Width / 2)) && (mousePos.Y > canvas.Height - (zoom_rec.Height / 2)))
                    //{
                    //    //Vpravo dole
                    //    // MessageBox.Show("vpravo dole");
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((canvas.Width - zoom_rec.Width) * ratio) / zoom_ratio));
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((canvas.Height - zoom_rec.Height) * ratio) / zoom_ratio));
                    //}
                    //if ((mousePos.X < (zoom_rec.Width / 2)) && (mousePos.Y < (zoom_rec.Height / 2)))
                    //{
                    //    //Vlevo nahoře
                    //    // MessageBox.Show("vlevo nahoře");
                    //    crop_rectangle.X = 0;
                    //    crop_rectangle.Y = 0;
                    //}
                    //if ((mousePos.Y < (zoom_rec.Height / 2)) && (mousePos.X > canvas.Width - (zoom_rec.Width / 2)))
                    //{
                    //    //Vpravo nahoře
                    //    //  MessageBox.Show("vpravo nahoře");
                    //    crop_rectangle.Y = 0;
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((canvas.Width - zoom_rec.Width) * ratio) / zoom_ratio));
                    //}
                    //if ((mousePos.Y > canvas.Height - (zoom_rec.Height / 2)) && (mousePos.X < (zoom_rec.Width / 2)))
                    //{
                    //    //Vlevo dole
                    //    // MessageBox.Show("vlevo dole");
                    //    crop_rectangle.X = 0;
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((canvas.Height - zoom_rec.Height) * ratio) / zoom_ratio));
                    //}
                    //if ((mousePos.X < (zoom_rec.Width / 2)) && mousePos.Y > (zoom_rec.Height / 2) && mousePos.Y < (canvas.Height - (zoom_rec.Height / 2)))
                    //{
                    //    //Vlevo uprostřed
                    //    // MessageBox.Show("vlevo urostřed");
                    //    crop_rectangle.X = 0;
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((mousePos.Y * ratio) - ((zoom_rec.Height / 2) * ratio)) / zoom_ratio));
                    //}
                    //if ((mousePos.X > canvas.Width - (zoom_rec.Width / 2)) && (mousePos.Y > (zoom_rec.Height / 2)) && mousePos.Y < (canvas.Height - (zoom_rec.Height / 2)))
                    //{
                    //    //Vpravo uprostřed
                    //    // MessageBox.Show("vpravo uprostřed");
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((canvas.Width - zoom_rec.Width) * ratio) / zoom_ratio));
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((mousePos.Y * ratio) - ((zoom_rec.Height / 2) * ratio)) / zoom_ratio));
                    //}

                    //if (mousePos.Y < (zoom_rec.Height / 2) && mousePos.X > (zoom_rec.Width / 2) && mousePos.X < canvas.Width - (zoom_rec.Width / 2))
                    //{
                    //    //Nahoře uprostřed
                    //    // MessageBox.Show("nahoře uprostřed");
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((mousePos.X * ratio) - ((zoom_rec.Width / 2) * ratio)) / zoom_ratio));
                    //    crop_rectangle.Y = 0;
                    //}
                    //if (mousePos.Y > canvas.Height - (zoom_rec.Height / 2) && mousePos.X > (zoom_rec.Width / 2) && mousePos.X < canvas.Width - (zoom_rec.Width / 2))
                    //{
                    //    //Dole uprosřed
                    //    // MessageBox.Show("dole uprostřed");
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((mousePos.X * ratio) - ((zoom_rec.Width / 2) * ratio)) / zoom_ratio));
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((canvas.Height - zoom_rec.Height) * ratio) / zoom_ratio)); ;
                    //}

                    //if (mousePos.X > (zoom_rec.Width / 2) && mousePos.X < Math.Abs(canvas.Width - (zoom_rec.Width / 2)) &&
                    //    mousePos.Y > (zoom_rec.Height / 2) && mousePos.Y < Math.Abs(canvas.Height - (zoom_rec.Height / 2)))
                    //{
                    //    //Uprostřed
                    //    // MessageBox.Show("uprostřed");
                    //    crop_rectangle.X = Convert.ToInt32(Math.Abs(((mousePos.X * ratio) - ((zoom_rec.Width / 2) * ratio)) / zoom_ratio));
                    //    crop_rectangle.Y = Convert.ToInt32(Math.Abs(((mousePos.Y * ratio) - ((zoom_rec.Height / 2) * ratio)) / zoom_ratio));
                    //}
                    //if (scrolls > 0)
                    //{
                    //    zoom_ratio = bitmapSources[0].Width / bitmapSources[bitmapSources.Count - 1].Width;
                    //}
                    //if (scrolls < 1)
                    //{

                    //    bitmapSources.Add(originalImage);
                    //    // MessageBox.Show("original image pridan");
                    //}

                    //crop_rectangle.Width = Convert.ToInt32(((zoom_rec.Width * ratio) / zoom_ratio)) - 5;
                    //crop_rectangle.Height = Convert.ToInt32(((zoom_rec.Height * ratio) / zoom_ratio)) - 5;

                    //try
                    //{
                    //    //MessageBox.Show(String.Format("{0} , {1} , {2} , {3}  ,{4} , {5}", crop_rectangle.Width, crop_rectangle.Height,bitmapSources.Count,zoom_rec.Height, bitmapSources[bitmapSources.Count-1].Width,bitmapSources[bitmapSources.Count-1].Height));

                    //    Image_brush.ImageSource = new CroppedBitmap(bitmapSources[bitmapSources.Count - 1], crop_rectangle);
                    //    Image_source = Image_brush.ImageSource;
                    //    originalImage = Image_source as BitmapSource;
                    //    bitmapSources.Add(originalImage);
                    //    canvas.Background = Image_brush;
                    //    scrolls++;

                    //}
                    //catch (Exception exc)
                    //{
                    //    //MessageBox.Show(Convert.ToString(exc));
                    //}
                }
                if (e.Delta < 0)
                {

                    //if (scrolls > 0)
                    //{
                    //    originalImage = bitmapSources[bitmapSources.Count - 2];
                    //    Image_brush.ImageSource = originalImage;
                    //    bitmapSources.RemoveAt(bitmapSources.Count - 1);
                    //    canvas.Background = Image_brush;
                    //    scrolls--;
                    //    MessageBox.Show(Convert.ToString(scrolls));
                    //    MessageBox.Show(String.Format("{0} , {1} , {2} , {3}  ,{4} , {5}", crop_rectangle.Width, crop_rectangle.Height, bitmapSources.Count, zoom_rec.Height, bitmapSources[bitmapSources.Count - 1].Width, bitmapSources[bitmapSources.Count - 1].Height));
                    //}
                    //if (scrolls == 0)
                    //{
                    //    bitmapSources.Clear();
                    //    zoom_ratio = 1;


                    //}


                    //canvasSizeAfterZoom.Width /= ScaleRate;                    
                    //canvasSizeAfterZoom.Height /= ScaleRate;
                    //canvas.Width = canvasSizeAfterZoom.Width;
                    //canvas.Height = canvasSizeAfterZoom.Height;

                    //st.ScaleX /= ScaleRate;
                    //st.ScaleY /= ScaleRate;
                    //if (canvas.Width < ((MainWindow)Application.Current.MainWindow).canvas_Size_On_Open.Width)
                    //{
                    //    canvas.RenderTransformOrigin = new Point(0, 0);
                    //}
                    //else
                    //{
                    //    canvas.RenderTransformOrigin = new Point(0, 0.5);
                    //}
                    //Canvas.SetLeft(canvas, uppercanvas.ActualWidth / 2 - canvas.Width / 2);
                    //Canvas.SetTop(canvas, uppercanvas.ActualHeight / 2 - canvas.Height / 2);
                    //ResetLineSegment(canvas, pathsegments, figure);

                    
                    canvas.Height -= canvas.Height * 0.1;
                    canvas.Width -= canvas.Width * 0.1;
                  
                    Canvas.SetLeft(canvas, uppercanvas.ActualWidth / 2 - canvas.Width / 2);
                    Canvas.SetTop(canvas, uppercanvas.ActualHeight / 2 - canvas.Height/ 2);
                    zoom_ratio_Width = canvas_Zoom_ratio_Size.Width / canvas.Width;
                    zoom_ratio_Height = canvas_Zoom_ratio_Size.Height / canvas.Height;
                }
                ResetLineSegment(canvas, pathsegments, figure);
            }
         

        }
        public void ResetLineSegment(Canvas canvas, PathSegmentCollection pathSegments, PathFigure pathfigure)
        {
            pathSegments.Clear();
            LineSegment linesegment = new LineSegment();
            LineSegment lineSegment2 = new LineSegment();
            LineSegment lineSegment3 = new LineSegment();
            LineSegment linesegment4 = new LineSegment();
            pathfigure.StartPoint = new Point(0, 0);
            lineSegment2.Point = new Point(canvas.Width, 0);
            lineSegment3.Point = new Point(canvas.Width, canvas.Height);
            linesegment4.Point = new Point(0, canvas.Height);
            pathSegments.Add(linesegment);
            pathSegments.Add(lineSegment2);
            pathSegments.Add(lineSegment3);
            pathSegments.Add(linesegment4);
        }

    }
}
