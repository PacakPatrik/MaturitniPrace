﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Markup;

namespace MaturitniPrace
{
    class Selection
    {
        #region Variables
        ImageBrush SelectedIconBrush = new ImageBrush();
        Point End;
        bool Draging;
        double width_of_rectangle, height_of_rectangle, rec_x, rec_y;
        bool draw;
        bool set_points;
        SelectionWindowsWithPoints selection_Windows = new SelectionWindowsWithPoints();
        MouseCreatedRec mouse_created_rec = new MouseCreatedRec();
        TxtBoxRec txt_box_rec = new TxtBoxRec();
        SelectionWindow selectionWindowMenu = new SelectionWindow();

        #endregion
        #region Others
        //Rozbalí menu výběru
        public void MouseDownShowSelectionMenu(Rectangle selectionRectangle, Canvas maincanvas,double ratio,Size original_size,bool pictureuploaded, Size original_size_to_set, ref bool Is_Side_Window_Opened,bool IsGifOpened)
        {
            selectionRectangle.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
           
            if (Is_Side_Window_Opened == false)
            {
                if (!IsGifOpened) { 
                selectionWindowMenu.Visibility = Visibility.Visible;

                    selectionWindowMenu.SetOriginals(Convert.ToString(original_size_to_set.Width), Convert.ToString(original_size_to_set.Height), pictureuploaded);
                    Is_Side_Window_Opened = true;
                }
                else
                {
                    MessageBox.Show("Due to maintaining the ratio of Gif, this option is not available");
                }
                }
            
           
            /*   SelectedIconBrush.ImageSource= new BitmapImage(new Uri("pack://application:,,,/Resources/icons8-fill-color-24.png"));
                SelectedControl.Background = SelectedIconBrush;*/
        }

        //Změní barvu controlu na původní při uvolnění tlačítka myši
        public void MouseUpShowIconMenu(Rectangle selectionRectangle)
        {
            selectionRectangle.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
        //překreslí možnost,která se zrovna používá(selected)
        //public void ReDrawSelectedControlCanvas(Canvas SelectedControl, string path,string ActiveControl,string name)
        //{
        //    if (ActiveControl == name)
        //    {
        //        SelectedIconBrush.ImageSource = new BitmapImage(new Uri(path));
        //        SelectedControl.Background = SelectedIconBrush;
        //    }

        //}
        public void RemoveTxtBoxesOnReset()
        {
          
                selectionWindowMenu.textboxstackpanel.Children.Clear();
                
            
        }
        #endregion

        #region PolygonFormation

        /*Funkce, která kreslí body na obrázek podle umístění myši.*/
        public void DrawPointsToPolygon(Canvas canvas, string ActiveControl, bool pictureUploaded, ref bool EndedPolygon, List<Point> listOfPoints
            , List<Ellipse> listOfElipses, List<Line> listOfLines, ref bool removedpoint, ref bool IsStopped, double ratio)
        {
            Point p = Mouse.GetPosition(canvas);
            if (ActiveControl == "SelectionPolygon" && pictureUploaded == true &&
                p.X > 0 && p.X < canvas.Width && p.Y > 0 && p.Y < canvas.Height && selectionWindowMenu.Visibility == Visibility.Visible)
            {



                if (listOfLines.Count > 0 && listOfLines[listOfLines.Count - 1].X2 < listOfLines[0].X1 + 5 && listOfLines[listOfLines.Count - 1].X2 > listOfLines[0].X1 - 5 &&
                   listOfLines[listOfLines.Count - 1].Y2 < listOfLines[0].Y1 + 5 && listOfLines[listOfLines.Count - 1].Y2 > listOfLines[0].Y1 - 5)
                {
                    draw = false;
                    EndedPolygon = true;
                    removedpoint = false;
                }
                else
                {
                    if (IsStopped == false && removedpoint == false && listOfPoints.Count > 0 && p.X > Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) - 5 && p.X < Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) + 5 &&
                       p.Y > Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) - 5 && p.Y < Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) + 5)
                    {
                        draw = false;
                        IsStopped = true;
                        canvas.Children.RemoveAt(canvas.Children.Count - 1);
                    }


                    else if (removedpoint == false && IsStopped == false)
                    {
                        draw = true;
                        listOfPoints.Add(p);
                        Ellipse ellipse = new Ellipse();
                        
                        Line line = new Line();
                        line.Stroke = new SolidColorBrush(Colors.Yellow);
                        line.X1 = listOfPoints[listOfPoints.Count - 1].X;
                        line.Y1 = listOfPoints[listOfPoints.Count - 1].Y;
                        line.X2 = line.X1;
                        line.Y2 = line.Y1;
                        ellipse.Width = 5;
                        ellipse.Height = 5;
                        ellipse.Fill = new SolidColorBrush(Colors.Orange);
                        listOfElipses.Add(ellipse);
                        listOfLines.Add(line);
                        Canvas.SetLeft(ellipse, listOfPoints[listOfPoints.Count - 1].X - 2);
                        Canvas.SetTop(ellipse, listOfPoints[listOfPoints.Count - 1].Y - 2);
                        canvas.Children.Add(ellipse);
                        canvas.Children.Add(line);
                        TextBlock textBox = new TextBlock();
                        textBox.Width = 100;
                        textBox.Text = Convert.ToString(String.Format("{0};{1}", Math.Round(listOfPoints[listOfPoints.Count - 1].X) * ratio, Math.Round(listOfPoints[listOfPoints.Count - 1].Y) * ratio));
                        selectionWindowMenu.textboxstackpanel.Children.Add(textBox);

                    }


                    else if (removedpoint == true && p.X > Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) - 5 && p.X < Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) + 5 &&
                        p.Y > Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) - 5 && p.Y < Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) + 5 || IsStopped == true)
                    {
                        draw = true;
                        Line line = new Line();
                        line.Stroke = new SolidColorBrush(Colors.Yellow);
                        line.X1 = listOfPoints[listOfPoints.Count - 1].X;
                        line.Y1 = listOfPoints[listOfPoints.Count - 1].Y;
                        line.X2 = line.X1;
                        line.Y2 = line.Y1;
                        listOfLines.Add(line);
                        canvas.Children.Add(line);
                        removedpoint = false;
                        IsStopped = false;
                    }

                }


            }

        }
        //Funkce, která vytváří čáry, které následují kursor uživatele
        public void DrawLineToPolygon(Canvas canvas, string ActiveControl, bool pictureUploaded, List<Line> listOfLines)
        {
            if (ActiveControl == "SelectionPolygon" && listOfLines.Count > 0 && draw == true && pictureUploaded == true)
            {

                listOfLines[listOfLines.Count - 1].X2 = Mouse.GetPosition(canvas).X;
                listOfLines[listOfLines.Count - 1].Y2 = Mouse.GetPosition(canvas).Y;
            }
        }
        //otevře okno výběru korespondující s volným výběre
       /* public void ShowSelectionWindowWithPoints(int count,ref bool isopened)
        {

            if (selection_Windows == null)
            {
                selection_Windows.Show();
                isopened = true;
            }
            else
            {

                foreach (Window window in Application.Current.Windows)
                {
                    if (window.Visibility == Visibility.Visible)
                    {
                        count++;
                    }

                }
                if (count < 3)
                {
                    selection_Windows.Visibility = Visibility.Visible;
                    isopened = true;
                }
            }
        }*/

        //Udělá bod větší, když přes něj uživatel přejede myší
        public void MakeEllipseBigger(Canvas canvas, string ActiveControl, bool pictureUploaded, List<Ellipse> listOfellipses, List<Line> listOfLines, bool removedpoint)
        {
            if (ActiveControl == "SelectionPolygon" && listOfLines.Count > 0 && pictureUploaded == true)
            {
                Point pos = Mouse.GetPosition(canvas);
                try
                {
                    if (pos.X > Canvas.GetLeft(listOfellipses[listOfellipses.Count - 1]) - 5 && pos.X < Canvas.GetLeft(listOfellipses[listOfellipses.Count - 1]) + 5 &&
                        pos.Y > Canvas.GetTop(listOfellipses[listOfellipses.Count - 1]) - 5 && pos.Y < Canvas.GetTop(listOfellipses[listOfellipses.Count - 1]) + 5)
                    {
                        /*Canvas.SetTop(listOfellipses[listOfellipses.Count - 1], Canvas.GetTop(listOfellipses[listOfellipses.Count - 1]) - 1);
                        Canvas.SetLeft(listOfellipses[listOfellipses.Count - 1], Canvas.GetLeft(listOfellipses[listOfellipses.Count - 1]) - 1);*/
                        listOfellipses[listOfellipses.Count - 1].Width = 10;
                        listOfellipses[listOfellipses.Count - 1].Height = 10;
                    }
                    else
                    {
                        listOfellipses[listOfellipses.Count - 1].Width = 5;
                        listOfellipses[listOfellipses.Count - 1].Height = 5;
                    }
                }
                catch { MessageBox.Show("chyba");  }
            }
        }

        public void SetLabelWMouseCoordinates(Canvas canvas,string activecontrol,double ratioafteropening,double resizeWith,double resizeHeight)
        {
            if (activecontrol == "SelectionPolygon")
            {
                Point p = Mouse.GetPosition(canvas);
                selectionWindowMenu.SetMouseCoordinates(p.X , p.Y);
            }
        }
        #endregion

        #region MouseRecFormation

        //Vytvoří původní bod, z kterého potom plyne zbytek čtverce
        public void StartRecWithMouse(Canvas canvas, List<Point> listofpoints, string activecontrol, List<Rectangle> listofrectangles, bool pictureuploaded, double ratioafteropen,double ratioafterresize)
        {
            Point p = Mouse.GetPosition(canvas);
            if (activecontrol == "SelectionMouse" && p.X > 0 && p.X < canvas.Width && p.Y > 0 && p.Y < canvas.Height && pictureuploaded == true && selectionWindowMenu.Visibility == Visibility.Visible)
            {
                set_points = true;
                if (listofrectangles.Count > 0)
                {

                    canvas.Children.Remove(listofrectangles[listofrectangles.Count - 1]);
                    listofrectangles.Clear();
                }
                Draging = true;
                Point Start = Mouse.GetPosition(canvas);
                End = Mouse.GetPosition(canvas);
                listofpoints.Add(Start);
                Rectangle rectangle = new Rectangle();
                rectangle.Stroke = new SolidColorBrush(Colors.Yellow);
                rectangle.Width = 0;
                rectangle.Height = 0;

                listofrectangles.Add(rectangle);
                canvas.Children.Add(rectangle);
                Canvas.SetLeft(rectangle, Math.Min(Start.X, End.X));
                Canvas.SetTop(rectangle, Math.Min(Start.Y, End.Y));
                selectionWindowMenu.PassValuesIntoTxtBoxes(Math.Round(((Math.Min(Start.X, End.X)) * ratioafteropen)/ratioafterresize), Math.Round(((Math.Min(Start.Y, End.Y)) * ratioafteropen)/ratioafterresize), 0, 0, set_points);
               
            }
        }
        //Formuje čtverec podle pohybu myši na obrázku
        public void FormRecWhileMovingMouse(Canvas canvas, string activecontrol, List<Rectangle> listofrectangles, List<Point> listofpoints, double ratioafteropen,double ratioafterresize,ref Size ResizeCanvasSize)
        {
            Point p = Mouse.GetPosition(canvas);

            if (activecontrol == "SelectionMouse" && listofrectangles.Count > 0 && Draging == true && p.X > 0 && p.X < canvas.Width && p.Y > 0 && p.Y < canvas.Height)
            {
                set_points = false;
                End = Mouse.GetPosition(canvas);
                rec_x = Math.Min(End.X, listofpoints[listofpoints.Count - 1].X);
                rec_y = Math.Min(End.Y, listofpoints[listofpoints.Count - 1].Y);
                width_of_rectangle = Math.Max(End.X, listofpoints[listofpoints.Count - 1].X) - rec_x;
                height_of_rectangle = Math.Max(End.Y, listofpoints[listofpoints.Count - 1].Y) - rec_y;
                listofrectangles[listofrectangles.Count - 1].Width = width_of_rectangle;
                listofrectangles[listofrectangles.Count - 1].Height = height_of_rectangle;
                Canvas.SetLeft(listofrectangles[listofrectangles.Count - 1], rec_x);
                Canvas.SetTop(listofrectangles[listofrectangles.Count - 1], rec_y);
                selectionWindowMenu.PassValuesIntoTxtBoxes((rec_x * ratioafteropen)/ratioafterresize, (rec_y * ratioafteropen)/ratioafterresize, Math.Round(((listofrectangles[listofrectangles.Count - 1].Width) * ratioafteropen)/ratioafterresize), Math.Round(((listofrectangles[listofrectangles.Count - 1].Height) * ratioafteropen)/ratioafterresize), set_points);
            }

        }
        //Ukončí formování čtverce
        public void EndFormingRec()
        {
            Draging = false;
        }
        //Otevře okno výběru korespondující s výberem čtvercem pomocí myší
        public void ShowMouseRecWindow(int count,ref bool isopened)
        {

            if (mouse_created_rec == null)
            {
                mouse_created_rec.Show();
                isopened = true;
            }
            else
            {
                foreach (Window window in Application.Current.Windows)
                {
                    if (window.Visibility == Visibility.Visible)
                    {
                        count++;
                    }

                }
                if (count < 3)
                {
                    mouse_created_rec.Visibility = Visibility.Visible;
                    isopened = true;
                }
            }
        }
        #endregion

        #region TxtBoxRecFormation
        //Přejmenuje promněnou Active_Control, kteroá udává aktuálně používanou možnost
        public void RenameActiveControl(ref string ActiveControl, string name,bool Isopened1,bool Isopened2)
        {
            if(Isopened1==false && Isopened2==false)
                ActiveControl = name;


        }
        //otevře okno výběru korespondující s výberem pomocí číselného údaje
        public void ShowTxtBoxRec(int count,ref bool isopened)
        {
            if (txt_box_rec == null)
            {
                txt_box_rec.Show();
                isopened = true;
            }
            else
            {
                foreach (Window window in Application.Current.Windows)
                {
                    if (window.Visibility == Visibility.Visible)
                    {
                        count++;
                    }

                }
                if (count < 3)
                {
                    txt_box_rec.Visibility = Visibility.Visible;
                    isopened = true;
                }
            }
        }
        #endregion
      
    }
}
