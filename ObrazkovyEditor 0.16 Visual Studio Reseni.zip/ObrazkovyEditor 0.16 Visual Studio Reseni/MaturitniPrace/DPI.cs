﻿using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Input;
using System.Windows.Documents;
using System.Collections.Generic;

namespace MaturitniPrace
{
    class DPI
    {
       
        List<BitmapImage> list_Of_Previous_Images = new List<BitmapImage>();
        ImageBrush brush=new ImageBrush();
        DPIWindow dpiWindow = new DPIWindow();
        public void ShowDpiMenu(Rectangle rec,ref bool IsWindowOpened)
        {
            if (!IsWindowOpened)
            {
                rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
                dpiWindow.Visibility = Visibility.Visible;
                IsWindowOpened = true;
            }
            else
            {

            }
        }
        public void LightenTheButton(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
        
        
        
        
        
        
     

    }
}
