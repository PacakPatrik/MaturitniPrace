﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Media.TextFormatting;
using System.IO;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro AddTextWindow.xaml
    /// </summary>
    public partial class AddTextWindow : Window
    {

        ColorSelector colorselect = new ColorSelector();
        int[] fontSizeArrays = new int[] { 8,9,11,13,14,15,16,18,20,24,26,30,32,34,36,42,48,52,56,60,68,72,84 };
        string[] fontweights = new string[] {"Regular","Bold","DemiBold","ExtraBold","ExtraLight" };
        string fontSize, fontFamily, writtenText;
        ImageBrush imageBrush2=new ImageBrush();
        ImageBrush imageBrush=new ImageBrush();
        BitmapImage bitmapimage=new BitmapImage();
        public List<TextBlock> list_of_Texts = new List<TextBlock>();
        Brush brush;
        public bool drag;
        string selected="Regular";
       
        bool converted;
        public AddTextWindow()
        {
            InitializeComponent();
            fontComboBox.ItemsSource = fontSizeArrays;
            FontWeightComboBox.ItemsSource = fontweights;
            fontSize = "8";
            fontFamily = "Calibri";
            writtenText = "Text";
            SelectedColor.Fill=new SolidColorBrush(Colors.Black);
        }

       

        private void SelectColor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            colorselect.Visibility = Visibility.Visible;
            
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

     

        private void FontStyles_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            fontFamily = FontStyles.SelectedItem.ToString();
            list_of_Texts[0].FontFamily = new FontFamily(fontFamily);
        }

        private void AddButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            
            ((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image = true;
            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
            imageBrush2 = (ImageBrush)brush;
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)imageBrush2.ImageSource.Width, (int)imageBrush2.ImageSource.Height, 96, 96, PixelFormats.Pbgra32);
            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();
            drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));

            FormattedText formatedtext = new FormattedText(writtenText, System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, new Typeface(fontFamily), Convert.ToInt32(fontSize) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width, SelectedColor.Fill);

            if (selected == "Bold")
            {

                formatedtext.SetFontWeight(FontWeights.Bold);
            }

            if (selected == "DemiBold")
            {

                formatedtext.SetFontWeight(FontWeights.DemiBold);
            }
            if (selected == "ExtraBold")
            {

                formatedtext.SetFontWeight(FontWeights.ExtraBold);
            }
            if (selected == "ExtraLight")
            {

                formatedtext.SetFontWeight(FontWeights.ExtraLight);
            }
            if (selected == "Regular")
            {

                formatedtext.SetFontWeight(FontWeights.Regular);
            }

            drawingContext.DrawText(formatedtext,new Point(Canvas.GetLeft(list_of_Texts[0]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                Canvas.GetTop(list_of_Texts[0]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height));
            drawingContext.Close();
            bitmap.Render(drawingVisual);
            imageBrush.ImageSource = bitmap;

            if (!converted)
            {
                var bitmapEncoder = new PngBitmapEncoder();
                bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                using (var stream = new MemoryStream())
                {
                    bitmapEncoder.Save(stream);
                    stream.Seek(0, SeekOrigin.Begin);

                    bitmapimage.BeginInit();
                    bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapimage.StreamSource = stream;
                    bitmapimage.EndInit();

                }

                imageBrush.ImageSource = bitmapimage;
                converted = true;
            }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            list_of_Texts.Clear();
        }

        private void CloseButton_PreviewMouseDown_1(object sender, MouseButtonEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            ((MainWindow)Application.Current.MainWindow).Is_Text_Added = false;
            ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
        }

        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

            if (this.Visibility == Visibility.Visible)
            {
                TextBlock textblock = new TextBlock();
                list_of_Texts.Add(textblock);
                list_of_Texts[0].MouseDown += Textblock_MouseDown;
              
                fontSize = "20";
                fontFamily = "Calibri";
                writtenText = "Text";
                list_of_Texts[0].Text = "Text";
                list_of_Texts[0].FontSize = 20;
                list_of_Texts[0].FontFamily = new FontFamily("Calibri");
             
                if (((MainWindow)Application.Current.MainWindow) != null)
                {
                    ((MainWindow)Application.Current.MainWindow).Is_Text_Added = true;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(list_of_Texts[0]);

                    Canvas.SetLeft(list_of_Texts[0], ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2 - list_of_Texts[0].ActualWidth / 2);
                    Canvas.SetTop(list_of_Texts[0], ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2 - list_of_Texts[0].ActualHeight / 2);
                }
                list_of_Texts[0].Text = "Text";

                list_of_Texts[0].FontFamily = new FontFamily("Calibri");
            }
            else
            {

            }
        }

      

       

        private void Textblock_MouseDown(object sender, MouseButtonEventArgs e)
        {
           
            drag = true;
        }

        private void FontWeightComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           selected = FontWeightComboBox.SelectedItem.ToString();
            if (selected == "Bold")
            {

                list_of_Texts[0].FontWeight = FontWeights.Bold;
            }

                if (selected == "DemiBold") {

                list_of_Texts[0].FontWeight = FontWeights.DemiBold;
                }
                if (selected == "ExtraBold")
                {

                list_of_Texts[0].FontWeight = FontWeights.ExtraBold;
                }
                if (selected == "ExtraLight")
                {

                list_of_Texts[0].FontWeight = FontWeights.ExtraLight;
                }
                if (selected == "Regular")
                {

                list_of_Texts[0].FontWeight = FontWeights.Regular;
                }
            

        }

        private void fontComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            fontSize = fontComboBox.SelectedItem.ToString();
            list_of_Texts[0].FontSize = Convert.ToDouble(fontSize);
        }

        private void WrittenText_TextChanged(object sender, TextChangedEventArgs e)
        {
            writtenText = WrittenText.Text;
            list_of_Texts[0].Text = writtenText;
        }
    }
}
