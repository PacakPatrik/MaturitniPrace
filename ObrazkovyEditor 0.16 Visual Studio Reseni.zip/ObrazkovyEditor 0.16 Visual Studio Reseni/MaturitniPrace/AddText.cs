﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Input;

namespace MaturitniPrace
{
    class AddText
    {
        Point p;
        AddTextWindow addTextWindow = new AddTextWindow();
        public void ShowAddTextMenu(Rectangle rec, Canvas mainpicture,ref bool sidewindowopened,bool istextadded)
        {
            if (!sidewindowopened)
            {
                addTextWindow.Visibility = Visibility.Visible;
                rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
                sidewindowopened = true;
                istextadded = true;
            }

        }
        public void ReleaseMouseOnIcon(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
      public void MoveText(bool Is_Text_Added,Canvas mainpicture)
        {
            if (Is_Text_Added)
            {
                p = Mouse.GetPosition(mainpicture);
                if (((AddTextWindow)Application.Current.Windows[1]).drag)
                {
                    Canvas.SetLeft(((AddTextWindow)Application.Current.Windows[1]).list_of_Texts[0], p.X - ((AddTextWindow)Application.Current.Windows[1]).list_of_Texts[0].ActualWidth);
                    Canvas.SetTop(((AddTextWindow)Application.Current.Windows[1]).list_of_Texts[0], p.Y - ((AddTextWindow)Application.Current.Windows[1]).list_of_Texts[0].ActualHeight);
                }
            }
        }
        public void ReleaseText()
        {
            ((AddTextWindow)Application.Current.Windows[1]).drag = false;
        }
    }
}
