﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Controls;

namespace MaturitniPrace
{

    class GraphicFilters
    {
        FilterWindow filterWindow = new FilterWindow();
        public void ShowFilterWindow(Rectangle rec, ref bool is_side_windows_opened,Canvas mainpicture,ref Rectangle LeftFilterRectangle,ref Rectangle RightFilterRectangle,ref bool Are_Rectangles_Added)
        {
            filterWindow.Visibility = System.Windows.Visibility.Visible;
            rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
            is_side_windows_opened = true;
            Rectangle filter1 = new Rectangle();
            Rectangle filter2 = new Rectangle();
            filter1.Fill = new SolidColorBrush(Colors.Black);
            filter1.Opacity = 0.5;
            filter2.Fill = new SolidColorBrush(Colors.White);
            filter2.Opacity = 0.5;
            Are_Rectangles_Added = false;
            LeftFilterRectangle = filter1;
            RightFilterRectangle = filter2;
            if (((SelectionWindow)Application.Current.Windows[32]).Visibility != Visibility.Visible)
            {


                mainpicture.Children.Add(filter1);
                mainpicture.Children.Add(filter2);

                filter1.Width = mainpicture.Width;
                filter1.Height = mainpicture.Height;
               
                Canvas.SetLeft(filter1, 0);
                Canvas.SetTop(filter1, 0);

                filter2.Width = mainpicture.Width;
                filter2.Height = mainpicture.Height;
               
                Canvas.SetLeft(filter2, 0);
                Canvas.SetTop(filter2, 0);
                Are_Rectangles_Added = true;
            }

        }
        public void FilterIconMouseUp(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }

        public void GetPointsForFilters(Canvas mainpicture, bool endedpolygon, List<Point> listofpoints, ref Polygon filterpolygon1,ref Polygon filterpolygon2, List<Rectangle> listofrectangles,ref bool Are_Rectangles_Added,ref Rectangle LeftFilterRectangle,
            ref Rectangle RightFilterRectangle)
        {
           // MessageBox.Show("hej");
            if (endedpolygon && filterWindow.Visibility==Visibility.Visible)
            {
               // mainpicture.Children.Clear();
                Polygon polygon = new Polygon();
                Polygon polygon2 = new Polygon();
                for (int i = 0; i < listofpoints.Count; i++)
                {
                    polygon.Points.Add(listofpoints[i]);
                    polygon2.Points.Add(listofpoints[i]);
                }
                polygon.Fill = filterWindow.LeftFilter.Fill;
                polygon2.Fill = filterWindow.RightFilter.Fill;
                filterpolygon1 = polygon;
                filterpolygon2 = polygon2;
                filterpolygon1.Opacity = 0.5;
                filterpolygon2.Opacity = 0.5;
                mainpicture.Children.Add(filterpolygon1);
                mainpicture.Children.Add(filterpolygon2);
                

            }
            if (filterWindow.Visibility == Visibility.Visible /*&& listofrectangles.Count > 0*/)
            {
               // MessageBox.Show(listofrectangles.Count.ToString());
                double x, y;
                if (!Are_Rectangles_Added)
                {
                    
                    mainpicture.Children.Add(LeftFilterRectangle);
                    mainpicture.Children.Add(RightFilterRectangle);
                    Are_Rectangles_Added = true;
                }

                
                x = Canvas.GetLeft(listofrectangles[listofrectangles.Count - 1]);
                y = Canvas.GetTop(listofrectangles[listofrectangles.Count - 1]);

               LeftFilterRectangle.Height = listofrectangles[listofrectangles.Count - 1].Height;
               LeftFilterRectangle.Width = listofrectangles[listofrectangles.Count - 1].Width;

                RightFilterRectangle.Width = listofrectangles[listofrectangles.Count - 1].Width;
              RightFilterRectangle.Height = listofrectangles[listofrectangles.Count - 1].Height;



                Canvas.SetLeft(LeftFilterRectangle, x);
                Canvas.SetTop(LeftFilterRectangle, y);

                Canvas.SetLeft(RightFilterRectangle, x);
                Canvas.SetTop(RightFilterRectangle, y);
                listofrectangles.Clear();

            }

        }
    }
}
