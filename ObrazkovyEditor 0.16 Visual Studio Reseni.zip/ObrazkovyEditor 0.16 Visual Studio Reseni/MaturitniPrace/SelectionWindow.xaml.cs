﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro SelectionWindow.xaml
    /// </summary>
 
    public partial class SelectionWindow : Window
    {
        #region Variables
        Point start_point;
        Size rec_size;
        ResizeWindow resizeWin = new ResizeWindow();
        FillColor fillcolor = new FillColor();
        GraphicFilters graphicFilters = new GraphicFilters();
        #endregion
        public SelectionWindow()
        {
            InitializeComponent();
        }

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {
                this.Visibility = Visibility.Hidden;
                ClickMouseOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0;
                ClickPolygonOpacityRec.Opacity = 0;
                PolygonOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                MouseOpacityRec.Visibility = Visibility.Visible;
                TxtX.Text = "0";
                TxtY.Text = "0";
                TxTWidth.Text = "0";
                TxTHeight.Text = "0";
                textboxstackpanel.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Lines.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();

                PointYTxt.IsEnabled = false;
                PointXTxt.IsEnabled = false;
                WidthTxt.IsEnabled = false;
                HeightTxtx.IsEnabled = false;

                ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
                ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = false;
                ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
            }
            else { this.Visibility = Visibility.Hidden;
                ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
                  }
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch { }
        }

       

        private void PolygonOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
           
        
                MouseOpacityRec.Opacity = 0;
                TextBoxOpacityRec.Opacity = 0;
                PolygonOpacityRec.Opacity = 0.2;
            
        }

        private void MouseOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
           
              
         
                MouseOpacityRec.Opacity = 0.2;
                TextBoxOpacityRec.Opacity = 0;
                PolygonOpacityRec.Opacity = 0;
            
        }

        private void TextBoxOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            
               
        
                MouseOpacityRec.Opacity = 0;
                TextBoxOpacityRec.Opacity = 0.2;
                PolygonOpacityRec.Opacity = 0;
            
            }

        private void PolygonOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {
                ResetMouseSelection();
                ResetTxtBoxSelection();
                ClickMouseOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0;
                ClickPolygonOpacityRec.Opacity = 0.5;
                PolygonOpacityRec.Visibility = Visibility.Hidden;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                MouseOpacityRec.Visibility = Visibility.Visible;
                ((MainWindow)Application.Current.MainWindow).active_Control = "SelectionPolygon";
                ((MainWindow)Application.Current.MainWindow).Are_Rectangles_Added=false;

                PointYTxt.IsEnabled = false;
                PointXTxt.IsEnabled = false;
                WidthTxt.IsEnabled = false;
                HeightTxtx.IsEnabled = false;
            }
        }

        private void MouseOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {
                ResetPolygonSelection();
                ResetTxtBoxSelection();
                ClickMouseOpacityRec.Opacity = 0.5;
                ClickTextBoxOpacityRec.Opacity = 0;
                ClickPolygonOpacityRec.Opacity = 0;
                PolygonOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                MouseOpacityRec.Visibility = Visibility.Hidden;
                ((MainWindow)Application.Current.MainWindow).active_Control = "SelectionMouse";

                PointYTxt.IsEnabled = false;
                PointXTxt.IsEnabled = false;
                WidthTxt.IsEnabled = false;
                HeightTxtx.IsEnabled = false;
            }
        }

        private void TextBoxOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {
                ResetPolygonSelection();
                ResetMouseSelection();
                ClickMouseOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0.5;
                ClickPolygonOpacityRec.Opacity = 0;
                PolygonOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Hidden;
                MouseOpacityRec.Visibility = Visibility.Visible;
                ((MainWindow)Application.Current.MainWindow).active_Control = "SelectionTxtBox";

                PointYTxt.IsEnabled = true;
                PointXTxt.IsEnabled = true;
                WidthTxt.IsEnabled = false;
                HeightTxtx.IsEnabled = false;
            }
        }
        
        private void Removebutton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).list_Of_Points.Count > 1)
            {
                if (((MainWindow)Application.Current.MainWindow).Ended_Polygon == true)
                {

               
                    if (((MainWindow)Application.Current.MainWindow).Is_Polygon_Filled_With_Color)
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                        ((MainWindow)Application.Current.MainWindow).list_Of_Lines.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Lines.Count - 1);
                        ((MainWindow)Application.Current.MainWindow).Is_Polygon_Filled_With_Color = false;
                        ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
                    }
                    else
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                        ((MainWindow)Application.Current.MainWindow).list_Of_Lines.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Lines.Count - 1);
                        ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
                    }
                }
                else
                {
                    for (int i = 0; i < 2; i++)
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                    }
                    ((MainWindow)Application.Current.MainWindow).list_Of_Lines.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Lines.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Points.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Points.Count - 1);
                    textboxstackpanel.Children.RemoveAt(textboxstackpanel.Children.Count - 1);
                }

          ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = true;
                
            }
        }
        #region TxtBoxChanges
        private void PointXTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (PointXTxt.Text == "") { }
            else if (Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < ((MainWindow)Application.Current.MainWindow).MainPicture.Width &&
               Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0 && PointXTxt.Text != "")
            {
                start_point.X = Convert.ToInt32(PointXTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize;

                if (((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count < 1)
                {
                    Ellipse ellipse = new Ellipse();
                    ellipse.Height = 5;
                    ellipse.Width = 5;
                    ellipse.Fill = new SolidColorBrush(Colors.Orange);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(ellipse);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Add(ellipse);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.X);
                }
                else
                {
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.X);
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                    {
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.X);
                    }
                }
                if (PointXTxt.Text != "" && PointYTxt.Text != "")
                {
                    WidthTxt.IsEnabled = true;
                    HeightTxtx.IsEnabled = true;
                }
            }
        }

        private void PointYTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
          if (PointYTxt.Text == "") { }
          else if (Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < ((MainWindow)Application.Current.MainWindow).MainPicture.Height &&
                     Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0)
               {
                start_point.Y = Convert.ToInt32(PointYTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize;


                 if (((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count < 1)
                 {
                    Ellipse ellipse = new Ellipse();
                    ellipse.Height = 5;
                    ellipse.Width = 5;
                    ellipse.Fill = new SolidColorBrush(Colors.Orange);
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(ellipse);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Add(ellipse);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.Y);
                 }
                 else
                 {
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1], start_point.Y);
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                    {
                        Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                    }
                 }
                 if(PointXTxt.Text!="" && PointYTxt.Text != "")
                 {
                    WidthTxt.IsEnabled = true;
                     HeightTxtx.IsEnabled = true;
                 }
               }
        }

        private void WidthTxt_TextChanged(object sender, TextChangedEventArgs e)
        {
            
                if (WidthTxt.Text == "")
                {

                }
               
                else if (Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < Math.Abs(start_point.X - ((MainWindow)Application.Current.MainWindow).MainPicture.Width) &&
                    Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0)
                rec_size.Width = Convert.ToInt32(WidthTxt.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize;
            {
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count < 1)
                    {

                        Rectangle rec = new Rectangle();
                        rec.Width = rec_size.Width;
                        rec.Height = 1;
                        rec.Stroke = new SolidColorBrush(Colors.Yellow);
                        ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Add(rec);
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rec);
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.X);
                        Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                        ((MainWindow)Application.Current.MainWindow).TxtBox_Rec_Size.Width = Convert.ToDouble(TxTWidth.Text);
                        
                    }
                    else
                    {
                        ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1].Width = rec_size.Width;
                      
                    }
                 }
            
        }

        private void HeightTxtx_TextChanged(object sender, TextChangedEventArgs e)
        {
           
                if (HeightTxtx.Text == "")
                {

                }
                else if (Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening < Math.Abs(start_point.Y - ((MainWindow)Application.Current.MainWindow).MainPicture.Height) &&
                    Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening > 0)
                {
                    rec_size.Height = Convert.ToInt32(HeightTxtx.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize;
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count < 1)
                    {
                        Rectangle rec = new Rectangle();
                        rec.Height = rec_size.Height;
                        rec.Width = 1;
                        rec.Stroke = new SolidColorBrush(Colors.Yellow);
                        ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Add(rec);
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rec);
                        Canvas.SetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.Y);
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1], start_point.X);
                        ((MainWindow)Application.Current.MainWindow).TxtBox_Rec_Size.Height = Convert.ToDouble(TxTHeight.Text);
                   
                    }

                    else
                    {
                        ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1].Height = rec_size.Height;
                  
                }
                }
            }
        
        #endregion
        #region Resets
        public void ResetPolygonSelection()
        {
            try
            {
                for (int i = (textboxstackpanel.Children.Count - 1); i > -1; i--)
                {
                    textboxstackpanel.Children.RemoveAt(i);

                }
                for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j > -1; j--)
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
                }
             ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = false;
                ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
                ((MainWindow)Application.Current.MainWindow).Is_Stopped_Before_Ending = false;
                ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Lines.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
                ((MainWindow)Application.Current.MainWindow).active_Control = "";
                ((MainWindow)Application.Current.MainWindow).count = 0;
                ((MainWindow)Application.Current.MainWindow).Is_SelectionPolygon_Open = false;
            }
            catch { }
            }
        public void ResetMouseSelection()
        {
            try
            {
                for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j > -1; j--)
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
                }
             ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Clear();
                TxtX.Text = "0";
                TxtY.Text = "0";
                TxTWidth.Text = "0";
                TxTHeight.Text = "0";

                ((MainWindow)Application.Current.MainWindow).active_Control = "";
                ((MainWindow)Application.Current.MainWindow).count = 0;
                ((MainWindow)Application.Current.MainWindow).Is_MouseRec_Open = false;
            }
            catch { }
            }
        public void ResetTxtBoxSelection()
        {
            try {
                PointXTxt.Text = "";
                PointYTxt.Text = "";
                WidthTxt.Text = "";
                HeightTxtx.Text = "";
                ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Clear();
                for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j > -1; j--)
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
                }

            ((MainWindow)Application.Current.MainWindow).active_Control = "";
                ((MainWindow)Application.Current.MainWindow).count = 0;



            }
            catch { }
            }
        #endregion
        public void PassValuesIntoTxtBoxes(double X, double Y, double width, double height, bool set_points)
        {
            if (set_points == true)
            {
                TxtX.Text = Convert.ToString(X);
                TxtY.Text = Convert.ToString(Y);
            }
            TxTWidth.Text = Convert.ToString(width);
            TxTHeight.Text = Convert.ToString(height);
            ((MainWindow)Application.Current.MainWindow).Mouse_Rec_Size.Width = Convert.ToDouble(TxTWidth.Text);
            ((MainWindow)Application.Current.MainWindow).Mouse_Rec_Size.Height = Convert.ToDouble(TxTHeight.Text);

        }
        public void SetMouseCoordinates(double x,double y)
        {
            MouseCoordinates.Content = Convert.ToString(String.Format("{0};{1}", Math.Round(Convert.ToDouble(x*((MainWindow)Application.Current.MainWindow).ratio_After_Opening/** ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width*/* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width)),
                Math.Round(Convert.ToDouble(y*((MainWindow)Application.Current.MainWindow).ratio_After_Opening) /** ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height*/* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height)));
        }
        public void SetOriginals(string Owidth,string Oheight,bool pictureuploaded)
        {
            if (pictureuploaded) {
                OriginalWidth.Text = Owidth;
                OriginalHeight.Text = Oheight;
            }
            else
            {
                OriginalWidth.Text = "0";
                OriginalHeight.Text = "0";
                TxtY.Text = "0";
                TxtX.Text = "0";
                TxTWidth.Text = "0";
                TxTHeight.Text = "0";
            }
        }
        public void RemoverStackpanelTextboxes()
        {
            textboxstackpanel.Children.Clear();
        }

     

    }
}
