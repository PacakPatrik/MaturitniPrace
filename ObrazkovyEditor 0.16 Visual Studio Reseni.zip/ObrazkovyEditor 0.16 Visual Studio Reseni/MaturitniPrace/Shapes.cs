﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Controls;
using System;

namespace MaturitniPrace
{
    class Shapes
    {
      
        ShapesWindows shapesWindows = new ShapesWindows();
        bool drag=false;
        Point p;

    
        public void ShowShapeMenu(Rectangle rec,ref bool Is_Side_Window_Opened)
        {
            if (!Is_Side_Window_Opened)
            {
                shapesWindows.Visibility = Visibility.Visible;
                rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
                Is_Side_Window_Opened = true;
                
            }
        }
        public void LightenTheRectangle(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }

        public void HighlightTheShape(Canvas mainpicture, bool Is_Shape_Added, List<Shape> listofshapes)
        {
            p = Mouse.GetPosition(mainpicture);
            if (Is_Shape_Added == true)
            {
                listofshapes[listofshapes.Count - 1].MouseMove += Shapes_MouseMove;
                listofshapes[listofshapes.Count - 1].MouseLeave += Shapes_MouseLeave;
                listofshapes[listofshapes.Count - 1].MouseDown += Shapes_MouseDown;
                listofshapes[listofshapes.Count - 1].MouseUp += Shapes_MouseUp;
                listofshapes[listofshapes.Count - 1].MouseWheel += Shapes_MouseWheel;
            }
            if (drag)
            {
                Canvas.SetLeft(listofshapes[listofshapes.Count - 1],p.X-listofshapes[listofshapes.Count - 1].ActualWidth/2);
                Canvas.SetTop(listofshapes[listofshapes.Count - 1], p.Y - listofshapes[listofshapes.Count - 1].ActualHeight/ 2);
            }
        }

        private void Shapes_MouseWheel(object sender, MouseWheelEventArgs e)
        {
          

        }

        private void Shapes_MouseUp(object sender, MouseButtonEventArgs e)
        {
            drag = false;
        }

        private void Shapes_MouseDown(object sender, MouseButtonEventArgs e)
        {
            drag = true;
        }


        private void Shapes_MouseLeave(object sender, MouseEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).list_Of_Shapes[((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Count - 1].Stroke = Brushes.Transparent;
        }

        private void Shapes_MouseMove(object sender, MouseEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).list_Of_Shapes[((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Count - 1].Stroke = Brushes.Black;
        }
        public void MouseWheelOnShape(List<Shape> list_Of_Shapes,Canvas mainpicture ,MouseWheelEventArgs e,bool isshapeadded)
        {
            if (isshapeadded)
            {
                if (e.Delta > 0)
                {
                    list_Of_Shapes[list_Of_Shapes.Count - 1].Width += 5;
                    list_Of_Shapes[list_Of_Shapes.Count - 1].Height += 5;
                }
                else
                {
                    list_Of_Shapes[list_Of_Shapes.Count - 1].Width -= 5;
                    list_Of_Shapes[list_Of_Shapes.Count - 1].Height -= 5;

                }
            }
            else
            {

       
            
              
              if (e.Delta > 0)
              {
                //Polygon polygon2 = new Polygon();
                //Point p=new Point();
                //polygon2 = ((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon;
                //for (int i=0;i < ((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon.Points.Count; i++)
                //{
                //    p.X = ((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon.Points[i].X + 5;
                //    p.Y = ((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon.Points[i].Y + 5;
                //    polygon2.Points.Add(p);
                //}
                //mainpicture.Children.Add(polygon2);
                //Canvas.SetLeft(polygon2, Canvas.GetLeft(((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon));
                //Canvas.SetTop(polygon2, Canvas.GetTop(((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon));
                //mainpicture.Children.Remove(((ShapesWindows)Application.Current.Windows[13]).ShapeSPollygon);
              }
              else
              {

              }
            }
        }
        
    }
}
