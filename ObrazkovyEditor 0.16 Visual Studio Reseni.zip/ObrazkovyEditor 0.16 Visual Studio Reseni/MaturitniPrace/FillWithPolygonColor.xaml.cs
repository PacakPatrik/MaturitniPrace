﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro FillWithPolygonColor.xaml
    /// </summary>
    public partial class FillWithPolygonColor : Window
    {
        ColorSelector colorSelector = new ColorSelector();
        Brush brush;
        ImageBrush imageBrush2 = new ImageBrush();
        ImageBrush imageBrush = new ImageBrush();
        bool converted;
        BitmapImage bitmapimage=new BitmapImage();
        public FillWithPolygonColor()
        {
            InitializeComponent();
            OpacitySlider.Value = 100;
        }

     

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.Visibility = Visibility.Hidden;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Lines.Clear();
                ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
                ((SelectionWindow)Application.Current.Windows[32]).textboxstackpanel.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
            }
            catch { MessageBox.Show("error"); }
         }

        private void AddButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

            if (((MainWindow)Application.Current.MainWindow).Is_Polygon_Filled_With_Color)
            {
                ((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image = true;
                if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                {
                    Rectangle rec = new Rectangle();
                    rec = ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1];

                    Rect rectanglee = new Rect();
                    rectanglee.Width = rec.Width* ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width;

                    rectanglee.Height = rec.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height*((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                    rectanglee.X = Canvas.GetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1]) *((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width*((MainWindow)Application.Current.MainWindow).zoom_ratio_Width;
                    rectanglee.Y = Canvas.GetTop(((MainWindow)Application.Current.MainWindow).list_Of_Rectangles[((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count - 1]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height*((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                    brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                    imageBrush2 = (ImageBrush)brush;
                    RenderTargetBitmap bitmap = new RenderTargetBitmap((int)imageBrush2.ImageSource.Width, (int)imageBrush2.ImageSource.Height, 96, 96, PixelFormats.Pbgra32);
                    DrawingVisual drawingVisual = new DrawingVisual();
                    DrawingContext drawingContext = drawingVisual.RenderOpen();
                    SolidColorBrush rectBrush = new SolidColorBrush();
                    Color color;
                    color = ((SolidColorBrush)SelectedColor.Fill).Color;
                    //rectBrush = (SolidColorBrush)SelectedColor.Fill;
                    rectBrush.Color = color;
                    rectBrush.Opacity = ((MainWindow)Application.Current.MainWindow).FilledRectangle.Opacity;
                    drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
                    drawingContext.DrawRectangle(rectBrush, new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0), rectanglee);
                    drawingContext.PushOpacity(((MainWindow)Application.Current.MainWindow).FilledRectangle.Opacity);
                    drawingContext.Close();

                    bitmap.Render(drawingVisual);
                    imageBrush.ImageSource = bitmap;

                    if (!converted)
                    {
                        var bitmapEncoder = new PngBitmapEncoder();
                        bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                        using (var stream = new MemoryStream())
                        {
                            bitmapEncoder.Save(stream);
                            stream.Seek(0, SeekOrigin.Begin);

                            bitmapimage.BeginInit();
                            bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                            bitmapimage.StreamSource = stream;
                            bitmapimage.EndInit();

                        }

                        imageBrush.ImageSource = bitmapimage;
                        converted = true;
                    }
                      ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
                    ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Clear();
                }
                else
                {
                    brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                    imageBrush2 = (ImageBrush)brush;
                    RenderTargetBitmap bitmap = new RenderTargetBitmap((int)imageBrush2.ImageSource.Width, (int)imageBrush2.ImageSource.Height, 96, 96, PixelFormats.Pbgra32);
                    DrawingVisual drawingVisual = new DrawingVisual();
                    DrawingContext drawingContext = drawingVisual.RenderOpen();
                    drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
                    StreamGeometry streamGeometry = new StreamGeometry();
                    using (StreamGeometryContext geometryContext = streamGeometry.Open())
                    {
                        geometryContext.BeginFigure(new System.Windows.Point(((MainWindow)Application.Current.MainWindow).FilledPolygon.Points[0].X * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                          ((MainWindow)Application.Current.MainWindow).FilledPolygon.Points[0].Y * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height*((MainWindow)Application.Current.MainWindow).zoom_ratio_Height), true, true);
                        PointCollection points = new PointCollection();
                        for (int i = 1; i < ((MainWindow)Application.Current.MainWindow).FilledPolygon.Points.Count; i++)
                        {
                            points.Add(new System.Windows.Point(((MainWindow)Application.Current.MainWindow).FilledPolygon.Points[i].X * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width*((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                                ((MainWindow)Application.Current.MainWindow).FilledPolygon.Points[i].Y * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width));
                        }
                        geometryContext.PolyLineTo(points, true, true);
                    }

                    SolidColorBrush rectBrush = new SolidColorBrush();
                    Color color;
                    color = ((SolidColorBrush)SelectedColor.Fill).Color;
                    //rectBrush = (SolidColorBrush)SelectedColor.Fill;
                    rectBrush.Color = color;
                    rectBrush.Opacity = ((MainWindow)Application.Current.MainWindow).FilledPolygon.Opacity;


                    drawingContext.DrawGeometry(rectBrush, new Pen(Brushes.Transparent, 0), streamGeometry);
                    drawingContext.Close();
                    bitmap.Render(drawingVisual);
                    imageBrush.ImageSource = bitmap;

                    if (!converted)
                    {
                        var bitmapEncoder = new PngBitmapEncoder();
                        bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                        using (var stream = new MemoryStream())
                        {
                            bitmapEncoder.Save(stream);
                            stream.Seek(0, SeekOrigin.Begin);

                            bitmapimage.BeginInit();
                            bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                            bitmapimage.StreamSource = stream;
                            bitmapimage.EndInit();

                        }

                        imageBrush.ImageSource = bitmapimage;
                        converted = true;
                    }
                  ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
                    ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
                    ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = false;
                    ((MainWindow)Application.Current.MainWindow).Is_Stopped_Before_Ending = false;
                    ((SelectionWindow)Application.Current.Windows[32]).textboxstackpanel.Children.Clear();

                }
                ((MainWindow)Application.Current.MainWindow).Is_Polygon_Filled_With_Color = false;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
                    ((MainWindow)Application.Current.MainWindow).list_Of_Lines.Clear();
                    ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
               
                
            }
        }

        private void SelectedColor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            colorSelector.Visibility = Visibility.Visible;
        }

        private void OpacitySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            try
            {
                if (((MainWindow)Application.Current.MainWindow).Is_Polygon_Filled_With_Color)
                {
                    if (((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Count > 0)
                    {
                        //MessageBox.Show(OpacitySlider.Value.ToString());
                        ((MainWindow)Application.Current.MainWindow).FilledRectangle.Opacity = Convert.ToDouble(OpacitySlider.Value / 100);
                    }
                    else
                    {
                        ((MainWindow)Application.Current.MainWindow).FilledPolygon.Opacity = Convert.ToDouble(OpacitySlider.Value / 100);
                    }

                }
            }
            catch {  }
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
    }
}
