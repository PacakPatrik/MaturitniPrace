﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System;
using Microsoft.Win32;
using System.Collections.Generic;


namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro SelectionWindowsWithPoints.xaml
    /// </summary>
    /// 
    public partial class SelectionWindowsWithPoints : Window
    {
       
        public SelectionWindowsWithPoints()
        {
            
            InitializeComponent();
           

        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
           //ZDE BUDE KOD PRO ORIZNUTI
         
        }
        //Odebere poslední bod vytvořený na obrázku
        private void Button_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).list_Of_Points.Count > 1)
            {
                if (((MainWindow)Application.Current.MainWindow).Ended_Polygon == true)
                {

                    ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Lines.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Lines.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
                }
                else
                {
                    for (int i = 0; i < 2; i++)
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1);
                    }
                    ((MainWindow)Application.Current.MainWindow).list_Of_Lines.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Lines.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Count - 1);
                    ((MainWindow)Application.Current.MainWindow).list_Of_Points.RemoveAt(((MainWindow)Application.Current.MainWindow).list_Of_Points.Count - 1);
                    textboxstackpanel.Children.RemoveAt(textboxstackpanel.Children.Count - 1);
                }

            ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = true;
            }
        }

      
        //Umožňuje pohybovat oknem kliknutím na něj a tahem
        private void Window_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        //Smaže všechny body a čářy na obrázku vytořené uživatelem
        private void CloseButton_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            for (int i = (textboxstackpanel.Children.Count - 1); i > -1; i--)
            {
                textboxstackpanel.Children.RemoveAt(i);

            }
            for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j >-1 ; j--)
            {
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
            }
             ((MainWindow)Application.Current.MainWindow).Removed_Polygon_Point = false;
            ((MainWindow)Application.Current.MainWindow).Ended_Polygon = false;
            ((MainWindow)Application.Current.MainWindow).Is_Stopped_Before_Ending = false;
            ((MainWindow)Application.Current.MainWindow).list_Of_Ellipses.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Lines.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
            ((MainWindow)Application.Current.MainWindow).active_Control = "";
            ((MainWindow)Application.Current.MainWindow).count = 0;
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_SelectionPolygon_Open = false;
        }
        public void RemoveTxtBoxes()
        {
            
        }
    }
}
