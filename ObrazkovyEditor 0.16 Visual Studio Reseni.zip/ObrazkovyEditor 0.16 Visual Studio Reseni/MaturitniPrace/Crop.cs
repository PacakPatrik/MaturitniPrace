﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using System.Windows.Input;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MaturitniPrace
{

    class Crop
    {
        PointCollection polygon_points = new PointCollection();
        ImageBrush Ib = new ImageBrush();
        ImageBrush imageBrush = new ImageBrush();
        BitmapSource btmp;
        ImageSource Is;
        Brush brush;
        Int32Rect rectangle = new Int32Rect();
        int lowest_X, lowest_Y, highest_X, highest_Y;
        ResizeWindow resizeWin = new ResizeWindow();
        SelectionWindow selectionwin = new SelectionWindow();
        /*Funkce Ořezu, která ořeže obrázek,pokud je vybrána oblast pomocí čtverce*/
        public void CropUsingRec(List<Rectangle> list_of_rectangles, Canvas canvas, double ratio, ref BitmapSource original_image, bool pictureUploaded, string ActiveControl, double zoom_ratio,
            ref bool polygon_created, PathSegmentCollection segmentcolection, ref Size CanvasSize, ref Size ResizeCanvasSize, ref Size original_Size_To_Set, Size Mouse_Rec_Size, Size TXTBox_Rec_Size)
        {
            if (pictureUploaded == true)
            {

                if (ActiveControl == "SelectionMouse" && list_of_rectangles.Count > 0)
                {
                    if (polygon_created == true)
                    {
                        MessageBox.Show("Please first reset the picture by opening it again");
                        for (int j = (canvas.Children.Count - 1); j > -1; j--)
                        {
                            canvas.Children.RemoveAt(j);
                        }
                        //segmentcolection.Clear();
                        list_of_rectangles.Clear();
                    }
                    else
                    {
                        rectangle.X = Convert.ToInt32((Canvas.GetLeft(list_of_rectangles[list_of_rectangles.Count - 1]) * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width);
                        rectangle.Y = Convert.ToInt32((Canvas.GetTop(list_of_rectangles[list_of_rectangles.Count - 1]) * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                        rectangle.Width = Convert.ToInt32((list_of_rectangles[list_of_rectangles.Count - 1].Width * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width);
                        rectangle.Height = Convert.ToInt32((list_of_rectangles[list_of_rectangles.Count - 1].Height * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                        if (((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image == true)
                        {
                            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                            imageBrush = (ImageBrush)brush;
                            btmp = (BitmapImage)imageBrush.ImageSource;
                            Ib.ImageSource = new CroppedBitmap(btmp, rectangle);
                        }
                        if (((MainWindow)Application.Current.MainWindow).Is_PictureRotated)
                        {

                            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                            imageBrush = (ImageBrush)brush;
                            btmp = (BitmapSource)imageBrush.ImageSource;
                            Ib.ImageSource = new CroppedBitmap(btmp, rectangle);
                        }
                        else
                        {
                            Ib.ImageSource = new CroppedBitmap(original_image, rectangle);
                        }
                        Is = Ib.ImageSource;
                        original_image = Is as BitmapSource;
                        canvas.Background = Ib;
                        canvas.Width = original_image.Width / ratio;
                        canvas.Height = original_image.Height / ratio;
                        CanvasSize.Width = canvas.Width;
                        CanvasSize.Height = canvas.Height;
                        ResizeCanvasSize.Width = rectangle.Width;
                        ResizeCanvasSize.Height = rectangle.Height;
                        for (int j = (canvas.Children.Count - 1); j > -1; j--)
                        {
                            canvas.Children.RemoveAt(j);
                        }
                        //segmentcolection.Clear();
                        list_of_rectangles.Clear();
                        polygon_created = false;
                        original_Size_To_Set.Width = Mouse_Rec_Size.Width;
                        original_Size_To_Set.Height = Mouse_Rec_Size.Height;
                        // MessageBox.Show(Convert.ToString(original_Size_To_Set.Width));
                    }
                }

                if (ActiveControl == "SelectionTxtBox" && list_of_rectangles.Count > 0)
                {
                    if (polygon_created == true)
                    {
                        MessageBox.Show("Please first reset the picture by opening it again");
                        for (int j = (canvas.Children.Count - 1); j > -1; j--)
                        {
                            canvas.Children.RemoveAt(j);
                        }
                        //segmentcolection.Clear();
                        list_of_rectangles.Clear();
                    }
                    else
                    {
                        rectangle.X = Convert.ToInt32((Canvas.GetLeft(list_of_rectangles[list_of_rectangles.Count - 1]) * ratio) *((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width);
                        rectangle.Y = Convert.ToInt32((Canvas.GetTop(list_of_rectangles[list_of_rectangles.Count - 1]) * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                        rectangle.Width = Convert.ToInt32((list_of_rectangles[list_of_rectangles.Count - 1].Width * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width);
                        rectangle.Height = Convert.ToInt32((list_of_rectangles[list_of_rectangles.Count - 1].Height * ratio) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                        if (((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image == true)
                        {
                            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                            imageBrush = (ImageBrush)brush;
                            btmp = (BitmapImage)imageBrush.ImageSource;
                            Ib.ImageSource = new CroppedBitmap(btmp, rectangle);
                        }
                        if (((MainWindow)Application.Current.MainWindow).Is_PictureRotated)
                        {

                            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                            imageBrush = (ImageBrush)brush;
                            btmp = (BitmapSource)imageBrush.ImageSource;
                            Ib.ImageSource = new CroppedBitmap(btmp, rectangle);
                        }
                        else
                        {
                            Ib.ImageSource = new CroppedBitmap(original_image, rectangle);
                        }
                        Is = Ib.ImageSource;
                        original_image = Is as BitmapSource;
                        canvas.Background = Ib;
                        canvas.Width = original_image.Width / ratio;
                        canvas.Height = original_image.Height / ratio;

                        for (int j = (canvas.Children.Count - 1); j > -1; j--)
                        {
                            canvas.Children.RemoveAt(j);
                        }
                        list_of_rectangles.Clear();
                        polygon_created = false;
                        original_Size_To_Set.Width = TXTBox_Rec_Size.Width;
                        original_Size_To_Set.Height = TXTBox_Rec_Size.Height;
                        //MessageBox.Show(Convert.ToString(original_Size_To_Set.Width));
                    }


                }

            }
        }
        //Změna barvy tlačitka ořezu
        public void DarkerRec(Rectangle rectangle)
        {
            rectangle.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
        }
        //Změna barvy tlačitka ořezu
        public void LigherRec(Rectangle rectangle)
        {
            rectangle.Fill = new SolidColorBrush(Color.FromRgb(60, 60, 60));
        }

        /*Vykoná se ořez pomocí bodů ve volném výběru. V podstatě se jen ořízne Canvas, na kterém se obrázek zobrazuje, ale ve finálním ukládání se uloží obrázek 
         podle truktury Canvasu*/
        public void CropUsingPolygonPoints(PathSegmentCollection pathsegments, PathFigure pathFigure, List<Point> listofpoints, bool PictureUploaded, string ActiveControl, ref Size size_of_croppedarea, ref bool polygoncreated)
        {
            if (ActiveControl == "SelectionPolygon" && PictureUploaded == true)
            {
                try
                {
                    lowest_X = (int)listofpoints[0].X;
                    highest_X = (int)listofpoints[0].X;
                    lowest_Y = (int)listofpoints[0].Y;
                    highest_Y = (int)listofpoints[0].Y;
                    for (int i = 0; i < listofpoints.Count - 1; i++)
                    {
                        if ((int)listofpoints[i].X > highest_X)
                        {
                            highest_X = (int)listofpoints[i].X;
                        }
                        if ((int)listofpoints[i].X < lowest_X)
                        {
                            lowest_X = (int)listofpoints[i].X;
                        }
                        if ((int)listofpoints[i].Y > highest_Y)
                        {
                            highest_Y = (int)listofpoints[i].Y;
                        }
                        if ((int)listofpoints[i].Y < lowest_Y)
                        {
                            lowest_Y = (int)listofpoints[i].Y;
                        }
                    }
                    size_of_croppedarea.Width = highest_X - lowest_X;
                    size_of_croppedarea.Height = highest_Y - lowest_Y;
                    pathsegments.Clear();
                    pathFigure.StartPoint = listofpoints[listofpoints.Count - 1];
                    for (int i = listofpoints.Count - 2; i >= 0; i--)
                    {




                        LineSegment linesegment = new LineSegment();
                        linesegment.Point = listofpoints[i];
                        pathsegments.Add(linesegment);
                    }
                    polygoncreated = true;
                }
                catch { }
            }
        }
        /*Vratí canvas do původního stavu a odstraní vše od uživatele(body,čáry, apod..)*/
        public void ClearCanvas(Canvas MainPicture, ref bool Removed_Polygon_Point, ref bool Ended_Polygon, ref bool Is_Stopped_Before_Ending,
            List<Ellipse> List_Of_Ellipses, List<Line> List_Of_Lines, List<Point> List_Of_Points, ref string Active_Control, ref int count, bool PictureUploaded)
        {
            if (Active_Control == "SelectionPolygon" && PictureUploaded == true)
            {
                for (int j = (MainPicture.Children.Count - 1); j > -1; j--)
                {
                    MainPicture.Children.RemoveAt(j);
                }
                Removed_Polygon_Point = false;
                Ended_Polygon = false;
                Is_Stopped_Before_Ending = false;
                List_Of_Ellipses.Clear();
                List_Of_Lines.Clear();
                List_Of_Points.Clear();
                count = 0;
            }
        }

    }
}
