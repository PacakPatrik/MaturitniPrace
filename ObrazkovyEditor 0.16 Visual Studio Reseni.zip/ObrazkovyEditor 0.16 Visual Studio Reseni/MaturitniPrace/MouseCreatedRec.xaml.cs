﻿using System;
using System.Windows;
using System.Windows.Input;


namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro MouseCreatedRec.xaml
    /// </summary>
    public partial class MouseCreatedRec : Window
    {
        public MouseCreatedRec()
        {
            InitializeComponent();
        }

        private void OkButton_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Visibility = Visibility.Hidden;
        }
      //Umožňuje pohybovat oknem pouhým kliknutím a tahem 
        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }
        //Nastaví data velikosti výběru do TextBoxů.
        public void PassValuesIntoTxtBoxes(double X,double Y,double width,double height,bool set_points)
        {
            if (set_points==true)
            {
                TxtX.Text = Convert.ToString(X);
                TxtY.Text = Convert.ToString(Y);
            }
            TxtWidth.Text = Convert.ToString(width);
            TxtHeight.Text = Convert.ToString(height);
        }

        //Vyčistí obrázek od čtverce a všecho vytvořeného uživatelem
        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            for (int j = (((MainWindow)Application.Current.MainWindow).MainPicture.Children.Count - 1); j > -1; j--)
            {
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.RemoveAt(j);
            }
             ((MainWindow)Application.Current.MainWindow).list_Of_Points.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Rectangles.Clear();
            TxtX.Text = "0";
            TxtY.Text = "0";
            TxtWidth.Text = "0";
            TxtHeight.Text = "0";
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).active_Control = "";
            ((MainWindow)Application.Current.MainWindow).count = 0;
            ((MainWindow)Application.Current.MainWindow).Is_MouseRec_Open = false;
        }
    }
}
