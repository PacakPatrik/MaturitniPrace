﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro ResizeWindow.xaml
    /// </summary>
    public partial class ResizeWindow : Window
    {
        public double Before_Resize_widht, Before_Resize_height;
        Size Diference_after_dividing;
        double ratio;
        ImageBrush PictureBrush = new ImageBrush();
        bool Is_Changed_With_arrows=false;
        
        Image image = new Image();
        public ResizeWindow()
        {
            InitializeComponent();
            NewPixelWidth.IsReadOnly = true;
            NewPixelHeight.IsReadOnly = true;
            PercentUpTxtBox.IsReadOnly = true;
            PercentDownTxtBox.IsReadOnly = true;
        }



        private void TextBoxOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            PercentOpacityRec.Opacity = 0;
            ManualOpacityRec.Opacity = 0;
            TextBoxOpacityRec.Opacity = 0.2;
        }

        private void PercentOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            PercentOpacityRec.Opacity = 0.2;
            ManualOpacityRec.Opacity = 0;
            TextBoxOpacityRec.Opacity = 0;
        }

        private void ManualOpacityRec_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            PercentOpacityRec.Opacity = 0;
            ManualOpacityRec.Opacity = 0.2;
            TextBoxOpacityRec.Opacity = 0;
        }
        #region Opacity
        private void ManualOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {

            try
            {
                ((MainWindow)Application.Current.MainWindow).uppercanvas.Children.RemoveAt(2);
            }
            catch { }
            ((MainWindow)Application.Current.MainWindow).MainPicture.Width= ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;
           
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded) {
               
                ((MainWindow)Application.Current.MainWindow).MainPicture.Width *= 0.5;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Height *= 0.5;


                ClickManualOpacityRec.Opacity = 0.5;
                ClickPercentOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0;

                ManualOpacityRec.Visibility = Visibility.Hidden;
                PercentOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                ((MainWindow)Application.Current.MainWindow).active_Control = "ResizeManual";

                PercentDownTxtBox.IsReadOnly = true;
                PercentUpTxtBox.IsReadOnly = true;
                NewPixelHeight.IsReadOnly = true;
                NewPixelWidth.IsReadOnly = true;
                Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width) / 2);
                Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);

            }
        }

        private void PercentOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                ((MainWindow)Application.Current.MainWindow).uppercanvas.Children.RemoveAt(2);
            }
            catch { }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;




            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded) {
                if (((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Count < 3)
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= 3.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= 3.5;

                    image.Source = ((MainWindow)Application.Current.MainWindow).original_Image;
                    image.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    image.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                    ((MainWindow)Application.Current.MainWindow).uppercanvas.Children.Add(image);
                    //MessageBox.Show(string.Format("{0}     {1} ", Canvas.GetLeft(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Width, Canvas.GetLeft(image)+ ((MainWindow)Application.Current.MainWindow).MainPicture.Width));
                }

                ClickManualOpacityRec.Opacity = 0;
                ClickPercentOpacityRec.Opacity = 0.5;
                ClickTextBoxOpacityRec.Opacity = 0;

                ManualOpacityRec.Visibility = Visibility.Visible;
                PercentOpacityRec.Visibility = Visibility.Hidden;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                ((MainWindow)Application.Current.MainWindow).active_Control = "ResizePercent";
                Before_Resize_widht = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                Before_Resize_height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                Diference_after_dividing.Width = (((MainWindow)Application.Current.MainWindow).MainPicture.Width * 3.5) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                Diference_after_dividing.Height = (((MainWindow)Application.Current.MainWindow).MainPicture.Height * 3.5) - ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                PercentDownTxtBox.IsReadOnly = false;
                PercentUpTxtBox.IsReadOnly = false;
                NewPixelHeight.IsReadOnly = true;
                NewPixelWidth.IsReadOnly = true;
                ((MainWindow)Application.Current.MainWindow).st.ScaleX = 1;
                ((MainWindow)Application.Current.MainWindow).st.ScaleY = 1;
                PutPercentImagesIntoMiddle();
              
            }

        }

        private void TextBoxOpacityRec_MouseDown(object sender, MouseButtonEventArgs e)
        {

            try
            {
                ((MainWindow)Application.Current.MainWindow).uppercanvas.Children.RemoveAt(2);
            }
            catch { }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;



            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {
                //if (((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Children.Count < 2)
                //{

                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= 3.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= 3.5;

                //    image.Source = ((MainWindow)Application.Current.MainWindow).OriginalImage;
                //    image.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                //    image.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                //    ((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Children.Add(image);
                //}
                ClickManualOpacityRec.Opacity = 0;
                ClickPercentOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0.5;
                ManualOpacityRec.Visibility = Visibility.Visible;
                PercentOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Hidden;
                ((MainWindow)Application.Current.MainWindow).active_Control = "ResizeWTextBox";
                Before_Resize_widht = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                Before_Resize_height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                PercentDownTxtBox.IsReadOnly = true;
                PercentUpTxtBox.IsReadOnly = true;
                NewPixelHeight.IsReadOnly = false;
                NewPixelWidth.IsReadOnly = false;
                ((MainWindow)Application.Current.MainWindow).st.ScaleX = 1;
                ((MainWindow)Application.Current.MainWindow).st.ScaleY = 1;
                Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width )/2);
                Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);

            }
        }
        #endregion

        #region ManualResize
        public void SetNewHeightAndWidth(string width,string height)
        {
            NewWidth.Text = width;
            NewHeight.Text = height;
        }
        #endregion


        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                this.DragMove();
            }
            catch { }
            }
        #region closeButton
        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
            {

                if (((MainWindow)Application.Current.MainWindow).AreProportionsChangedWTxtBox && ((MainWindow)Application.Current.MainWindow).active_Control == "ResizeWTextBox")
                {

                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 3.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 3.5;
                    // MessageBox.Show(string.Format("{0}   {1}", ((MainWindow)Application.Current.MainWindow).MainPicture.Width, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth));
                    //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                    //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;

                    if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth &&
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight)
                    {
                       // MessageBox.Show("hij");
                    
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height;
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                        if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth || ((MainWindow)Application.Current.MainWindow).MainPicture.Height > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight){
                            double size=0;
                            double ratio=0;
                            size = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                            ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth-150;
                            ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                            ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ratio;
                          
                        }
                    }
                    else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth)
                    {
                        //MessageBox.Show("hej");
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth - 100;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize;
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                   
                            double size = 0;
                            double ratio = 0;
                            size = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                            ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth - 150;
                            ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                            ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ratio;

                        


                    }
                    else if (((MainWindow)Application.Current.MainWindow).MainPicture.Height > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight)
                    {
                      
                        //  ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Height/ ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;
                      
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight - 100;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width;

                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;

                        double size = 0;
                        double ratio = 0;
                        size = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight - 150;
                        ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= ratio;
                    }
                        ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;

                } if  (!((MainWindow)Application.Current.MainWindow).AreProportionsChangedWTxtBox && ((MainWindow)Application.Current.MainWindow).active_Control == "ResizeWTextBox")
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 3.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 3.5;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                
                }


                if (((MainWindow)Application.Current.MainWindow).AreProportionsChangedManualy && ((MainWindow)Application.Current.MainWindow).active_Control== "ResizeManual")
                {

                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 0.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 0.5;
                    // MessageBox.Show(string.Format("{0}   {1}", ((MainWindow)Application.Current.MainWindow).MainPicture.Height, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight));
                    //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening);
                    //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewHeight.Text);
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                    ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Width = Convert.ToDouble(NewWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Height = Convert.ToDouble(NewHeight.Text);

                    if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth &&
                       ((MainWindow)Application.Current.MainWindow).MainPicture.Height > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight)
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height;

                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;


                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);

                        double size = 0;
                        double ratio = 0;
                        size = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth - 150;
                        ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ratio;
                        // MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).ratio_After_Resize));
                    }
                    else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth)
                    {
                        //MessageBox.Show("msos");
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;

                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth - 100;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height;
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewHeight.Text);
                        double size = 0;
                        double ratio = 0;
                        size = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight - 150;
                        ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width/= ratio;
                    }
                    else if (((MainWindow)Application.Current.MainWindow).MainPicture.Height > ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight)
                    {
                        
                        //MessageBox.Show("mem");
                      
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight - 100;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width /= ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width;

                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).MainPicture.Height / ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height / ((MainWindow)Application.Current.MainWindow).MainPicture.Height;

                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        //((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Math.Round((((MainWindow)Application.Current.MainWindow).MainPicture.Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewHeight.Text);
                        double size = 0;
                        double ratio = 0;
                        size = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth - 150;
                        ratio = size / ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height /= ratio;
                    }
                        ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                    // MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width));
                }
                if(!((MainWindow)Application.Current.MainWindow).AreProportionsChangedManualy && ((MainWindow)Application.Current.MainWindow).active_Control == "ResizeManual")
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 0.5;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 0.5;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                    ((MainWindow)Application.Current.MainWindow).canvas_Zoom_ratio_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
                }

                if (Is_Changed_With_arrows)
                {
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(ChangedWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(ChangedHeight.Text);
                    Is_Changed_With_arrows = false;
                }
                if (((MainWindow)Application.Current.MainWindow).active_Control == "ResizePercent")
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).canvas_Size.Width;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).canvas_Size.Height;
                }

                PutLineSegmentsToCorners();
                ((MainWindow)Application.Current.MainWindow).active_Control = "";
                PercentDownTxtBox.Text = "";
                PercentUpTxtBox.Text = "";
                NewPixelHeight.Text = "";
                NewPixelWidth.Text = "";
                NewWidth.Text = "";
                NewHeight.Text = "";
                this.Visibility = Visibility.Hidden;
                try
                {
                    ((MainWindow)Application.Current.MainWindow).uppercanvas.Children.RemoveAt(2);
                }
                catch { }

                ClickManualOpacityRec.Opacity = 0;
                ClickPercentOpacityRec.Opacity = 0;
                ClickTextBoxOpacityRec.Opacity = 0;
                ManualOpacityRec.Visibility = Visibility.Visible;
                PercentOpacityRec.Visibility = Visibility.Visible;
                TextBoxOpacityRec.Visibility = Visibility.Visible;
                ((MainWindow)Application.Current.MainWindow).st.ScaleX = 1;
                ((MainWindow)Application.Current.MainWindow).st.ScaleY = 1;
                Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - ((MainWindow)Application.Current.MainWindow).MainPicture.Width/2);
                Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - ((MainWindow)Application.Current.MainWindow).MainPicture.Height/2);
                ((MainWindow)Application.Current.MainWindow).AreProportionsChangedWTxtBox = false;
                ((MainWindow)Application.Current.MainWindow).AreProportionsChangedManualy = false;
                //try
                //{
                //    ((MainWindow)Application.Current.MainWindow).Ratio_After_Resize = ((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Width / Convert.ToDouble(ChangedWidth.Text);
                //}
                //catch { }
                ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
                ((MainWindow)Application.Current.MainWindow).canvas_Size.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width;
                ((MainWindow)Application.Current.MainWindow).canvas_Size.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height;
            }
            else 
            {
                this.Visibility = Visibility.Hidden;
                ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
                 
            }
                //MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).Ratio_After_Resize));
        }
        #endregion
        #region Up&DownArrows
        private void UpPercent_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).active_Control == "ResizePercent")
            {
                if (((MainWindow)Application.Current.MainWindow).MainPicture.Width > Before_Resize_widht * 2.5)
                {
                    image.Width -= image.Width * 0.1;
                    image.Height -= image.Height * 0.1;

                    ChangeWHWithArrowUp();
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width + image.Width) / 2);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);
                    PutPercentImagesIntoMiddle();

                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Width / 2);




                }
                else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width != Before_Resize_widht && image.Width > Before_Resize_widht)
                {
                    image.Width -= image.Width * 0.1;
                    image.Height -= image.Height * 0.1;

                    ChangeWHWithArrowUp();

                    PutPercentImagesIntoMiddle();
                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Height / 2);

                }
                else
                {


                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 0.10;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 0.10;
                    ChangeWHWithArrowUp();
                    //ChangeWHWithCanvasSize();
                    PutPercentImagesIntoMiddle();
                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Height / 2);


                }

                Is_Changed_With_arrows = true;

            }
        }

        private void DownPercent_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).active_Control == "ResizePercent")
            {
                if (((MainWindow)Application.Current.MainWindow).MainPicture.Width < Before_Resize_widht / 2.5)
                {
                    image.Width += image.Width * 0.1;
                    image.Height += image.Height * 0.1;

                    ChangeWHWithArrowDown();
                    //PutPercentImagesIntoMiddle();
                    // Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, (Canvas.GetTop(image) + image.Width / 2) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, Canvas.GetLeft(image) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width);
                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Width / 2);


                }
                else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width != Before_Resize_widht && image.Width < Before_Resize_widht)
                {


                    image.Width += image.Width * 0.1;
                    image.Height += image.Height * 0.1;

                    ChangeWHWithArrowDown();

                    PutPercentImagesIntoMiddle();
                    // Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, (Canvas.GetTop(image) + image.Width / 2) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, Canvas.GetLeft(image) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width);
                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Height / 2);


                }
                else
                {
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width -= ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 0.10;
                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height -= ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 0.10;
                    ChangeWHWithArrowDown();
                    PutPercentImagesIntoMiddle();
                    //  Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, (Canvas.GetTop(image) + image.Width / 2) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2);
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, Canvas.GetLeft(image) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width);
                    Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Height / 2);


                }
                // PutPercentImagesIntoMiddle();
                Is_Changed_With_arrows = true;

            }
        }
        //public void changepercentage10procent()
        //{

        //}

        #endregion
        #region PercentTextBoxes
        private void PercentUpTxtBox_TextChanged(object sender, TextChangedEventArgs e)
    {


        try
        {
                if (PercentUpTxtBox.Text != "")
                {
                  
                    PercentDownTxtBox.IsReadOnly = true;
                 
                }
                else
                {
                    PercentDownTxtBox.IsReadOnly = false;
                }
              
                ////else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width < Before_Resize_widht && image.Width > Before_Resize_widht)
                ////{
                ////    image.Width = Before_Resize_widht;
                ////    image.Height = Before_Resize_height;
                ////    ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentWidth.Text) / 100);
                ////    ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentWidth.Text) / 100);
                ////    if (Convert.ToDouble(PercentWidth.Text) > 150 )
                ////    {
                ////        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width + ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 1.5;
                ////        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height + ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 1.5;
                ////        ChangeWithPercent(Convert.ToDouble(PercentWidth.Text));
                ////        image.Width -= image.Width * ((Convert.ToDouble(PercentWidth.Text) - 150) / 100);
                ////        image.Height -= image.Height * ((Convert.ToDouble(PercentWidth.Text) - 150) / 100);
                ////        passWHvalues();
                ////    }
                ////    else
                ////    {
                ////        ChangeWithPercent(Convert.ToDouble(PercentWidth.Text));
                ////        passWHvalues();
                ////    }
                ////}
                //else
                //{
                //    ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentWidth.Text) / 100);
                //    ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentWidth.Text) / 100);
                //    //MessageBox.Show(Convert.ToString(/*((MainWindow)Application.Current.MainWindow).MainPicture.Width **/ (Convert.ToDouble(PercentWidth.Text) / 100)));
                //    ChangeWHWithCanvasSize();
                //    passWHvalues();
                //}


            }
            catch
            {
                
            }

        }

    private void PercentDownTxtBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        try
        {
                if (PercentDownTxtBox.Text != "")
                {
                    PercentUpTxtBox.IsReadOnly = true;
                }
                else
                {
                    PercentUpTxtBox.IsReadOnly = false;
                }
                //    if (Convert.ToDouble(PercentHeight.Text) > 150 && ((MainWindow)Application.Current.MainWindow).MainPicture.Width >= Before_Resize_widht)
                //    {
                //        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width - ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 1.5;
                //        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height - ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 1.5;
                //        ChangeWithPercent(Convert.ToDouble(PercentHeight.Text));
                //        image.Width += image.Width * ((Convert.ToDouble(PercentHeight.Text) - 150) / 100);
                //        image.Height += image.Height * ((Convert.ToDouble(PercentHeight.Text) - 150) / 100);
                //        passWHvalues();

                //    }
                //    //else if (((MainWindow)Application.Current.MainWindow).MainPicture.Width < Before_Resize_widht && image.Width > Before_Resize_widht)
                //    //{
                //    //    image.Width = Before_Resize_widht;
                //    //    image.Height = Before_Resize_height;
                //    //    ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentWidth.Text) / 100);
                //    //    ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentWidth.Text) / 100);
                //    //    if (Convert.ToDouble(PercentWidth.Text) > 150)
                //    //    {
                //    //        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width + ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 1.5;
                //    //        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height + ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 1.5;
                //    //        ChangeWithPercent(Convert.ToDouble(PercentWidth.Text));
                //    //        image.Width -= image.Width * ((Convert.ToDouble(PercentWidth.Text) - 150) / 100);
                //    //        image.Height -= image.Height * ((Convert.ToDouble(PercentWidth.Text) - 150) / 100);
                //    //        passWHvalues();
                //    //    }
                //    //    else
                //    //    {
                //    //        ChangeWithPercent(Convert.ToDouble(PercentWidth.Text));
                //    //        passWHvalues();
                //    //    }
                //    //}
                //    else
                //    {
                       
                //    }
                //((MainWindow)Application.Current.MainWindow).MainPicture.Width -= ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentHeight.Text) / 100);
                //((MainWindow)Application.Current.MainWindow).MainPicture.Height -= ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentHeight.Text) / 100);
                //ChangeWHWithCanvasSize();
                //passWHvalues();

            }
            catch {
           
        }

    }
        #endregion
        public void SetOriginals(string Owidth, string Oheight, bool pictureuploaded)
        {
            if (pictureuploaded==true) {
                ChangedWidth.Text = Owidth;
                ChangedHeight.Text = Oheight;
                OriginalWidth.Text = Owidth;
                OriginalHeight.Text = Oheight;
                OrigWidth.Text = Owidth;
                OrigHeight.Text = Oheight;
            }
            else
            {
                ChangedWidth.Text = "0";
                ChangedHeight.Text = "0";
                OriginalWidth.Text = "0";
                OriginalHeight.Text = "0";
                OrigWidth.Text = "0";
                OrigHeight.Text = "0";
              
            }
        }
    public void ChangeWHWithCanvasSize()
    {
        ChangedWidth.Text = Convert.ToString((((MainWindow)Application.Current.MainWindow).MainPicture.Width + Diference_after_dividing.Width) * ratio);
        ChangedHeight.Text = Convert.ToString((((MainWindow)Application.Current.MainWindow).MainPicture.Height + Diference_after_dividing.Height) * (ratio));
    }
    public void ChangeWHWithArrowUp()
    {
            ChangedWidth.Text = Convert.ToString(Math.Round((Convert.ToDouble(ChangedWidth.Text)+(Convert.ToDouble(ChangedWidth.Text)*0.1))));
            ChangedHeight.Text = Convert.ToString(Math.Round((Convert.ToDouble(ChangedHeight.Text) + (Convert.ToDouble(ChangedHeight.Text) * 0.1))));
           
    }
    public void ChangeWHWithArrowDown()
    {
            ChangedWidth.Text = Convert.ToString(Math.Round(Convert.ToDouble(ChangedWidth.Text) - (Convert.ToDouble(ChangedWidth.Text) * 0.1)));
            ChangedHeight.Text = Convert.ToString(Math.Round(Convert.ToDouble(ChangedHeight.Text) - (Convert.ToDouble(ChangedHeight.Text) * 0.1)));

    }
    public void ChangeWithPercent(double percent)
    {
            if (PercentDownTxtBox.IsReadOnly == false)
            {

                if (Convert.ToDouble(PercentDownTxtBox.Text) < 100)
                {
                    ChangedWidth.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalWidth.Text) - (Convert.ToDouble(ChangedWidth.Text) * (percent / 100))));
                    ChangedHeight.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalHeight.Text) - (Convert.ToDouble(ChangedHeight.Text) * (percent / 100))));
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(ChangedWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(ChangedHeight.Text);
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Width = Convert.ToDouble(ChangedWidth.Text);
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Height= Convert.ToDouble(ChangedHeight.Text);
                   
                    // MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).Original_Size_To_Set.Width));
                }
                else
                {
                    MessageBox.Show("Picture cant be more than 99% smaller");
                }
            }
            if (PercentUpTxtBox.IsReadOnly == false)
            {
                if (Convert.ToDouble(PercentUpTxtBox.Text) > 150)
                {
                    ChangedWidth.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalWidth.Text) * (percent / 100)));
                    ChangedHeight.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalHeight.Text) * (percent / 100)));
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(ChangedWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(ChangedHeight.Text);
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Width = Convert.ToDouble(ChangedWidth.Text);
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Height = Convert.ToDouble(ChangedHeight.Text);
                  
                    // MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).Original_Size_To_Set.Width));
                }
                else
                {
                    
                    ChangedWidth.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalWidth.Text) +Convert.ToDouble(ChangedWidth.Text) * (percent / 100)));
                    ChangedHeight.Text = Convert.ToString(Math.Round(Convert.ToDouble(OriginalHeight.Text)+Convert.ToDouble(ChangedHeight.Text) * (percent / 100)));
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(ChangedWidth.Text);
                    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(ChangedHeight.Text);
                   // MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).Original_Size_To_Set.Width));
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Width = Convert.ToDouble(ChangedWidth.Text);
                   
                    //((MainWindow)Application.Current.MainWindow).Resize_Canvas_Size.Height = Convert.ToDouble(ChangedHeight.Text);

                }
            }
         
    }


   
    public void PassRatio(double Ratio)
    {
        ratio = Ratio;
    }

      

        private void okbutton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded)
                {
                    if (((MainWindow)Application.Current.MainWindow).active_Control == "ResizePercent")
                    {
                        Is_Changed_With_arrows = false;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = Before_Resize_widht;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = Before_Resize_height;
                        image.Width = Before_Resize_widht;
                        image.Height = Before_Resize_height;
                        if (PercentUpTxtBox.IsReadOnly == false)
                        {
                            if (Convert.ToDouble(PercentUpTxtBox.Text) > 150)
                            {
                                ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width + ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 1.5;
                                ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height + ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 1.5;
                                ChangeWithPercent(Convert.ToDouble(PercentUpTxtBox.Text));
                                image.Width -= image.Width * ((Convert.ToDouble(PercentUpTxtBox.Text) - 150) / 100);
                                image.Height -= image.Height * ((Convert.ToDouble(PercentUpTxtBox.Text) - 150) / 100);
                             
                                Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width + image.Width) / 2);
                                Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);
                                PutPercentImagesIntoMiddle();

                                Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Width / 2);


                            }
                            else
                            {
                                ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentUpTxtBox.Text) / 100);
                                ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentUpTxtBox.Text) / 100);
                                ChangeWithPercent(Convert.ToDouble(PercentUpTxtBox.Text));
                              
                               PutPercentImagesIntoMiddle();
                              
                                Canvas.SetTop(image, (Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture)+ ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2) - image.Height / 2);
                            }
                        }
                        if (PercentDownTxtBox.IsReadOnly == false)
                        {

                            ((MainWindow)Application.Current.MainWindow).MainPicture.Width -= ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentDownTxtBox.Text) / 100);
                            ((MainWindow)Application.Current.MainWindow).MainPicture.Height -= ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentDownTxtBox.Text) / 100);
                            ChangeWithPercent(Convert.ToDouble(PercentDownTxtBox.Text));
                         
                            PutPercentImagesIntoMiddle();
                            Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, (Canvas.GetTop(image)+image.Width/2)- ((MainWindow)Application.Current.MainWindow).MainPicture.Width/2);
                            Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, Canvas.GetLeft(image) - ((MainWindow)Application.Current.MainWindow).MainPicture.Width);
                        }
                        ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Width = Convert.ToDouble(ChangedWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Height = Convert.ToDouble(ChangedHeight.Text);


                    }
                    else { PutPercentImagesIntoMiddle(); }
                }
            }
            catch { }
        }

        private void TxtOkButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {

            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Width = double.NaN;
            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Width = double.NaN;
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Height = double.NaN;
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Height = double.NaN;
            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Width = double.NaN;
            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Height = double.NaN;
            if (((MainWindow)Application.Current.MainWindow).active_Control == "ResizeWTextBox" && NewPixelHeight.Text != "" && NewPixelWidth.Text != "") {

                //MessageBox.Show(Convert.ToString(((MainWindow)Application.Current.MainWindow).uppercanvas.Width));
                try
                {
                  

                    if ((Convert.ToDouble(NewPixelWidth.Text)/ ((MainWindow)Application.Current.MainWindow).ratio_After_Opening)/3.5 > ((MainWindow)Application.Current.MainWindow).uppercanvas.Width && Convert.ToDouble(NewPixelHeight.Text) < ((MainWindow)Application.Current.MainWindow).uppercanvas.Height )
                    {
                        
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.Width / 2 - Convert.ToDouble(NewPixelWidth.Text) / 2);
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).Width - ((MainWindow)Application.Current.MainWindow).Width * 0.2;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((Convert.ToDouble(NewPixelHeight.Text) )/ ((MainWindow)Application.Current.MainWindow).ratio_After_Opening)/ 3.5;
                       // ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                       // ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height= Convert.ToDouble(NewPixelHeight.Text);


                        //MessageBox.Show("vesti sirka");
                    }
                    if ((Convert.ToDouble(NewPixelHeight.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5 > ((MainWindow)Application.Current.MainWindow).uppercanvas.Height && Convert.ToDouble(NewPixelWidth.Text) < ((MainWindow)Application.Current.MainWindow).uppercanvas.Width )
                    {
                       // MessageBox.Show("vesti vyska");
                        Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.Width / 2 - Convert.ToDouble(NewPixelWidth.Text) / 2);

                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).Height - ((MainWindow)Application.Current.MainWindow).Height * 0.2;

                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((Convert.ToDouble(NewPixelWidth.Text)) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5;
                    //    ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                     //   ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                    }
                    if((Convert.ToDouble(NewPixelHeight.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5 > ((MainWindow)Application.Current.MainWindow).uppercanvas.Height * 0.2 && (Convert.ToDouble(NewPixelWidth.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5 > ((MainWindow)Application.Current.MainWindow).uppercanvas.Width)
                    {
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).uppercanvas.Width;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).uppercanvas.Height;
                        MessageBox.Show("vesti vyska a sirka");
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                        ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                    }
                    if (Convert.ToDouble((Convert.ToDouble(NewPixelHeight.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5) < ((MainWindow)Application.Current.MainWindow).Height - ((MainWindow)Application.Current.MainWindow).Height * 0.2   && Convert.ToDouble((Convert.ToDouble(NewPixelWidth.Text) / ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5) < ((MainWindow)Application.Current.MainWindow).Width - ((MainWindow)Application.Current.MainWindow).Width * 0.2)
                    {
                      //  MessageBox.Show("lel");
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((Convert.ToDouble(NewPixelWidth.Text)  )/ ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5;
                        ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((Convert.ToDouble(NewPixelHeight.Text)  )/ ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) / 3.5;
                    }
                    //((MainWindow)Application.Current.MainWindow).MainPicture.Width = double.NaN;
                    //((MainWindow)Application.Current.MainWindow).MainPicture.Height = double.NaN;
                    //PictureBrush.ImageSource= ((MainWindow)Application.Current.MainWindow).OriginalImage;
                    //((MainWindow)Application.Current.MainWindow).MainPicture.Background = PictureBrush;
                    //((MainWindow)Application.Current.MainWindow).st.ScaleX = 1;
                    //((MainWindow)Application.Current.MainWindow).st.ScaleY = 1;
                    Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width ) / 2);
                    Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);

                   // ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Width = Convert.ToDouble(NewPixelWidth.Text);
                   // ((MainWindow)Application.Current.MainWindow).original_Size_To_Set.Height = Convert.ToDouble(NewPixelHeight.Text);
                    //ImageToMiddle(((MainWindow)Application.Current.MainWindow).uppercanvas, ((MainWindow)Application.Current.MainWindow).MainPicture);
                    ((MainWindow)Application.Current.MainWindow).AreProportionsChangedWTxtBox = true;
                }
                catch { }


                ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Width = Convert.ToDouble(NewPixelWidth.Text);
                ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size.Height = Convert.ToDouble(NewPixelHeight.Text);

                //    {
                // MessageBox.Show("Work in progress");
                //try
                //{
                //    if (((MainWindow)Application.Current.MainWindow).Active_Control == "ResizePercent" && NewPixelHeight.Text != "" && NewPixelWidth.Text != "")
                //    {



                //            ((MainWindow)Application.Current.MainWindow).MainPicture.Width = Before_Resize_widht;
                //            ((MainWindow)Application.Current.MainWindow).MainPicture.Height = Before_Resize_height;
                //            image.Width = Before_Resize_widht;
                //            image.Height = Before_Resize_height;

                //                if (Convert.ToDouble(PercentUpTxtBox.Text) > 150)
                //                {
                //                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).MainPicture.Width + ((MainWindow)Application.Current.MainWindow).MainPicture.Width * 1.5;
                //                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).MainPicture.Height + ((MainWindow)Application.Current.MainWindow).MainPicture.Height * 1.5;
                //                    ChangeWithPercent(Convert.ToDouble(PercentUpTxtBox.Text));
                //                    image.Width -= image.Width * ((Convert.ToDouble(PercentUpTxtBox.Text) - 150) / 100);
                //                    image.Height -= image.Height * ((Convert.ToDouble(PercentUpTxtBox.Text) - 150) / 100);
                //                    passWHvalues();

                //                }
                //                else
                //                {
                //                    ((MainWindow)Application.Current.MainWindow).MainPicture.Width += ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentUpTxtBox.Text) / 100);
                //                    ((MainWindow)Application.Current.MainWindow).MainPicture.Height += ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentUpTxtBox.Text) / 100);
                //                    ChangeWHWithCanvasSize();
                //                    passWHvalues();
                //                }



                //                ((MainWindow)Application.Current.MainWindow).MainPicture.Width -= ((MainWindow)Application.Current.MainWindow).MainPicture.Width * (Convert.ToDouble(PercentDownTxtBox.Text) / 100);
                //                ((MainWindow)Application.Current.MainWindow).MainPicture.Height -= ((MainWindow)Application.Current.MainWindow).MainPicture.Height * (Convert.ToDouble(PercentDownTxtBox.Text) / 100);
                //                ChangeWithPercent(Convert.ToDouble(PercentDownTxtBox.Text));
                //                passWHvalues();


                //        }
                //        else { }

                //}
                //catch { }
            
            }
        
        }



        public void SetCanvasOriginalSize(string Owidth, string Oheight,bool pictureuploaded)
        {
            if (pictureuploaded) {
                OriginalWidth.Text = Owidth;
                OriginalHeight.Text = Oheight;
            }
            else
            {

            }
        }
       
        public void OnresetButton(double width,double height)
        {
            ChangedWidth.Text = "0";
            ChangedHeight.Text = "0";
            NewWidth.Text = Convert.ToString(width);
            NewHeight.Text = Convert.ToString(height);
            NewPixelWidth.Text = Convert.ToString(width);
            NewPixelHeight.Text = Convert.ToString(height);
            Before_Resize_widht = 0;
            Before_Resize_height = 0;
        }

        public void ImageToMiddle(Canvas uppercanvas, Canvas mainpicture)
        {
            Canvas.SetLeft(mainpicture, uppercanvas.Width / 2 - mainpicture.Width/2 );
            Canvas.SetTop(mainpicture, uppercanvas.Height / 2 - mainpicture.Height/2 );
            //MessageBox.Show("hej");
        }
       
        public void PutPercentImagesIntoMiddle()
        {
            Canvas.SetLeft(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualWidth / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Width + image.Width) / 2);
            Canvas.SetTop(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).uppercanvas.ActualHeight / 2 - (((MainWindow)Application.Current.MainWindow).MainPicture.Height) / 2);
            Canvas.SetLeft(image, Canvas.GetLeft(((MainWindow)Application.Current.MainWindow).MainPicture) + ((MainWindow)Application.Current.MainWindow).MainPicture.Width);
            Canvas.SetTop(image, Canvas.GetTop(((MainWindow)Application.Current.MainWindow).MainPicture));

        }
       
        public void PutLineSegmentsToCorners() 
        {
            ((MainWindow)Application.Current.MainWindow).pathfigure.StartPoint = new Point(0, 0);
            LineSegment linesegment1 = new LineSegment();
            LineSegment linesegment2 = new LineSegment();
            LineSegment linesegment3 = new LineSegment();
            linesegment1.Point = new Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, 0);
            linesegment2.Point = new Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);
            linesegment3.Point = new Point(0, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);

            ((MainWindow)Application.Current.MainWindow).segmentColection.Clear();
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment1);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment2);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment3);
        }

        public void SetManualWidthAndHeight(double Newwidht,double Newheight)
        {
            NewWidth.Text = Convert.ToString(Math.Round(Newwidht));
            NewHeight.Text = Convert.ToString(Math.Round(Newheight));
        }
    }
}

