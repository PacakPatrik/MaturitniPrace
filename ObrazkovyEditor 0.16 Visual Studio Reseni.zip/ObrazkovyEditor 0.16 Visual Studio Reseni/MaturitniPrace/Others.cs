﻿using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Input;
using System.Windows.Documents;
using System.Linq;
using System.Diagnostics;
using XamlAnimatedGif;
//using WpfAnimatedGif;
using System.Collections.Generic;

namespace MaturitniPrace
{

    class Others
    {
        #region variables
        string original_file_directory;
        string original_file_name;
        string original_file_ext;
        public string original_gif_path;
        public BitmapImage UploadedImage = new BitmapImage();
        ImageBrush LoadPictureBrush = new ImageBrush();
        ImageBrush print_Image_Brush = new ImageBrush();
        ImageBrush imagetoscale = new ImageBrush();
        Size Gifbitmap;
        public Size sizeAfterOpen;
        SelectionWindow selectionWindow = new SelectionWindow();
        int PotentialWidthOfImage;
        double Divisor;
        DrawingVisual drawing_Visual = new DrawingVisual();
   

        bool Is_Ctrl_Held = false;
        bool Is_File_Gif_Format;
        bool isset=false;
        ResizeWindow resizeWin = new ResizeWindow();
        #endregion
        /*Funkce, která zobrazí vysouvací menu*/
        public void ShowMenu(Storyboard sb, ResourceDictionary Resources, StackPanel VysouvaciMenu, ref bool opened, Rectangle RectangleMenu)
        {
            if (opened == false)
            {
                sb = Resources["OpenMenu"] as Storyboard;
                sb.Begin(VysouvaciMenu);
                RectangleMenu.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
                opened = true;
            }
        }


        /*Funkce, která skryje vysouvací menu*/
        public void HideMainMenu(Storyboard sb, ResourceDictionary Resources, StackPanel VysouvaciMenu, ref bool opened)
        {
            if (opened == true)
            {
                sb = Resources["CloseMenu"] as Storyboard;
                sb.Begin(VysouvaciMenu);
                opened = false;
            }
        }


        /*Změní barvu ikony menu*/
        public void MenuIconMouseUpColorChange(Rectangle rectangle)
        {
            rectangle.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }


        public void ResetLineSegment(Canvas canvas, PathSegmentCollection pathSegments, PathFigure pathfigure)
        {
            pathSegments.Clear();
            LineSegment linesegment = new LineSegment();
            LineSegment lineSegment2 = new LineSegment();
            LineSegment lineSegment3 = new LineSegment();
            LineSegment linesegment4 = new LineSegment();
            pathfigure.StartPoint = new Point(0, 0);
            lineSegment2.Point = new Point(canvas.Width, 0);
            lineSegment3.Point = new Point(canvas.Width, canvas.Height);
            linesegment4.Point = new Point(0, canvas.Height);
            pathSegments.Add(linesegment);
            pathSegments.Add(lineSegment2);
            pathSegments.Add(lineSegment3);
            pathSegments.Add(linesegment4);
        }



        /*Otevře obrázek, podle výběru v dialogovém okně*/
        public void OpenFile(ScaleTransform st, OpenFileDialog openFileDialog, Canvas canvas,/* Border canvasBorder */ref bool PictureUploaded, ref Size original_size, ref BitmapSource OriginalImage, ref bool is_polygon_created, ref bool Is_path_changed
            , ref Size original_size_to_set, ref Size ResizeCanvasSize, Image GifImage, BitmapImage GifBitmap, List<BitmapSource> List_Of_Gif_Images, Canvas uppercanvas, ref bool isgifopened, List<FileStream> listofstreams)
        {
            try
            {
                //CanvasesStackPanel.Width = double.NaN;
                //CanvasesStackPanel.Height = double.NaN;
                // ResetScaleFactor(st);

                openFileDialog.FileOk += OpenFilePressedOpen;
                openFileDialog.Filter = "All files |*.*| JPG(*.jpg)|*.jpg| GIF(*.gif)|*.gif| PNG(*.png)|*.png| " +
                "BMP(*.bmp) | *.bmp";
                if (openFileDialog.ShowDialog() == true)
                {

                    if (openFileDialog.FileName != "")
                    {
                        if (openFileDialog.FileName.EndsWith(".gif"))
                        {

                            foreach(FileStream stream in listofstreams)
                            {
                                stream.Dispose();
                            }
                            listofstreams.Clear();
                            AnimationBehavior.SetSourceStream(GifImage, null);
                            isgifopened = true;
                            canvas.Visibility = Visibility.Hidden;
                            original_gif_path = openFileDialog.FileName;
                            GifImage.Source = null;
                            List_Of_Gif_Images.Clear();
                          
                            ((LayersWindows)Application.Current.Windows[14]).Visibility = Visibility.Hidden;
                            Stream imagestreamsource = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                            GifBitmapDecoder decoder = new GifBitmapDecoder(imagestreamsource, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                           
                            for (int i = 0; i < decoder.Frames.Count - 1; i++)
                            {
                                
                                List_Of_Gif_Images.Add(decoder.Frames[i]);
                                
                            }
                           ((MainWindow)Application.Current.MainWindow).first_bitmap_frame = decoder.Frames[0];
                            // MessageBox.Show(List_Of_Gif_Images.Count.ToString());
                            //MessageBox.Show(openFileDialog.FileName);
                            GifImage.Visibility = Visibility.Visible;
                            if (isset == false)
                            {
                                GifBitmap.BeginInit();
                                GifBitmap.UriSource = new Uri(openFileDialog.FileName);
                                GifBitmap.EndInit();
                                isset = true;
                            }
                            else
                            {
                                GifBitmap.UriSource = new Uri(openFileDialog.FileName);

                            }
                            AnimationBehavior.SetSourceUri(GifImage, new Uri(openFileDialog.FileName));


                            // AnimationBehavior.SetSourceUri(GifImage, new Uri(openFileDialog.FileName));
                            //System.Diagnostics.Process.Start(openFileDialog.FileName);




                            //BitmapImage image = new BitmapImage();
                            //image.BeginInit();
                            //image.UriSource = new Uri("Resources/lovegif.gif");
                            //image.EndInit();

                            // Stream Imagesousrcestream = new FileStream(openFileDialog.FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                            //  Stream Imagesousrcestream2 = new FileStream("C:/Users/pacak/OneDrive/Plocha/Testovaci slozka/396d8cf19235b7b437d1067045a63b5a.gif", FileMode.Open, FileAccess.Read, FileShare.Read);
                            //  MessageBox.Show(openFileDialog.FileName);


                            // AnimationBehavior.SetSourceUri(GifImage,new Uri(openFileDialog.FileName));
                            // AnimationBehavior.SetSourceStream(imageGif, null);
                            // AnimationBehavior.SetSourceStream(imageGif, Imagesousrcestream2);


                            // AnimationBehavior.SetSourceUri(GifImage, new Uri(openFileDialog.FileName));
                            // AnimationBehavior.SetAutoStart(GifImage, true);
                            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height = 1;
                            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width = 1;
                            ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = 1;
                            ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = 1;
                        }
                        else
                        {
                            isgifopened = false;
                            GifImage.Visibility = Visibility.Hidden;
                            AnimationBehavior.SetSourceUri(GifImage, null);
                            canvas.Visibility = Visibility.Visible;
                            ((LayersWindows)Application.Current.Windows[14]).Visibility = Visibility.Hidden;
                            LoadPictureBrush.ImageSource = new BitmapImage(new Uri(openFileDialog.FileName));
                            UploadedImage = new BitmapImage(new Uri(openFileDialog.FileName));
                            OriginalImage = UploadedImage;
                            //MessageBox.Show(Convert.ToString(UploadedImage.PixelHeight));
                            //if (System.IO.Path.GetExtension(openFileDialog.FileName) == ".png")
                            //{
                            //    canvasBorder.BorderThickness = new Thickness(1);


                            //}
                            //else
                            //{
                            //    canvasBorder.BorderThickness = new Thickness(0);
                            //}

                            Gifbitmap.Width = UploadedImage.PixelWidth;
                            Gifbitmap.Height = UploadedImage.PixelHeight;

                            original_size.Width = Gifbitmap.Width;
                            original_size.Height = Gifbitmap.Height;
                            ResizeCanvasSize.Width = original_size.Width;
                            ResizeCanvasSize.Height = original_size.Height;
                            original_size_to_set = original_size;
                            canvas.Background = LoadPictureBrush;
                            PictureUploaded = true;

                            original_file_directory = System.IO.Path.GetDirectoryName(openFileDialog.FileName);
                            original_file_name = System.IO.Path.GetFileNameWithoutExtension(openFileDialog.FileName);
                            original_file_ext = System.IO.Path.GetExtension(openFileDialog.FileName);
                            is_polygon_created = false;
                            Is_path_changed = true;
                            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height = 1;
                            ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width = 1;
                            ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width = 1;
                            ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height = 1;

                        }
                    }
                   
                }
                else { }
            }
            catch { MessageBox.Show("This format is not supported"); }
        }
        /*Funkce, která se provede, po stisknutí tlačítka otevřít v dialogovém okně*/
        void OpenFilePressedOpen(object sender, CancelEventArgs e)
        {

            ((MainWindow)Application.Current.MainWindow).Is_Open_Pressed = true;
            foreach (Window window in Application.Current.Windows)
            {
                if (window != ((MainWindow)Application.Current.MainWindow))
                {
                    window.Visibility = Visibility.Hidden;
                }
            

            }
            
        }

        // Funkce, která obsahuje algoritmus, který by měl nastavit velikost obrázku tak,aby se vlezl do aplikace, ale stále zachoval jeho původní ratio.
        public void SetSizeOfCanvas(PathSegmentCollection pathSegments, PathFigure pathFigure, Canvas canvas, /* Border canvasBorder */ref double ratio, ref Size Canvas_Size, ref Size Canvas_Size_On_Open, MainWindow mainWindow,
            ref Size SizeAfterZoom, ScaleTransform st, OpenFileDialog openfiledialog, ref BitmapImage Gifbitmap, Image GifImage,ref bool Is_Open_Pressed, ref Size canvas_Zoom_ratio_Size)
        {
            if (Is_Open_Pressed)
            {
                if (openfiledialog.FileName.EndsWith(".gif"))
                {
                    PotentialWidthOfImage = 0;
                    Divisor = 1;
                    for (int i = 0; i < 7; i++)
                    {

                        if (Gifbitmap.Width > PotentialWidthOfImage && Gifbitmap.Width < PotentialWidthOfImage + 700)
                        {
                            GifImage.Height = Gifbitmap.Height / Divisor;
                            GifImage.Width = Gifbitmap.Width / Divisor;

                            // canvasBorder.Width = canvas.Width;
                            // canvasBorder.Height = canvas.Height;
                            ratio = Divisor;


                        }
                        else if ((Gifbitmap.Height > mainWindow.Height - mainWindow.Height * 0.1) && (Gifbitmap.Height > Gifbitmap.Width))
                        {

                            GifImage.Height = mainWindow.Height - mainWindow.Height * 0.15;
                            Divisor = Gifbitmap.Height / GifImage.Height;
                            GifImage.Width = Gifbitmap.Width / Divisor;
                            ratio = Divisor;


                            // MessageBox.Show("varianta 2");

                            break;
                        }

                        PotentialWidthOfImage += 700;
                        Divisor += 0.8;

                    }
                }
                else
                {
                    PotentialWidthOfImage = 0;
                    Divisor = 1;
                    for (int i = 0; i < 7; i++)
                    {
                        //if (Size_Of_Uploaded_Image.Width > 700 && Size_Of_Uploaded_Image.Height > 2 * Size_Of_Uploaded_Image.Width)
                        //{
                        //    canvas.Height = Size_Of_Uploaded_Image.Height / 3;
                        //    canvas.Width = Size_Of_Uploaded_Image.Width / 3;


                        //    // canvasBorder.Width = canvas.Width;
                        //    // canvasBorder.Height = canvas.Height;
                        //    sizeAfterOpen.Width = canvas.Width;
                        //    sizeAfterOpen.Height = canvas.Height;
                        //    Canvas_Size.Width = canvas.Width;
                        //    Canvas_Size.Height = canvas.Height;
                        //    Canvas_Size_On_Open.Width = canvas.Width;
                        //    Canvas_Size_On_Open.Height = canvas.Height;
                        //}


                        /* else*/
                        if (this.Gifbitmap.Width > PotentialWidthOfImage && this.Gifbitmap.Width < PotentialWidthOfImage + 700)
                        {
                            canvas.Height = this.Gifbitmap.Height / Divisor;
                            canvas.Width = this.Gifbitmap.Width / Divisor;

                            // canvasBorder.Width = canvas.Width;
                            // canvasBorder.Height = canvas.Height;
                            ratio = Divisor;
                            sizeAfterOpen.Width = canvas.Width;
                            sizeAfterOpen.Height = canvas.Height;
                            Canvas_Size.Width = canvas.Width;
                            Canvas_Size.Height = canvas.Height;
                            Canvas_Size_On_Open.Width = canvas.Width;
                            Canvas_Size_On_Open.Height = canvas.Height;
                            SizeAfterZoom.Width = canvas.Width;
                            SizeAfterZoom.Height = canvas.Height;
                            // MessageBox.Show("varianta 1");
                            //MessageBox.Show(Convert.ToString(Divisor));

                        }
                        else if ((this.Gifbitmap.Height > mainWindow.Height - mainWindow.Height * 0.1) && (this.Gifbitmap.Height > this.Gifbitmap.Width))
                        {

                            canvas.Height = mainWindow.Height - mainWindow.Height * 0.15;
                            Divisor = this.Gifbitmap.Height / canvas.Height;
                            canvas.Width = this.Gifbitmap.Width / Divisor;
                            ratio = Divisor;

                            sizeAfterOpen.Width = canvas.Width;
                            sizeAfterOpen.Height = canvas.Height;
                            Canvas_Size.Width = canvas.Width;
                            Canvas_Size.Height = canvas.Height;
                            Canvas_Size_On_Open.Width = canvas.Width;
                            Canvas_Size_On_Open.Height = canvas.Height;
                            SizeAfterZoom.Width = canvas.Width;
                            SizeAfterZoom.Height = canvas.Height;
                            // MessageBox.Show("varianta 2");

                            break;
                        }

                        PotentialWidthOfImage += 700;
                        Divisor += 0.8;

                    }
                    canvas_Zoom_ratio_Size.Width = canvas.Width;
                    canvas_Zoom_ratio_Size.Height = canvas.Height;
                    pathSegments.Clear();
                    LineSegment lineSegment1 = new LineSegment();
                    LineSegment lineSegment2 = new LineSegment();
                    LineSegment lineSegment3 = new LineSegment();
                    LineSegment lineSegment4 = new LineSegment();

                    lineSegment2.Point = new Point(canvas.Width, 0);
                    lineSegment3.Point = new Point(canvas.Width, canvas.Height);
                    lineSegment4.Point = new Point(0, canvas.Height);
                    pathFigure.StartPoint = lineSegment1.Point = new Point(0, 0);
                    pathSegments.Add(lineSegment2);
                    pathSegments.Add(lineSegment3);
                    pathSegments.Add(lineSegment4);

                    ResetScaleFactor(st);
                }

            }
            else
            {


            }

        }
        //Skryje rozbalen menu výběru

        //Funkce, která otevře dialogové okno ukládání a uloží soubor
        public void SaveImage(SaveFileDialog saveFileDialog, string activecontrol)
        {
            if (activecontrol == "SelectionPolygon")
            {
                saveFileDialog.Filter = "Png Image (.png)|*.png";
                saveFileDialog.FileOk += OkSavePressed;
                if (saveFileDialog.ShowDialog() == true)
                {
                }
            }
            else
            {
                saveFileDialog.Filter = "Bitmap Image (.bmp)|*.bmp|Gif Image (.gif)|*.gif|JPEG Image (.jpeg)|*.jpeg|Png Image (.png)|*.png";
                saveFileDialog.FileOk += OkSavePressed;
                if (saveFileDialog.ShowDialog() == true)
                {
                }
            }

        }
        //Funkce, která se provede po stisknutí tlačítka uložit v dialogovém okně
        void OkSavePressed(object sender, CancelEventArgs e)
        {
            AskForAnimatedGif(((MainWindow)Application.Current.MainWindow).saveFileDialog);

        }

        /*Funkce, která se spustí po stisknutí tlačítka Save. Spouští funkci, uloží soubor ve složce
         původního souboru a vytvoří koupii s EditorCopy na konci,pokud tato verze původního obrázku už existuje, smaže ji a nahradí
        ji novou*/
        public void CreateSaveCopyFile(string ActiveControl, bool is_polygon_created, bool pictureuploaded)
        {
            if (pictureuploaded == true)
            {
                if (ActiveControl == "SelectionPolygon" || is_polygon_created == true)
                {
                    string path = original_file_directory + @"\" + original_file_name + "-EditorCopy" + ".png";
                    System.IO.File.Delete(path);
                    DirectlySaveFile(((MainWindow)Application.Current.MainWindow).MainPicture, path,
                ((MainWindow)Application.Current.MainWindow).size_of_croppedarea,
                ((MainWindow)Application.Current.MainWindow).active_Control, ((MainWindow)Application.Current.MainWindow).original_Image,
                ((MainWindow)Application.Current.MainWindow).Is_polygon_created, ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size,
                  ((MainWindow)Application.Current.MainWindow).Is_PictureRotated, ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed,
                  ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added);
                    MessageBox.Show("Saved succesfully");
                }
                else
                {

                    string path = original_file_directory + @"\" + original_file_name + "-EditorCopy" + original_file_ext;
                    System.IO.File.Delete(path);
                    DirectlySaveFile(((MainWindow)Application.Current.MainWindow).MainPicture, path,
                  ((MainWindow)Application.Current.MainWindow).size_of_croppedarea,
                  ((MainWindow)Application.Current.MainWindow).active_Control, ((MainWindow)Application.Current.MainWindow).original_Image,
                  ((MainWindow)Application.Current.MainWindow).Is_polygon_created, ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size,
                  ((MainWindow)Application.Current.MainWindow).Is_PictureRotated, ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed
                  , ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added);
                    MessageBox.Show("Saved succesfully");
                }
            }
        }
        //Funkce, která přímo uloží soubor bez dialogového okna

        public void DirectlySaveFile(Canvas canvas, string filename, Size sizeofcrop, string Active_control, BitmapSource OriginalImage, bool is_polygon_created, Size ResizeCanvasSize, bool rotated, bool Is_DPI_Changed, bool isshapeperma)
        {
            if (Active_control == "SelectionPolygon" || is_polygon_created == true || ((MainWindow)Application.Current.MainWindow).openFileDialog.FileName.EndsWith(".gif") )
            {

                BitmapSource bitmapSource = ConvertToBitmapSource(canvas, sizeofcrop);
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                using (FileStream stream = new FileStream(filename, FileMode.Create))
                {
                    encoder.Save(stream);
                }
            }
            else
            {

                BitmapSource bitmapSource = ConvertToBitmapSource(canvas, ResizeCanvasSize);
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                using (FileStream stream = new FileStream(filename, FileMode.Create))
                {
                    encoder.Save(stream);
                }
            }
        }
        //Funkce, která convertuje pozadí controlu na typ BitmapSource
        public BitmapSource ConvertToBitmapSource(UIElement element, Size sizeofcrop)
        {
            var target = new RenderTargetBitmap((int)(sizeofcrop.Width), (int)(sizeofcrop.Height), 96, 96, PixelFormats.Pbgra32);

            var brush = new VisualBrush(element);

            var visual = new DrawingVisual();
            var drawingContext = visual.RenderOpen();


            drawingContext.DrawRectangle(brush, null, new Rect(new Point(0, 0), new Point((int)(sizeofcrop.Width), (int)(sizeofcrop.Height))));

            drawingContext.Close();

            target.Render(visual);

            return target;
        }
        //Nastaví velikost aplikace, podle velikosti obrazovky
        public void SetWindowSize(Window window)
        {
            double screen_width = SystemParameters.PrimaryScreenWidth;
            double screen_height = SystemParameters.PrimaryScreenHeight;
            //MessageBox.Show(String.Format("{0}{1}", screen_width, screen_height));
            window.Width = screen_width / 1.5;
            window.Height = screen_height / 1.2;
        }

        public void CTRLplusZShortcutPressed(KeyEventArgs e, ref bool Is_Shortcut_pressed)
        {
            if (e.Key == Key.LeftCtrl)
            {
                Is_Ctrl_Held = true;

            }
            if ((e.Key == Key.Z) && Is_Ctrl_Held == true)
            {
                Is_Shortcut_pressed = true;
                Is_Ctrl_Held = false;
            }


        }

        public void CTRLReleased(KeyEventArgs e)
        {
            if (e.Key == Key.LeftCtrl)
            {
                Is_Ctrl_Held = false;
            }
        }

        public void AskForAnimatedGif(SaveFileDialog savefiledialog)
        {
            Is_File_Gif_Format = savefiledialog.FileName.EndsWith(".gif");
            if (Is_File_Gif_Format == true)
            {
                MessageBoxResult messageboxressult = MessageBox.Show("Dou you want to anime the Gif?", "", MessageBoxButton.YesNo);
                if (messageboxressult == MessageBoxResult.Yes)
                {
                    AnimatedGifEncoder animatedGifEncoder = new AnimatedGifEncoder();
                    //FileStream stream = new FileStream("newGIF.Animated.gif", FileMode.Create);
                    FileStream savestream = new FileStream(savefiledialog.FileName, FileMode.Create);
                   
                    //File.Delete((nameoffile - 2).ToString() + ".gif");
                    animatedGifEncoder.Start(savestream);
                    animatedGifEncoder.SetRepeat(0);
                    animatedGifEncoder.SetQuality(256);

                    if (((LayersWindows)Application.Current.Windows[14]).FramerateTxtBox.Text != "")
                    {
                        animatedGifEncoder.SetFrameRate(Convert.ToInt32(((LayersWindows)Application.Current.Windows[14]).FramerateTxtBox.Text));
                    }
                    else
                    {
                        animatedGifEncoder.SetFrameRate(8);
                    }
                    for (int i = 0; i < ((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate.Count; i++)
                    {
                        System.Drawing.Image image;
                        BitmapSource bitmapsource;

                        bitmapsource = (BitmapSource)((LayersWindows)Application.Current.Windows[14]).list_Of_Images_To_Animate[i].Source;

                        image = BitmapConversion.ToWinFormsBitmap(bitmapsource);



                        animatedGifEncoder.AddFrame(image);

                        //collection.Add(Convert.ToString(i+1)+".png");
                        //collection[i].AnimationDelay = 100;
                        // MessageBox.Show(Convert.ToString(i + 1) + ".png");
                    }


                    animatedGifEncoder.Finish();
                    savestream.Close();
                    savestream.Dispose();
                    MessageBox.Show("Saved");
                }
                if (messageboxressult == MessageBoxResult.No)
                {


                    BitmapSource bitmapSource;
                    bitmapSource = ((MainWindow)Application.Current.MainWindow).first_bitmap_frame;
                    var encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(bitmapSource));
                    using (FileStream stream = new FileStream(savefiledialog.FileName, FileMode.Create))
                    {
                        encoder.Save(stream);
                    }

                }
            }
            else
            {

                DirectlySaveFile(((MainWindow)Application.Current.MainWindow).MainPicture, ((MainWindow)Application.Current.MainWindow).saveFileDialog.FileName,
                               ((MainWindow)Application.Current.MainWindow).size_of_croppedarea,
                               ((MainWindow)Application.Current.MainWindow).active_Control, ((MainWindow)Application.Current.MainWindow).original_Image,
                               ((MainWindow)Application.Current.MainWindow).Is_polygon_created, ((MainWindow)Application.Current.MainWindow).resize_Canvas_Size,
                  ((MainWindow)Application.Current.MainWindow).Is_PictureRotated, ((MainWindow)Application.Current.MainWindow).Is_Dpi_Changed,
                  ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added);

            }
        }
        public void PutImageToMiddle(Canvas uppercanvas, Canvas mainpicture, ref bool Is_ResetDone, ref bool is_cut_done, Image gifImage, ref bool Is_Open_Pressed)
        {
            //stackpanel.Width = double.NaN;
            //stackpanel.Height = double.NaN;
            if (gifImage.Visibility == Visibility.Visible)
            {
                Canvas.SetLeft(gifImage, uppercanvas.ActualWidth / 2 - gifImage.Width / 2);
                Canvas.SetTop(gifImage, uppercanvas.ActualHeight / 2 - gifImage.Height / 2);
            }
            else if (Is_Open_Pressed || Is_ResetDone || is_cut_done)
            {
                Canvas.SetLeft(mainpicture, uppercanvas.ActualWidth / 2 - mainpicture.Width / 2);
                Canvas.SetTop(mainpicture, uppercanvas.ActualHeight / 2 - mainpicture.Height / 2);

                Is_Open_Pressed = false;
                Is_ResetDone = false;
                is_cut_done = false;
            }
            else
            {

            }
        }

        public void ResetScaleFactor(ScaleTransform st)
        {
            st.ScaleX = 1;
            st.ScaleY = 1;
        }

        public void CutDone(ref bool is_cut_done)
        {
            is_cut_done = true;
        }
        public void PutLineSegmentsToCorners()
        {
            ((MainWindow)Application.Current.MainWindow).pathfigure.StartPoint = new Point(0, 0);
            LineSegment linesegment1 = new LineSegment();
            LineSegment linesegment2 = new LineSegment();
            LineSegment linesegment3 = new LineSegment();
            linesegment1.Point = new Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, 0);
            linesegment2.Point = new Point(((MainWindow)Application.Current.MainWindow).MainPicture.Width, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);
            linesegment3.Point = new Point(0, ((MainWindow)Application.Current.MainWindow).MainPicture.Height);

            ((MainWindow)Application.Current.MainWindow).segmentColection.Clear();
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment1);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment2);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment3);

        }

     

        //private void SetAnimation(Image GifImage,Stream imagestreamsource)
        //{
        //    Animator animator = ;
        //    animator.Dispose();
        //    AnimationBehavior.SetSourceStream(GifImage, imagestreamsource);
        //    AnimationBehavior.SetRepeatBehavior(GifImage, RepeatBehavior.Forever);
        //}


        #region Tisk

        public void TiskObrazku(PrintDialog printdialog, Canvas mainpicture, bool Is_picture_uploaded, BitmapSource original_Image)
        {
            if (Is_picture_uploaded)
            {
                if (printdialog.ShowDialog() == true)
                {
                    Brush brush;
                    Brush load_Back_Brush;
                    BitmapSource bitmapSource;
                    BitmapImage bi = new BitmapImage();
                    if (original_Image.Width > original_Image.Height)
                    {
                        TransformedBitmap transformedBitmap = new TransformedBitmap();
                        TransformedBitmap transformedBitmap2 = new TransformedBitmap();
                        RotateTransform rotateTransform = new RotateTransform(90);
                        brush = mainpicture.Background;

                        print_Image_Brush = (ImageBrush)brush;

                        bitmapSource = (BitmapSource)print_Image_Brush.ImageSource;

                        transformedBitmap.BeginInit();
                        transformedBitmap.Source = bitmapSource;
                        transformedBitmap.Transform = rotateTransform;
                        transformedBitmap.EndInit();
                        print_Image_Brush.ImageSource = transformedBitmap;
                        brush = print_Image_Brush;

                        rotateTransform.Angle = 270;
                        transformedBitmap2.BeginInit();
                        transformedBitmap2.Source = (BitmapSource)print_Image_Brush.ImageSource;

                        transformedBitmap2.Transform = rotateTransform;
                        transformedBitmap2.EndInit();
                        print_Image_Brush.ImageSource = transformedBitmap2;
                        load_Back_Brush = print_Image_Brush;
                        mainpicture.Background = load_Back_Brush;


                        FixedDocument fixeddoc = new FixedDocument();
                        FixedPage fixedpage = new FixedPage();
                        PageContent pagecontent = new PageContent();
                        fixedpage.Background = brush;
                        pagecontent.Child = fixedpage;
                        fixeddoc.Pages.Add(pagecontent);
                        printdialog.PrintDocument(fixeddoc.DocumentPaginator, "");

                        //transformedBitmap.BeginInit();


                        // transformedBitmap.EndInit();

                    }
                    else
                    {
                        brush = mainpicture.Background;
                        //print_Image_Brush = (ImageBrush)brush;
                        //bitmapSource = (BitmapSource)print_Image_Brush.ImageSource;
                        //bi = (BitmapImage)bitmapSource;
                        //using (var dc = drawing_Visual.RenderOpen())
                        //{
                        //    dc.DrawImage(bi, new Rect { Width = bi.Width, Height = bi.Height });
                        //}
                        //printdialog.PrintVisual(drawing_Visual, "");
                        FixedDocument fixeddoc = new FixedDocument();
                        FixedPage fixedpage = new FixedPage();
                        PageContent pagecontent = new PageContent();
                        fixedpage.Background = brush;
                        pagecontent.Child = fixedpage;
                        fixeddoc.Pages.Add(pagecontent);
                        printdialog.PrintDocument(fixeddoc.DocumentPaginator, "");
                    }
                }
            }
        }
        public void rotateimage(int angle)
        {


        }

        #endregion


    }









}



   