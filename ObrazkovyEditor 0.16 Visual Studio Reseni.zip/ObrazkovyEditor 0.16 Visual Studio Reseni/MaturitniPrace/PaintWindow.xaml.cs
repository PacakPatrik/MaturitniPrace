﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro PaintWindow.xaml
    /// </summary>
    public partial class PaintWindow : Window
    {
        Brush brush;
        ImageBrush imageBrush = new ImageBrush();
        ImageBrush imageBrush2 = new ImageBrush();
        BitmapImage bitmapimage = new BitmapImage();
        bool converted = false;

        ColorSelector colorselector = new ColorSelector();
        string[] comboboxsource = new string[] { "Square", "Rectangle", "Ellipse" };
        public PaintWindow()
        {
            InitializeComponent();
            ShapesCombobox.ItemsSource = comboboxsource;
            EnteredThickness.Text = "8";
            ShapesCombobox.SelectedItem = "Ellipse";
        }

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles.Clear();
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;
            ShapesCombobox.SelectedItem = "Ellipse";
        }

        private void ClearButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles.Clear();
        }


        private void SelectedColor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            colorselector.Visibility = Visibility.Visible;
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void AddButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {


            ((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image = true;
            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
            imageBrush2 = (ImageBrush)brush;
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)imageBrush2.ImageSource.Width, (int)imageBrush2.ImageSource.Height, 96, 96, PixelFormats.Pbgra32);
            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();

            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
            imageBrush2 = (ImageBrush)brush;

            drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
            try
            {
                for (int i = 0; i < ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles.Count; i++)
                {
                    Rect rectangle = new Rect();
                    rectangle.X = Canvas.GetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles[i])*((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width*((MainWindow)Application.Current.MainWindow).zoom_ratio_Width;
                    rectangle.Y = Canvas.GetTop(((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles[i]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening*((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                    rectangle.Width = ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles[i].Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width*((MainWindow)Application.Current.MainWindow).zoom_ratio_Width; 
                    rectangle.Height = ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles[i].Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height*((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                    drawingContext.DrawRectangle(((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles[i].Fill, new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0), rectangle);
                }
                //MessageBox.Show(((MainWindow)Application.Current.MainWindow).zoom_ratio_Width.ToString());
               // MessageBox.Show(string.Format("{0}   {1}   {2}   {3}", ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width, ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height, ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width, ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height));

            }
            catch {  }
            try
            {
                for (int i = 0; i < ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Count; i++)
                {
                    Ellipse ellipse = new Ellipse();

                    ellipse.Width = ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Count - 1].Width;
                    ellipse.Height = ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses[((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Count - 1].Height;

                    drawingContext.DrawEllipse(SelectedColor.Fill, 
                        new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0), 
                        new Point(((Canvas.GetLeft(((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses[i])+ellipse.Width/2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                        ((Canvas.GetTop(((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses[i])+ellipse.Height/2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height),
                       (( ellipse.Width/2 )* ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width, 
                       (( ellipse.Height/2 )* ((MainWindow)Application.Current.MainWindow).ratio_After_Opening) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                }
            }
            catch {  }

            drawingContext.Close();
            bitmap.Render(drawingVisual);
            imageBrush.ImageSource = bitmap;
            if (!converted)
            {
                var bitmapEncoder = new PngBitmapEncoder();
                bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                using (var stream = new MemoryStream())
                {
                    bitmapEncoder.Save(stream);
                    stream.Seek(0, SeekOrigin.Begin);

                    bitmapimage.BeginInit();
                    bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapimage.StreamSource = stream;
                    bitmapimage.EndInit();

                }

                imageBrush.ImageSource = bitmapimage;
                converted = true;

            
            }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();

            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Ellipses.Clear();
            ((MainWindow)Application.Current.MainWindow).list_Of_Painted_Rectangles.Clear();
        }
    }
}
