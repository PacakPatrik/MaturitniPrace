﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Windows.Input;

namespace MaturitniPrace
{
    class Paint
    {
        PaintWindow paintWindow = new PaintWindow();
        string selected;
        public void ShowPaintMenu(Rectangle rec, ref bool IsSideWindowOpened)
        {
            if (!IsSideWindowOpened)
            {
                rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
                //System.Windows.Forms.Integration.ElementHost.EnableModelessKeyboardInterop(paintWindow);
                paintWindow.Visibility = Visibility.Visible;
                IsSideWindowOpened = true;
            }
        }
        public void ReleaseMouseOnButton(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65,65,65));
        }
        bool drag;
        public void PaintMouseDown(bool pictureuploaded)
        {
            if (paintWindow.Visibility == Visibility.Visible && pictureuploaded)
            {
                drag = true;
            }
        }
        public void PaintMouseUp()
        {
            drag = false;
        }
        public void PaintMouseMove(Canvas mainpicture,List<Rectangle> rectangles, List<Ellipse> ellipses)
        {
            try
            {
                if (drag)
                {

                    Point p = Mouse.GetPosition(mainpicture);
                    selected = paintWindow.ShapesCombobox.SelectedItem.ToString();
                    if (selected == "Ellipse")
                    {
                        Ellipse ellipse = new Ellipse();
                        ellipse.Fill = paintWindow.SelectedColor.Fill;
                        ellipse.Width = Convert.ToDouble(paintWindow.EnteredThickness.Text);
                        ellipse.Height = Convert.ToDouble(paintWindow.EnteredThickness.Text);


                        mainpicture.Children.Add(ellipse);
                        Canvas.SetLeft(ellipse, p.X - ellipse.Width / 2);
                        Canvas.SetTop(ellipse, p.Y - ellipse.Height / 2);
                        ellipses.Add(ellipse);
                    }
                    if (selected == "Rectangle")
                    {
                        Rectangle rectangle = new Rectangle();
                        rectangle.Fill = paintWindow.SelectedColor.Fill;
                        rectangle.Width = Convert.ToDouble(paintWindow.EnteredThickness.Text);
                        rectangle.Height = Convert.ToDouble(paintWindow.EnteredThickness.Text) / 2;


                        mainpicture.Children.Add(rectangle);
                        Canvas.SetLeft(rectangle, p.X - rectangle.Width / 2);
                        Canvas.SetTop(rectangle, p.Y - rectangle.Height / 2);
                        rectangles.Add(rectangle);
                    }
                    if (selected == "Square")
                    {
                        Rectangle rectangle = new Rectangle();
                        rectangle.Fill = paintWindow.SelectedColor.Fill;
                        rectangle.Width = Convert.ToDouble(paintWindow.EnteredThickness.Text); ;
                        rectangle.Height = Convert.ToDouble(paintWindow.EnteredThickness.Text); ;


                        mainpicture.Children.Add(rectangle);
                        Canvas.SetLeft(rectangle, p.X - rectangle.Width / 2);
                        Canvas.SetTop(rectangle, p.Y - rectangle.Height / 2);
                        rectangles.Add(rectangle);
                    }
                }
            }
            catch { }
        }
    }
}
