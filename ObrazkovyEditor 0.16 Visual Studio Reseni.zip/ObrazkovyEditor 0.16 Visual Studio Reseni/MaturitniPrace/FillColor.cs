﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Controls;
namespace MaturitniPrace
{
    class FillColor
    {
        FillWithPolygonColor polygonColor = new FillWithPolygonColor();
        double x, y;
        public void ShowFillColorMenu(Rectangle rec, string activeControl)
        {
           
            if (activeControl == "SelectionPolygon")
            {


                polygonColor.Visibility = Visibility.Visible;
                rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
            }
            else
            {
                MessageBox.Show("Open Selection first and then Color filling option");
            }
        }
        public void FillColorMouseUp(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
        public void FillWithDesiredColor(Canvas mainpicture, bool endedpolygon,List<Point> listofpoints, ref bool isfilledwithcolor, ref Polygon filledpolygon,List<Rectangle> listofrectangles)
        {
           
            if (endedpolygon && polygonColor.Visibility==Visibility.Visible)
            {
               
                Polygon polygon = new Polygon();
                for(int i = 0; i < listofpoints.Count; i++)
                {
                    polygon.Points.Add(listofpoints[i]);
                }
                polygon.Fill = polygonColor.SelectedColor.Fill;
                filledpolygon = polygon;
                mainpicture.Children.Add(filledpolygon);
                isfilledwithcolor = true;
               
            }
            if (polygonColor.Visibility==Visibility.Visible && listofrectangles.Count>0)
            {
                Rectangle rec = new Rectangle();
               
                rec.Fill = polygonColor.SelectedColor.Fill;
                x=Canvas.GetLeft(listofrectangles[listofrectangles.Count - 1]);
                y=Canvas.GetTop(listofrectangles[listofrectangles.Count - 1]);
                rec.Width = listofrectangles[listofrectangles.Count - 1].Width;
                rec.Height= listofrectangles[listofrectangles.Count - 1].Height;
                ((MainWindow)Application.Current.MainWindow).FilledRectangle = rec;
                mainpicture.Children.Add(((MainWindow)Application.Current.MainWindow).FilledRectangle);
                Canvas.SetLeft(rec, x);
                Canvas.SetTop(rec, y);
                isfilledwithcolor = true;
                
            }

        }
    }
}
