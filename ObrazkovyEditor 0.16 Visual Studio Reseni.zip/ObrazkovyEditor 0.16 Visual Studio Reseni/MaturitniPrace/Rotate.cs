﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Collections.Generic;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Controls;
using System;

namespace MaturitniPrace
{
    
    class Rotate
    {
       
        ImageBrush image_brush;
        
        Size New_Size;
        public void DarkenTheButtonAfterPress(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(40, 40, 40));
        }
        public void LightenTheButtonAfterReleas(Rectangle rec)
        {
            rec.Fill = new SolidColorBrush(Color.FromRgb(65, 65, 65));
        }
        public void RotateCanvas(BitmapSource originalimage, Canvas mainpicture, Canvas uppercanvas, ref bool rotate,ref Size ResizeCanvasSize, bool pictureUploaded)
        {
            if (pictureUploaded)
            {
                Brush brush;

                BitmapSource bitmapSource;
                TransformedBitmap transformedBitmap = new TransformedBitmap();

                brush = mainpicture.Background;

                image_brush = (ImageBrush)brush;
                RotateTransform rotateTransform = new RotateTransform(90);
                bitmapSource = (BitmapSource)image_brush.ImageSource;
               
                transformedBitmap.BeginInit();
                transformedBitmap.Source = bitmapSource;
                transformedBitmap.Transform = rotateTransform;

                transformedBitmap.EndInit();
                BitmapSource bitmpsource;
                bitmpsource = transformedBitmap;
              
                
                image_brush.ImageSource = bitmpsource;
                //MessageBox.Show(string.Format("{0} {1}", image_brush.ImageSource.Width, image_brush.ImageSource.Height));


                mainpicture.Background = image_brush;
                New_Size.Height = mainpicture.Width;
                New_Size.Width = mainpicture.Height;
                if (New_Size.Width > uppercanvas.Width)
                {
                    New_Size.Width = uppercanvas.Width - 50;
                }
                if (New_Size.Height > uppercanvas.Height)
                {
                    New_Size.Height = uppercanvas.Height - 50;
                }
                //if(New_Size.Width> ((MainWindow)Application.Current.MainWindow).Width - ((MainWindow)Application.Current.MainWindow).Width * 0.2)
                //  {
                //      New_Size.Width = ((MainWindow)Application.Current.MainWindow).Width - ((MainWindow)Application.Current.MainWindow).Width * 0.2;
                //  }
                //  if (New_Size.Height > ((MainWindow)Application.Current.MainWindow).Height- ((MainWindow)Application.Current.MainWindow).Height* 0.2)
                //  {
                //      New_Size.Height= ((MainWindow)Application.Current.MainWindow).Height- ((MainWindow)Application.Current.MainWindow).Height * 0.2;
                //  }

                mainpicture.Height = New_Size.Height;
                mainpicture.Width = New_Size.Width;
                ResizeCanvasSize.Height = mainpicture.Height;
                ResizeCanvasSize.Width = mainpicture.Width;
                ImageToMiddle(uppercanvas, mainpicture);
                PutLineSegmentsToCorners();
                rotate = true;
            }
            //((MainWindow)Application.Current.MainWindow).MainPicture.Width = ((MainWindow)Application.Current.MainWindow).Canvas_Size.Width;
            //((MainWindow)Application.Current.MainWindow).MainPicture.Height = ((MainWindow)Application.Current.MainWindow).Canvas_Size.Height;

            //MessageBox.Show(string.Format("{0} {1}", mainpicture.Width, mainpicture.Height));
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Width = New_Size.Width;
            //((MainWindow)Application.Current.MainWindow).uppercanvas.Height= New_Size.Height;


            //image_brush.ImageSource = new BitmapImage(new Uri(((MainWindow)Application.Current.MainWindow).openFileDialog.FileName));




            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Width = New_Size.Width;
            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Height= New_Size.Height;



            //((MainWindow)Application.Current.MainWindow).CanvasesStackPanel.Height = double.NaN;





            //brush = mainpicture.Background;

            //image_brush = (ImageBrush)brush;

            //bitmapimage = (BitmapImage)image_brush.ImageSource;
            //transformedBitmap.BeginInit();
            //transformedBitmap.Source = bitmapimage;
            //transformedBitmap.Transform = rotateTransform;
            //transformedBitmap.EndInit();
            //image_brush.ImageSource = transformedBitmap;
            //mainpicture.Background = image_brush;
            //
            //
            //brush = null;
        }

        public void ImageToMiddle(Canvas uppercanvas, Canvas mainpicture)
        {
            Canvas.SetLeft(mainpicture, uppercanvas.ActualWidth / 2 - mainpicture.Width / 2);
            Canvas.SetTop(mainpicture, uppercanvas.ActualHeight/ 2 - mainpicture.Height / 2);
            //MessageBox.Show("hej");
        }
        public void PutLineSegmentsToCorners()
        {
            ((MainWindow)Application.Current.MainWindow).pathfigure.StartPoint = new Point(0, 0);
            LineSegment linesegment1 = new LineSegment();
            LineSegment linesegment2 = new LineSegment();
            LineSegment linesegment3 = new LineSegment();
            linesegment1.Point = new Point(((MainWindow)Application.Current.MainWindow).uppercanvas.Width, 0);
            linesegment2.Point = new Point(((MainWindow)Application.Current.MainWindow).uppercanvas.Width, ((MainWindow)Application.Current.MainWindow).uppercanvas.Height);
            linesegment3.Point = new Point(0, ((MainWindow)Application.Current.MainWindow).uppercanvas.Height);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Clear();
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment1);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment2);
            ((MainWindow)Application.Current.MainWindow).segmentColection.Add(linesegment3);
        }
    }

    
}
