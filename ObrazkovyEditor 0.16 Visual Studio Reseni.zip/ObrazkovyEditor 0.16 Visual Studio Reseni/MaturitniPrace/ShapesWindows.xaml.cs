﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;
using System.IO;
using System.Windows.Interop;
using System.Drawing.Imaging;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro ShapesWindows.xaml
    /// </summary>
    public partial class ShapesWindows : Window
    {
        ColorSelector colorSelector = new ColorSelector();
        List<System.Windows.Point> listOfPoints = new List<System.Windows.Point>();
        List<Ellipse> listOfElipses= new List<Ellipse>();
        List<Line> listOfLines= new List<Line>();
        List<Shape> listofshapes = new List<Shape>();
        public Polygon ShapeSPollygon;
        Ellipse ShapesEllipse;
        ImageBrush imageBrush = new ImageBrush();
        ImageBrush imageBrush2 = new ImageBrush();
        System.Windows.Media.Brush brush;
        BitmapImage bitmapimage=new BitmapImage();

        public string ShapeType;

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

 
        bool converted=false;
       
        public ShapesWindows()
        {
            InitializeComponent();
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }


        //private Bitmap MergedBitmaps(Bitmap bmp1, Bitmap bmp2)
        //{
        //    Bitmap result = new Bitmap(Math.Max(bmp1.Width, bmp2.Width),
        //                               Math.Max(bmp1.Height, bmp2.Height));
        //    using (Graphics g = Graphics.FromImage(result))
        //    {
        //        g.DrawImage(bmp2, System.Drawing.Point.Empty);
        //        g.DrawImage(bmp1, new System.Drawing.Point((int)Canvas.GetLeft(listofshapes[listofshapes.Count-1]), (int)Canvas.GetTop(listofshapes[listofshapes.Count - 1])));
        //    }
        //    return result;
        //}

        //private Bitmap BitmapImage2Bitmap(BitmapImage bitmapImage)
        //{
        //    // BitmapImage bitmapImage = new BitmapImage(new Uri("../Images/test.png", UriKind.Relative));

        //    using (MemoryStream outStream = new MemoryStream())
        //    {
        //        BitmapEncoder enc = new BmpBitmapEncoder();
        //        enc.Frames.Add(BitmapFrame.Create(bitmapImage));
        //        enc.Save(outStream);
        //        System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(outStream);

        //        return new Bitmap(bitmap);
        //    }
        //}

    

        //private BitmapImage Bitmap2BitmapImage(Bitmap bitmap)
        //{
        //    MemoryStream ms = new MemoryStream();
        //    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
        //    BitmapImage image = new BitmapImage();
        //    image.BeginInit();
        //    ms.Seek(0, SeekOrigin.Begin);
        //    image.StreamSource = ms;
        //    image.EndInit();
        //    return image;
        //}
        //public BitmapImage ToBitmapImage(Bitmap bitmap)
        //{
        //    using (var memory = new MemoryStream())
        //    {
        //        bitmap.Save(memory, ImageFormat.Png);
        //        memory.Position = 0;

        //        var bitmapImage = new BitmapImage();
        //        bitmapImage.BeginInit();
        //        bitmapImage.StreamSource = memory;
        //        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
        //        bitmapImage.EndInit();
        //        bitmapImage.Freeze();

        //        return bitmapImage;
        //    }
        //}

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
           
             
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = false;
                //brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                //imageBrush2 = (ImageBrush)brush;
                //bitmap2 = MergedBitmaps(BitmapImage2Bitmap(bitmapimage), BitmapImage2Bitmap((BitmapImage)imageBrush2.ImageSource));
                //finalbitmap = Bitmap2BitmapImage(bitmap2);
                listofshapes.Clear();
            //imageBrush.ImageSource = finalbitmap;
            //((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
            //((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            this.Visibility = Visibility.Hidden;
            ((MainWindow)Application.Current.MainWindow).Is_Side_Window_Opened = false;

        }

        private void Square_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded && ((MainWindow)Application.Current.MainWindow).Is_Shape_Added==false)
            {
                //MessageBox.Show("hej");
                System.Windows.Shapes.Rectangle rectangle = new System.Windows.Shapes.Rectangle();
                rectangle.Width = 100;
                rectangle.Height = 100;
                rectangle.Fill = SelectColor.Fill;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rectangle);
                Canvas.SetLeft(rectangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2 - rectangle.Width / 2);
                Canvas.SetTop(rectangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2 - rectangle.Height / 2);
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = true;
                ((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Add(rectangle);
                listofshapes.Add(rectangle);
                ShapeType = "Rectangle";
            }
        
        }

        private void Rectangle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded && ((MainWindow)Application.Current.MainWindow).Is_Shape_Added == false)
            {
                System.Windows.Shapes.Rectangle rectangle = new System.Windows.Shapes.Rectangle();
                rectangle.Width = 120;
                rectangle.Height = 50;
                rectangle.Fill = SelectColor.Fill;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(rectangle);
                Canvas.SetLeft(rectangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2 - rectangle.Width / 2);
                Canvas.SetTop(rectangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2 - rectangle.Height / 2);
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = true;
                ((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Add(rectangle);
                listofshapes.Add(rectangle);
                ShapeType = "Rectangle";
            }
        }

        //private void Triangle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        //{
        //    if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded && ((MainWindow)Application.Current.MainWindow).Is_Shape_Added == false)
        //    {
        //        Polygon triangle = new Polygon();
        //        triangle.Points.Add(new System.Windows.Point(0, 11 * 10));
        //        triangle.Points.Add(new System.Windows.Point(6 * 10, 2 * 10));
        //        triangle.Points.Add(new System.Windows.Point(11 * 10, 11 * 10));
        //        triangle.Fill = SelectColor.Fill;
        //        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(triangle);
        //        Canvas.SetLeft(triangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2 - triangle.ActualWidth / 2);
        //        Canvas.SetTop(triangle, ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2 - triangle.ActualHeight / 2);
        //        ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = true;
        //        ((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Add(triangle);
        //        ShapeSPollygon = triangle;
        //        ShapeType = "Polygon";
        //    }
        //}

        private void Circle_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded && ((MainWindow)Application.Current.MainWindow).Is_Shape_Added == false)
            {
                Ellipse ellipse = new Ellipse();
                ellipse.Height = 100;
                ellipse.Width = 100;
                ellipse.Fill = SelectColor.Fill;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(ellipse);
                Canvas.SetLeft(ellipse, ((MainWindow)Application.Current.MainWindow).MainPicture.Width / 2 - ellipse.Width / 2);
                Canvas.SetTop(ellipse, ((MainWindow)Application.Current.MainWindow).MainPicture.Height / 2 - ellipse.Height / 2);
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = true;
                ((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Add(ellipse);
                ShapesEllipse = ellipse;
                listofshapes.Add(ellipse);
                ShapeType = "Ellipse";
            }
        }

        private void SelectColor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            colorSelector.Visibility = Visibility.Visible;
        }

        //private void ShapeCanvas_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        //{
        //    if (((MainWindow)Application.Current.MainWindow).Is_Shape_Added == false && ((MainWindow)Application.Current.MainWindow).Is_Picture_Uploaded) {
        //        System.Windows.Point p = Mouse.GetPosition(ShapeCanvas);
        //        if (listOfLines.Count > 0 && listOfLines[listOfLines.Count - 1].X2 < listOfLines[0].X1 + 5 && listOfLines[listOfLines.Count - 1].X2 > listOfLines[0].X1 - 5 &&
        //           listOfLines[listOfLines.Count - 1].Y2 < listOfLines[0].Y1 + 5 && listOfLines[listOfLines.Count - 1].Y2 > listOfLines[0].Y1 - 5)
        //        {
        //            draw = false;
        //            removedpoint = false;
        //            Polygon polygon = new Polygon();
        //            for (int i = 0; i < listOfPoints.Count; i++)
        //            {
        //                polygon.Points.Add(listOfPoints[i]);
        //            }
        //            polygon.Fill = SelectColor.Fill;
                 
        //            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Add(polygon);
        //            ((MainWindow)Application.Current.MainWindow).list_Of_Shapes.Add(polygon);
        //            ShapeSPollygon = polygon;
        //            ShapeCanvas.Children.Clear();
        //            listOfElipses.Clear();
        //            listOfLines.Clear();
        //            listOfPoints.Clear();
        //            ((MainWindow)Application.Current.MainWindow).Is_Shape_Added=true;
        //            ShapeType = "Polygon";
        //        }
        //        else
        //        {

        //            if (IsStopped == false && removedpoint == false && listOfPoints.Count > 0 && p.X > Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) - 5 && p.X < Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) + 5 &&
        //                      p.Y > Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) - 5 && p.Y < Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) + 5)
        //            {
        //                draw = false;
        //                removedpoint = false;


        //                ShapeCanvas.Children.Clear();
        //                listOfElipses.Clear();
        //                listOfLines.Clear();
        //                listOfPoints.Clear();
        //            }
        //            else if (removedpoint == false && IsStopped == false)
        //            {

        //                draw = true;
        //                listOfPoints.Add(p);
        //                Ellipse ellipse = new Ellipse();

        //                Line line = new Line();
        //                line.Stroke = new SolidColorBrush(Colors.Black);
        //                line.X1 = listOfPoints[listOfPoints.Count - 1].X;
        //                line.Y1 = listOfPoints[listOfPoints.Count - 1].Y;
        //                line.X2 = line.X1;
        //                line.Y2 = line.Y1;
        //                ellipse.Width = 5;
        //                ellipse.Height = 5;
        //                ellipse.Fill = new SolidColorBrush(Colors.Orange);
        //                listOfElipses.Add(ellipse);
        //                listOfLines.Add(line);
        //                Canvas.SetLeft(ellipse, listOfPoints[listOfPoints.Count - 1].X - 2);
        //                Canvas.SetTop(ellipse, listOfPoints[listOfPoints.Count - 1].Y - 2);
        //                ShapeCanvas.Children.Add(ellipse);
        //                ShapeCanvas.Children.Add(line);
        //            }
        //            else if (removedpoint == true && p.X > Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) - 5 && p.X < Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) + 5 &&
        //                      p.Y > Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) - 5 && p.Y < Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) + 5 || IsStopped == true)
        //            {
        //                draw = true;
        //                Line line = new Line();
        //                line.Stroke = new SolidColorBrush(Colors.Black);
        //                line.X1 = listOfPoints[listOfPoints.Count - 1].X;
        //                line.Y1 = listOfPoints[listOfPoints.Count - 1].Y;
        //                line.X2 = line.X1;
        //                line.Y2 = line.Y1;
        //                listOfLines.Add(line);
        //                ShapeCanvas.Children.Add(line);
        //                removedpoint = false;
        //                IsStopped = false;
        //            }
        //        }
        //    }
        //}

        //private void ShapeCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
        //{
        //    if ( listOfLines.Count > 0 && draw == true )
        //    {

        //        listOfLines[listOfLines.Count - 1].X2 = Mouse.GetPosition(ShapeCanvas).X;
        //        listOfLines[listOfLines.Count - 1].Y2 = Mouse.GetPosition(ShapeCanvas).Y;
        //    }
        //    if (  listOfLines.Count > 0)
        //    {
        //        System.Windows.Point pos = Mouse.GetPosition(ShapeCanvas);
        //        try
        //        {
        //            if (pos.X > Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) - 5 && pos.X < Canvas.GetLeft(listOfElipses[listOfElipses.Count - 1]) + 5 &&
        //                pos.Y > Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) - 5 && pos.Y < Canvas.GetTop(listOfElipses[listOfElipses.Count - 1]) + 5)
        //            {
        //                /*Canvas.SetTop(listOfellipses[listOfellipses.Count - 1], Canvas.GetTop(listOfellipses[listOfellipses.Count - 1]) - 1);
        //                Canvas.SetLeft(listOfellipses[listOfellipses.Count - 1], Canvas.GetLeft(listOfellipses[listOfellipses.Count - 1]) - 1);*/
        //                listOfElipses[listOfElipses.Count - 1].Width = 10;
        //                listOfElipses[listOfElipses.Count - 1].Height = 10;
        //            }
        //            else
        //            {
        //                listOfElipses[listOfElipses.Count - 1].Width = 5;
        //                listOfElipses[listOfElipses.Count - 1].Height = 5;
        //            }
        //        }
        //        catch { MessageBox.Show("chyba"); }
        //    }
        //}

        private void AddButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).Is_Smthg_Added_To_Image = true;
            brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
            imageBrush2 = (ImageBrush)brush;
            RenderTargetBitmap bitmap = new RenderTargetBitmap((int)imageBrush2.ImageSource.Width, (int)imageBrush2.ImageSource.Height, 96, 96, PixelFormats.Pbgra32);
            DrawingVisual drawingVisual = new DrawingVisual();
            DrawingContext drawingContext = drawingVisual.RenderOpen();
            if (ShapeType == "Rectangle")
            {
                brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                imageBrush2 = (ImageBrush)brush;

                Rect rectangle = new Rect();

                rectangle.X = Canvas.GetLeft(listofshapes[listofshapes.Count - 1]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width;
                rectangle.Y = Canvas.GetTop(listofshapes[listofshapes.Count - 1]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening* ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height* ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                rectangle.Width = listofshapes[listofshapes.Count - 1].Width * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening*((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width;
                rectangle.Height = listofshapes[listofshapes.Count - 1].Height * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening*((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height;
                drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
                drawingContext.DrawRectangle(SelectColor.Fill, new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0), rectangle);
                drawingContext.Close();
                bitmap.Render(drawingVisual);
                imageBrush.ImageSource = bitmap;
                if (!converted)
                {
                    var bitmapEncoder = new PngBitmapEncoder();
                    bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                    using (var stream = new MemoryStream())
                    {
                        bitmapEncoder.Save(stream);
                        stream.Seek(0, SeekOrigin.Begin);

                        bitmapimage.BeginInit();
                        bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapimage.StreamSource = stream;
                        bitmapimage.EndInit();

                    }

                    imageBrush.ImageSource = bitmapimage;
                    converted = true;
                }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added = true;
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = false;
                //brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                //imageBrush2 = (ImageBrush)brush;
                //bitmap2 = MergedBitmaps(BitmapImage2Bitmap(bitmapimage), BitmapImage2Bitmap((BitmapImage)imageBrush2.ImageSource));
                //finalbitmap = Bitmap2BitmapImage(bitmap2);
                //listofshapes.Clear();
                //imageBrush.ImageSource = finalbitmap;
                //((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
                //((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
            }
            if (ShapeType == "Ellipse")
            {
                brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
                imageBrush2 = (ImageBrush)brush;



                drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
                drawingContext.DrawEllipse(SelectColor.Fill, new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0),
                   new System.Windows.Point(Canvas.GetLeft(listofshapes[listofshapes.Count - 1]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening + (listofshapes[listofshapes.Count - 1].Width / 2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                   Canvas.GetTop(listofshapes[listofshapes.Count - 1]) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening + (listofshapes[listofshapes.Count - 1].Height / 2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height),
                   (listofshapes[listofshapes.Count - 1].Width / 2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Width * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Width,
                   (listofshapes[listofshapes.Count - 1].Height / 2) * ((MainWindow)Application.Current.MainWindow).ratio_After_Opening * ((MainWindow)Application.Current.MainWindow).ratio_After_Resize_Height * ((MainWindow)Application.Current.MainWindow).zoom_ratio_Height);
                drawingContext.Close();
                bitmap.Render(drawingVisual);
                imageBrush.ImageSource = bitmap;
                if (!converted)
                {
                    var bitmapEncoder = new PngBitmapEncoder();
                    bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

                    using (var stream = new MemoryStream())
                    {
                        bitmapEncoder.Save(stream);
                        stream.Seek(0, SeekOrigin.Begin);

                        bitmapimage.BeginInit();
                        bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapimage.StreamSource = stream;
                        bitmapimage.EndInit();

                    }

                    imageBrush.ImageSource = bitmapimage;
                    converted = true;
                }
                ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
                ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added = true;
                ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = false;
            }
        //    if (ShapeType == "Polygon")
        //    {
        //        StreamGeometry streamGeometry = new StreamGeometry();
        //        using (StreamGeometryContext geometryContext = streamGeometry.Open())
        //        {
        //            geometryContext.BeginFigure(new System.Windows.Point(Canvas.GetLeft(ShapeSPollygon) + ShapeSPollygon.Points[0].X, Canvas.GetTop(ShapeSPollygon) + ShapeSPollygon.Points[0].Y), true, true);
        //            PointCollection points = new PointCollection();
        //            for (int i = 1; i < ShapeSPollygon.Points.Count; i++)
        //            {
        //                points.Add(new System.Windows.Point(Canvas.GetLeft(ShapeSPollygon) + ShapeSPollygon.Points[i].X, Canvas.GetTop(ShapeSPollygon) + ShapeSPollygon.Points[i].Y));
        //            }
        //            geometryContext.PolyLineTo(points, true, true);
        //        }


        //        brush = ((MainWindow)Application.Current.MainWindow).MainPicture.Background;
        //        imageBrush2 = (ImageBrush)brush;



        //        drawingContext.DrawImage(imageBrush2.ImageSource, new Rect(0, 0, imageBrush2.ImageSource.Width, imageBrush2.ImageSource.Height));
        //        drawingContext.DrawGeometry(SelectColor.Fill, new System.Windows.Media.Pen(System.Windows.Media.Brushes.Transparent, 0), streamGeometry);
        //        drawingContext.Close();
        //        bitmap.Render(drawingVisual);
        //        imageBrush.ImageSource = bitmap;
        //        if (!converted)
        //        {
        //            var bitmapEncoder = new PngBitmapEncoder();
        //            bitmapEncoder.Frames.Add(BitmapFrame.Create(bitmap));

        //            using (var stream = new MemoryStream())
        //            {
        //                bitmapEncoder.Save(stream);
        //                stream.Seek(0, SeekOrigin.Begin);

        //                bitmapimage.BeginInit();
        //                bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
        //                bitmapimage.StreamSource = stream;
        //                bitmapimage.EndInit();

        //            }

        //            imageBrush.ImageSource = bitmapimage;
        //            converted = true;
        //        }
        //        ((MainWindow)Application.Current.MainWindow).MainPicture.Background = imageBrush;
        //        ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();
        //        ((MainWindow)Application.Current.MainWindow).Is_Shape_Permanently_Added = true;
        //        ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = false;
        //    }


        //    this.Visibility = Visibility.Hidden;
        //    colorSelector.Visibility = Visibility.Hidden;
        }

        private void Reset_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).MainPicture.Children.Clear();

            ((MainWindow)Application.Current.MainWindow).Is_Shape_Added = false;
            listofshapes.Clear();
        }
    }
}
