﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Runtime.InteropServices;

namespace MaturitniPrace
{
    /// <summary>
    /// Interakční logika pro ColorSelector.xaml
    /// </summary>
    public partial class ColorSelector : Window
    {
     
        public byte Red, Green, Blue;
        public ColorSelector()
        {
            InitializeComponent();
        }

        private void Border_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            //this.DragMove();
        }

        private void CloseButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            this.Visibility = Visibility.Hidden;

            if (!((MainWindow)Application.Current.MainWindow).Is_Right_Filter_Pressed && !((MainWindow)Application.Current.MainWindow).Is_Left_Filter_Pressed)
            {
                ((ShapesWindows)Application.Current.Windows[34]).SelectColor.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));

                ((MainWindow)Application.Current.MainWindow).ColorFilledBrush = SelectedColor.Fill;
                ((AddTextWindow)Application.Current.Windows[1]).SelectedColor.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                try
                {
                    ((AddTextWindow)Application.Current.Windows[1]).list_of_Texts[0].Foreground = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }
                catch { }
                    ((FillWithPolygonColor)Application.Current.Windows[11]).SelectedColor.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                ((PaintWindow)Application.Current.Windows[16]).SelectedColor.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                if (((MainWindow)Application.Current.MainWindow).list_Of_Points.Count>0)
                {
                    ((MainWindow)Application.Current.MainWindow).FilledPolygon.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }

            }
            if (((MainWindow)Application.Current.MainWindow).Is_Left_Filter_Pressed) 
            {
                ((FilterWindow)Application.Current.Windows[13]).LeftFilter.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                ((FilterWindow)Application.Current.Windows[13]).LeftGradientColor.Color = Color.FromRgb(Red, Green, Blue);
                if (((MainWindow)Application.Current.MainWindow).Are_Rectangles_Added)
                {
                    ((MainWindow)Application.Current.MainWindow).LowerFilterRectangle.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }
                else
                {
                    ((MainWindow)Application.Current.MainWindow).FilterPolygon1.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }
                ((MainWindow)Application.Current.MainWindow).Is_Left_Filter_Pressed = false;
            }
            if (((MainWindow)Application.Current.MainWindow).Is_Right_Filter_Pressed)
            {
                ((FilterWindow)Application.Current.Windows[13]).RightFilter.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                ((FilterWindow)Application.Current.Windows[13]).RightGradientColor.Color = Color.FromRgb(Red, Green, Blue);
                if (((MainWindow)Application.Current.MainWindow).Are_Rectangles_Added)
                {
                    ((MainWindow)Application.Current.MainWindow).UpperFilterRectangle.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }
                else
                {
                    ((MainWindow)Application.Current.MainWindow).FilterPolygon2.Fill = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                }
                    ((MainWindow)Application.Current.MainWindow).Is_Right_Filter_Pressed = false;
            }
         
        }

        private void RedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ChangeColor(RedSlider.Value, GreenSlider.Value, BlueSlider.Value);
            RedValue.Text = Convert.ToString(Math.Round(RedSlider.Value));
        }

        private void GreenSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ChangeColor(RedSlider.Value, GreenSlider.Value, BlueSlider.Value);
            GreenValue.Text = Convert.ToString(Math.Round(GreenSlider.Value));
        }

        private void BlueSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ChangeColor(RedSlider.Value, GreenSlider.Value,BlueSlider.Value);
            BlueValue.Text = Convert.ToString(Math.Round(BlueSlider.Value));
        }

      

        public void ChangeColor(double redvalue,double greenvalue,double bluevalue)
        {
            SelectedColor.Fill = new SolidColorBrush(Color.FromRgb((byte)redvalue, (byte)greenvalue,(byte)bluevalue));
            Red = (byte)redvalue;
            Green = (byte)greenvalue;
            Blue = (byte)bluevalue;
            
        }


      
    }
}
